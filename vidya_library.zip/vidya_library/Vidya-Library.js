/* =========================================================
   VIDYA LIBRARY | THE STUDY ZONE - RAJNANDGAON
   COMPLETE JAVASCRIPT
   Firebase Realtime Database Direct Sync (Users, Seats, Lockers, Bookings)
   Mobile Auth + Forgot Password + Live Availability + Admin
   ========================================================= */

"use strict";

/* ================= PLAN DISPLAY NAME HELPER ================= */
function getPlanDisplayName(p) {
    if (p === "4") return "4 घंटे (शिफ्ट)";
    if (p === "6") return "6 घंटे (शिफ्ट)";
    if (p === "8") return "8 घंटे (शिफ्ट)";
    if (p === "Full Time") return "Full Time (24/7)";
    if (p === "Reserved") return "Reserved (फिक्स्ड अपनी सीट)";
    return p || "4 घंटे";
}
window.getPlanDisplayName = getPlanDisplayName;


import { initializeApp } from "https://www.gstatic.com/firebasejs/13.1.0/firebase-app.js";
import {
    getDatabase,
    ref,
    set,
    get,
    update,
    child,
    onValue,
    push,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/13.1.0/firebase-database.js";

/* ================= FIREBASE CONFIG ================= */
const firebaseConfig = {
    apiKey: "AIzaSyAinNLUTaMDRYhAHId_3c-44nN2ygGAF_c",
    authDomain: "vidya-library-7aeb7.firebaseapp.com",
    databaseURL: "https://vidya-library-7aeb7-default-rtdb.firebaseio.com",
    projectId: "vidya-library-7aeb7",
    storageBucket: "vidya-library-7aeb7.firebasestorage.app",
    messagingSenderId: "213812561204",
    appId: "1:213812561204:web:7cec5ec006e1a419f51161"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

/* ================= LIBRARY SETTINGS ================= */
const TOTAL_SEATS = 80;
const TOTAL_LOCKERS = 24;
const DEPOSIT = 300;
const LOCKER_MONTHLY = 100;
const UPI_ID = "q270033628@ybl";
const PAYEE_NAME = "Vidyalibrary the study zone";
const LIBRARY_PHONE_1 = "9111701828";
const LIBRARY_PHONE_2 = "7000545675";
const LIBRARY_PHONE = "9111701828";
const LIBRARY_ADDRESS = "Add. - 1st Floor, Near Digvijay College, Front of Durga Mandir, Shiv Towar, Rajnandgaon (C.G.)";

/* ================= FEES STRUCTURE ================= */
const FEES = {
    "4": { "1": 500, "2": 800, "3": 1200, "6": 2400 },
    "6": { "1": 700, "2": 1200, "3": 1800, "6": 3200 },
    "8": { "1": 900, "2": 1600, "3": 2200, "6": 4000 },
    "Full Time": { "1": 1000, "2": 1800, "3": 2500, "6": 4500 },
    "Reserved": { "1": 1200, "2": 2200, "3": 3200, "6": 5500 }
};

/* ================= SEED BOOKS ================= */
const INITIAL_BOOKS = [
  {
    "id": "b1",
    "title": "Ankganit (RS Agrawal)",
    "author": "RS Agrawal",
    "category": "गणित (Maths)",
    "copies": 2
  },
  {
    "id": "b2",
    "title": "Ankganit (S.D. Yadav)",
    "author": "S.D. Yadav",
    "category": "गणित (Maths)",
    "copies": 2
  },
  {
    "id": "b3",
    "title": "Lakshmikant (Bharat Ki Rajvyavastha)",
    "author": "M. Laxmikanth",
    "category": "राजव्यवस्था (Polity)",
    "copies": 2
  },
  {
    "id": "b4",
    "title": "Aryabhatt (Maths)",
    "author": "Aryabhatt Publication",
    "category": "गणित (Maths)",
    "copies": 2
  },
  {
    "id": "b5",
    "title": "Deepak Kumar (Reasoning)",
    "author": "Deepak Kumar",
    "category": "रीजनिंग (Reasoning)",
    "copies": 2
  },
  {
    "id": "b6",
    "title": "Aryabhatt (Reasoning)",
    "author": "Aryabhatt Publication",
    "category": "रीजनिंग (Reasoning)",
    "copies": 1
  },
  {
    "id": "b7",
    "title": "Vinay Kumar Pathak (Hindi)",
    "author": "Vinay Kumar Pathak",
    "category": "हिंदी भाषा",
    "copies": 2
  },
  {
    "id": "b8",
    "title": "Vinay Kumar (Chhattisgarhi)",
    "author": "Vinay Kumar",
    "category": "छत्तीसगढ़ी भाषा",
    "copies": 2
  },
  {
    "id": "b9",
    "title": "Lucent Samanya Gyan",
    "author": "Lucent Publication",
    "category": "सामान्य ज्ञान (GK)",
    "copies": 2
  },
  {
    "id": "b10",
    "title": "Lucent Hindi",
    "author": "Lucent Publication",
    "category": "हिंदी भाषा",
    "copies": 2
  },
  {
    "id": "b11",
    "title": "Lucent Sa. Vigyan (General Science)",
    "author": "Lucent Publication",
    "category": "सामान्य विज्ञान",
    "copies": 2
  },
  {
    "id": "b12",
    "title": "Mahesh Kr Barnwal (Bhugol)",
    "author": "Mahesh Kumar Barnwal",
    "category": "भूगोल (Geography)",
    "copies": 2
  },
  {
    "id": "b13",
    "title": "Ramkumar Behar",
    "author": "Ramkumar Behar",
    "category": "छत्तीसगढ़ संदर्भ",
    "copies": 1
  },
  {
    "id": "b14",
    "title": "Gitesh Kumar Janjati",
    "author": "Gitesh Kumar",
    "category": "जनजाति एवं संस्कृति",
    "copies": 1
  },
  {
    "id": "b15",
    "title": "Gitesh Kumar Manna Sanskriti",
    "author": "Gitesh Kumar",
    "category": "संस्कृति एवं परंपरा",
    "copies": 1
  },
  {
    "id": "b16",
    "title": "HR Vishisht Adhyayan (CG)",
    "author": "Hariram Patel (HR)",
    "category": "छत्तीसगढ़ अध्ययन",
    "copies": 2
  },
  {
    "id": "b17",
    "title": "Neetu Mam English (Vol-1)",
    "author": "Neetu Singh (KD Campus)",
    "category": "अंग्रेजी (English)",
    "copies": 1
  },
  {
    "id": "b18",
    "title": "Neetu Mam English (Vol-2)",
    "author": "Neetu Singh (KD Campus)",
    "category": "अंग्रेजी (English)",
    "copies": 1
  },
  {
    "id": "b19",
    "title": "HR Samanya Angreji",
    "author": "Hariram Patel (HR)",
    "category": "अंग्रेजी (English)",
    "copies": 2
  },
  {
    "id": "b20",
    "title": "Arihant CTET (Ganit)",
    "author": "Arihant Publication",
    "category": "शिक्षक पात्रता (CTET/TET)",
    "copies": 1
  },
  {
    "id": "b21",
    "title": "Arihant CTET (Sa. Vigyan)",
    "author": "Arihant Publication",
    "category": "शिक्षक पात्रता (CTET/TET)",
    "copies": 1
  },
  {
    "id": "b22",
    "title": "HR (CG Class Notes)",
    "author": "Hariram Patel (HR)",
    "category": "छत्तीसगढ़ क्लास नोट्स",
    "copies": 2
  },
  {
    "id": "b23",
    "title": "Arihant Samanya Adhyayan 1400+",
    "author": "Arihant Publication",
    "category": "सामान्य अध्ययन",
    "copies": 2
  },
  {
    "id": "b24",
    "title": "Samanya Gyan Manohar Pandey",
    "author": "Manohar Pandey",
    "category": "सामान्य ज्ञान (GK)",
    "copies": 2
  },
  {
    "id": "b25",
    "title": "HR Computer (Solved)",
    "author": "Hariram Patel (HR)",
    "category": "कंप्यूटर ज्ञान",
    "copies": 2
  },
  {
    "id": "b26",
    "title": "Madan Kumar",
    "author": "Madan Kumar",
    "category": "प्रतियोगी संदर्भ",
    "copies": 1
  },
  {
    "id": "b27",
    "title": "Hindi Vidhish",
    "author": "Vidhish Publication",
    "category": "हिंदी साहित्य व व्याकरण",
    "copies": 1
  },
  {
    "id": "b28",
    "title": "Rojgar / Suchna",
    "author": "Govt Publications",
    "category": "रोजगार व सूचना",
    "copies": 1
  },
  {
    "id": "b29",
    "title": "CG Vastunishth Solved Paper",
    "author": "CG Vyapam / CGPSC",
    "category": "सॉल्व्ड पेपर्स",
    "copies": 1
  },
  {
    "id": "b30",
    "title": "Pariksha Vani (Jeev Vigyan)",
    "author": "Pariksha Vani",
    "category": "जीव विज्ञान (Biology)",
    "copies": 2
  },
  {
    "id": "b31",
    "title": "Pariksha Vani (Bhautik Rasayan)",
    "author": "Pariksha Vani",
    "category": "भौतिक व रसायन",
    "copies": 2
  },
  {
    "id": "b32",
    "title": "Vinay Kumar (CG Handbook)",
    "author": "Vinay Kumar",
    "category": "छत्तीसगढ़ हैंडबुक",
    "copies": 2
  },
  {
    "id": "b33",
    "title": "HR Bharat Bhugol",
    "author": "Hariram Patel (HR)",
    "category": "भारत का भूगोल",
    "copies": 2
  },
  {
    "id": "b34",
    "title": "Arihant (SSC-GD)",
    "author": "Arihant Publication",
    "category": "SSC-GD भर्ती",
    "copies": 2
  },
  {
    "id": "b35",
    "title": "Arihant (Railway Group D)",
    "author": "Arihant Publication",
    "category": "रेलवे (Railway)",
    "copies": 2
  },
  {
    "id": "b36",
    "title": "Vardhwal (Itihas)",
    "author": "Vardhwal Publication",
    "category": "इतिहास (History)",
    "copies": 2
  },
  {
    "id": "b37",
    "title": "Vardhwal (Arthashastra)",
    "author": "Vardhwal Publication",
    "category": "अर्थशास्त्र (Economics)",
    "copies": 2
  },
  {
    "id": "b38",
    "title": "Ghatnachakra (Bhugol)",
    "author": "Ghatna Chakra",
    "category": "पूर्वावलोकन भूगोल",
    "copies": 2
  },
  {
    "id": "b39",
    "title": "HR CGPSC Solved",
    "author": "Hariram Patel (HR)",
    "category": "CGPSC सॉल्व्ड पेपर्स",
    "copies": 2
  },
  {
    "id": "b40",
    "title": "HR Hamar Chhattisgarhi Bhasha",
    "author": "Hariram Patel (HR)",
    "category": "छत्तीसगढ़ी भाषा",
    "copies": 1
  },
  {
    "id": "b41",
    "title": "HR CG Ko Gaurav Shala",
    "author": "Hariram Patel (HR)",
    "category": "छत्तीसगढ़ सामान्य ज्ञान",
    "copies": 1
  },
  {
    "id": "b42",
    "title": "HR - CG VYAPAM Solved",
    "author": "Hariram Patel (HR)",
    "category": "व्यापम सॉल्व्ड पेपर्स",
    "copies": 1
  },
  {
    "id": "b43",
    "title": "HR Lok Kala Sanskriti",
    "author": "Hariram Patel (HR)",
    "category": "लोक कला एवं संस्कृति",
    "copies": 1
  },
  {
    "id": "b44",
    "title": "Delhi IAS Prashnottari Sangrah",
    "author": "Delhi IAS Academy",
    "category": "IAS/PSC प्रश्नोत्तरी",
    "copies": 1
  },
  {
    "id": "b45",
    "title": "Varnwal Samvidhan",
    "author": "Mahesh Kumar Barnwal",
    "category": "भारतीय संविधान",
    "copies": 1
  },
  {
    "id": "b46",
    "title": "Tuteja CG Prashnottari",
    "author": "Tuteja Tutorials",
    "category": "छत्तीसगढ़ प्रश्नोत्तरी",
    "copies": 1
  },
  {
    "id": "b47",
    "title": "Book Nayak Current Affairs",
    "author": "Book Nayak",
    "category": "करेंट अफेयर्स",
    "copies": 1
  },
  {
    "id": "b48",
    "title": "Picasso (General English / GS)",
    "author": "Picasso Series",
    "category": "सामान्य अध्ययन",
    "copies": 1
  },
  {
    "id": "b49",
    "title": "e-Pathshala Current Affairs",
    "author": "e-Pathshala",
    "category": "करेंट अफेयर्स",
    "copies": 1
  },
  {
    "id": "b50",
    "title": "Arjuna Current Affairs",
    "author": "Arjuna Publication",
    "category": "करेंट अफेयर्स",
    "copies": 1
  },
  {
    "id": "b51",
    "title": "UGC NET (Madan-1)",
    "author": "KVS Madaan",
    "category": "UGC NET Paper 1",
    "copies": 2
  },
  {
    "id": "b52",
    "title": "UGC NET (Arihant-1)",
    "author": "Arihant Publication",
    "category": "UGC NET Paper 1",
    "copies": 2
  },
  {
    "id": "b53",
    "title": "Ghatnachakra Hindi",
    "author": "Ghatna Chakra",
    "category": "पूर्वावलोकन सामान्य हिंदी",
    "copies": 2
  },
  {
    "id": "b54",
    "title": "Ghatnachakra Rajya Vyavastha",
    "author": "Ghatna Chakra",
    "category": "पूर्वावलोकन राजव्यवस्था",
    "copies": 2
  },
  {
    "id": "b55",
    "title": "Ghatnachakra Itihas",
    "author": "Ghatna Chakra",
    "category": "पूर्वावलोकन इतिहास",
    "copies": 2
  },
  {
    "id": "b56",
    "title": "ADEO Vastunishth",
    "author": "ADEO Exam Special",
    "category": "ADEO परीक्षा विशेष",
    "copies": 1
  },
  {
    "id": "b57",
    "title": "HOSTAL WARDEN",
    "author": "Hostel Warden Special",
    "category": "छात्रावास अधीक्षक विशेष",
    "copies": 2
  },
  {
    "id": "b58",
    "title": "CG Aarthik Sarvekshan",
    "author": "CG Government",
    "category": "छत्तीसगढ़ आर्थिक सर्वेक्षण",
    "copies": 1
  }
];

/* ================= STATE ================= */
let currentUser = null;
let currentAuthMode = "login";
let activeGeneratedOtp = null;
let registeredUsers = {};
let usedUtrs = {};

let selectedSeat = null;
let currentBookingType = "seat";
let currentSelectedPlan = "4";
let currentSelectedMonths = "1";
let selectedLocker = null;

let availability = {
    seats: {},
    lockers: {}
};

let myBookings = [];
let allAdminRequests = [];
let allComplaints = [];
let booksCache = [...INITIAL_BOOKS];
let toastTimer = null;
let currentBookingDraft = null;
let currentLockerDraft = null;

/* ================= HELPER FUNCTIONS ================= */
const $ = id => document.getElementById(id);
const value = (id, fallback = "") => $(id)?.value ?? fallback;

function text(id, content) {
    const el = $(id);
    if (el) el.textContent = content;
}

function money(amount) {
    return "₹" + Number(amount || 0).toLocaleString("en-IN");
}

function escapeHTML(input) {
    return String(input ?? "").replace(/[&<>"']/g, c => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[c]);
}

function normalisePhone(phone) {
    return String(phone || "").replace(/\D/g, "").slice(-10);
}


/* ================= ROBUST DATE PARSER & 30-DAY MONTH VALIDITY ================= */
function parseAnyDate(dStr) {
    if (!dStr) return new Date();
    if (dStr instanceof Date && !isNaN(dStr.getTime())) return dStr;
    const str = String(dStr).trim();
    if (/^\d{4}-\d{1,2}-\d{1,2}/.test(str)) {
        const [y, m, d] = str.split('-').map(Number);
        return new Date(y, m - 1, d);
    }
    if (/^\d{1,2}\/\d{1,2}\/\d{4}/.test(str)) {
        const parts = str.split('/').map(Number);
        if (parts[0] > 12) {
            return new Date(parts[2], parts[1] - 1, parts[0]);
        }
        return new Date(parts[2], parts[0] - 1, parts[1]);
    }
    const parsed = new Date(str);
    if (!isNaN(parsed.getTime())) return parsed;
    return new Date();
}

function calculateValidity(startDateStr, months) {
    try {
        const start = parseAnyDate(startDateStr);
        const m = Number(months || 1);
        const totalDays = m * 30; // 30 days per month
        const end = new Date(start.getTime() + (totalDays - 1) * 24 * 60 * 60 * 1000);

        const pad = n => String(n).padStart(2, '0');
        const formatDate = d => `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
        const formatISO = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
        const formatReadable = d => d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });

        return {
            startDate: formatISO(start),
            startDateFormatted: formatDate(start),
            endDate: formatISO(end),
            endDateFormatted: formatDate(end),
            startReadable: formatReadable(start),
            endReadable: formatReadable(end),
            totalDays,
            months: m,
            summaryText: `${formatDate(start)} से ${formatDate(end)} (कुल ${totalDays} दिन)`
        };
    } catch (err) {
        console.warn("calculateValidity fallback:", err);
        const d = new Date();
        return {
            startDate: todayDate(),
            startDateFormatted: todayDate(),
            endDate: todayDate(),
            endDateFormatted: todayDate(),
            startReadable: todayDate(),
            endReadable: todayDate(),
            totalDays: 30,
            months: 1,
            summaryText: "30 दिन की सदस्यता"
        };
    }
}

function todayDate() {
    const d = new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
}

/* ================= TOAST ================= */
function toast(message, type = "info") {
    let node = $("toast");
    if (!node) {
        node = document.createElement("div");
        node.id = "toast";
        document.body.appendChild(node);
    }
    node.textContent = message;
    node.style.display = "block";
    node.style.background = type === "error" ? "#df2028" : (type === "success" ? "#18833b" : "#252f87");

    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
        node.style.display = "none";
    }, 3500);
}
window.toast = toast;

/* ================= NAVIGATION ================= */
function go(pageId) {
    try {
        if (pageId === "login" || pageId === "lockers") {
            pageId = (pageId === "lockers") ? "booking" : "profile";
        }
        const target = $(pageId);
        if (!target || !target.classList.contains("page")) {
            toast("पेज नहीं मिला: " + pageId, "error");
            return;
        }

        document.querySelectorAll(".page").forEach(p => {
            p.classList.remove("active");
            p.style.display = "none";
        });

        target.classList.add("active");
        target.style.display = "block";

        document.querySelectorAll(".nav-item, .d-nav-item").forEach(btn => {
            const active = btn.dataset.page === pageId;
            btn.classList.toggle("active", active);
            if (active) btn.setAttribute("aria-current", "page");
            else btn.removeAttribute("aria-current");
        });

        window.scrollTo({ top: 0, behavior: "smooth" });

        // Safely trigger sub-page renders inside independent try/catch
        if (pageId === "booking") {
            try {
                if (currentUser) {
                    if ($("studentName") && !$("studentName").value) $("studentName").value = currentUser.displayName || "";
                    if ($("studentPhone") && !$("studentPhone").value && currentUser.phoneNumber) $("studentPhone").value = currentUser.phoneNumber;
                }
                renderSeatGrid();
                updateSummary();
                const curPhone = normalisePhone(value("studentPhone") || currentUser?.phoneNumber || "");
                if (curPhone.length === 10) {
                    renderDepositBadge(curPhone, getStudentDepositStatus(curPhone));
                }
            } catch (e) {
                console.warn("Booking sub-render notice:", e);
            }
        } else if (pageId === "lockers") {
            try { renderLockerGrid(); } catch (e) {}
        } else if (pageId === "profile") {
            try { renderHistory(); } catch (e) { console.warn("renderHistory notice:", e); }
            try { renderAdminRequests(); } catch (e) { console.warn("renderAdminRequests notice:", e); }
            try { renderStudentComplaints(); } catch (e) { console.warn("renderStudentComplaints notice:", e); }
        } else if (pageId === "books") {
            try { renderBooks(booksCache); } catch (e) { console.warn("renderBooks notice:", e); }
        } else if (pageId === "fees") {
            try { updateSummary(); } catch (e) { console.warn("updateSummary notice:", e); }
        }
    } catch (navErr) {
        console.error("Global navigation error:", navErr);
    }
}
window.go = go;

window._pageRenderHooks = {
    booking: function() {
        if (currentUser) {
            if ($("studentName") && !$("studentName").value) $("studentName").value = currentUser.displayName || "";
            if ($("studentPhone") && !$("studentPhone").value && currentUser.phoneNumber) $("studentPhone").value = currentUser.phoneNumber;
        }
        renderSeatGrid();
        updateSummary();
        const curPhone = normalisePhone(value("studentPhone") || currentUser?.phoneNumber || "");
        if (curPhone.length === 10) {
            renderDepositBadge(curPhone, getStudentDepositStatus(curPhone));
        }
    },
    lockers: function() { renderLockerGrid(); },
    profile: function() {
        try { renderHistory(); } catch(e) {}
        try { renderAdminRequests(); } catch(e) {}
        try { renderStudentComplaints(); } catch(e) {}
    },
    books: function() { renderBooks(booksCache); },
    fees: function() { updateSummary(); }
};



/* ================= UNIFIED BOOKING (SEAT, LOCKER, COMBO) ================= */
function setBookingType(type) {
    currentBookingType = type;

    $("btnTypeSeat")?.classList.toggle("active", type === "seat");
    $("btnTypeBoth")?.classList.toggle("active", type === "seat_and_locker");
    $("btnTypeLocker")?.classList.toggle("active", type === "locker_only");

    const seatCard = $("seatSelectionCard");
    const lockerCard = $("lockerSelectionCard");
    const seatPlanRow = $("seatPlanRow");
    const lockerDurationWrap = $("lockerOnlyDurationWrap");
    const rowBaseFee = $("rowBaseFee");
    const rowLockerFee = $("rowLockerFee");
    const rowDepositFee = $("rowDepositFee");

    if (type === "seat") {
        if (seatCard) seatCard.style.display = "block";
        if (lockerCard) lockerCard.style.display = "none";
        if (seatPlanRow) seatPlanRow.style.display = "grid";
        if (lockerDurationWrap) lockerDurationWrap.style.display = "none";
        if (rowBaseFee) rowBaseFee.style.display = "flex";
        if (rowLockerFee) rowLockerFee.style.display = "none";
        if (rowDepositFee) rowDepositFee.style.display = "flex";
        selectedLocker = null;
    } else if (type === "seat_and_locker") {
        if (seatCard) seatCard.style.display = "block";
        if (lockerCard) lockerCard.style.display = "block";
        if (seatPlanRow) seatPlanRow.style.display = "grid";
        if (lockerDurationWrap) lockerDurationWrap.style.display = "none";
        if (rowBaseFee) rowBaseFee.style.display = "flex";
        if (rowLockerFee) rowLockerFee.style.display = "flex";
        if (rowDepositFee) rowDepositFee.style.display = "flex";
    } else if (type === "locker_only") {
        if (seatCard) seatCard.style.display = "none";
        if (lockerCard) lockerCard.style.display = "block";
        if (seatPlanRow) seatPlanRow.style.display = "none";
        if (lockerDurationWrap) lockerDurationWrap.style.display = "block";
        if (rowBaseFee) rowBaseFee.style.display = "none";
        if (rowLockerFee) rowLockerFee.style.display = "flex";
        if (rowDepositFee) rowDepositFee.style.display = "none";
        selectedSeat = null;
    }

    selectSlot("4");
    selectMonths("1");
    renderLockerGrid();
    updateSummary();
}
window.setBookingType = setBookingType;

function onMonthsChange() {
    updateSummary();
}
window.onMonthsChange = onMonthsChange;

function onLockerMonthsChange() {
    updateSummary();
}
window.onLockerMonthsChange = onLockerMonthsChange;

function renderDepositBadge(phone, status) {
    const badge = $("depositNoticeBadge");
    if (!badge) return;

    if (!phone || phone.length !== 10) {
        badge.style.display = "none";
        return;
    }

    badge.style.display = "block";
    if (status === "active_held") {
        badge.style.background = "#f0fdf4";
        badge.style.border = "1.5px solid #86efac";
        badge.style.color = "#15803d";
        badge.innerHTML = `✓ <b>रजिस्टर्ड विद्यार्थी:</b> आपका ₹300 सिक्योरिटी डिपॉजिट पूर्व से सुरक्षित जमा है। <u>सेकंड, थर्ड या आगे की किसी भी बुकिंग (2nd / 3rd Booking) पर डिपॉजिट ₹0 (पूर्णतः फ्री)</u> रहेगा!`;
    } else if (status === "refunded") {
        badge.style.background = "#fffbeb";
        badge.style.border = "1.5px solid #fde68a";
        badge.style.color = "#b45309";
        badge.innerHTML = `↩️ <b>पुनः प्रवेश:</b> आपका पूर्व डिपॉजिट रिफंड हो चुका था। नए सत्र हेतु ₹300 रिफंडेबल डिपॉजिट देय होगा।`;
    } else {
        badge.style.background = "#eff6ff";
        badge.style.border = "1.5px solid #bfdbfe";
        badge.style.color = "#1e40af";
        badge.innerHTML = `ℹ️ <b>फर्स्ट बुकिंग (1st Time):</b> ₹300 रिफंडेबल सिक्योरिटी डिपॉजिट <u>केवल पहली बार</u> देय है। इसके बाद 2nd, 3rd या आगे की किसी भी बुकिंग पर यह शुल्क ₹0 रहेगा।`;
    }
}
window.renderDepositBadge = renderDepositBadge;

async function onPhoneInput() {
    const phone = normalisePhone(value("studentPhone"));
    updateSummary();

    if (phone.length === 10) {
        const localStatus = getStudentDepositStatus(phone);
        renderDepositBadge(phone, localStatus);

        // Also verify real-time status in Firebase
        try {
            const userSnap = await get(child(ref(db), "users/" + phone));
            if (userSnap.exists()) {
                const uData = userSnap.val();
                if (!registeredUsers[phone]) registeredUsers[phone] = {};
                registeredUsers[phone] = { ...registeredUsers[phone], ...uData };

                if (uData.depositStatus) {
                    registeredUsers[phone].depositStatus = uData.depositStatus;
                } else if (uData.bookings && Object.keys(uData.bookings).length > 0) {
                    registeredUsers[phone].depositStatus = "active_held";
                }

                if (uData.name && $("studentName") && !$("studentName").value.trim()) {
                    $("studentName").value = uData.name;
                }

                updateSummary();
                renderDepositBadge(phone, getStudentDepositStatus(phone));
            }
        } catch (e) {
            console.warn("Realtime phone deposit check notice:", e);
        }
    } else {
        renderDepositBadge("", "not_paid");
    }
}
window.onPhoneInput = onPhoneInput;

/* ================= PLAN SELECTION ================= */
function selectedPlan() {
    return currentSelectedPlan || value("slot", "4");
}

function selectedMonths() {
    return String(currentSelectedMonths || value("months", "1"));
}

function selectedStartDate() {
    return value("startDate", todayDate());
}


/* ================= INSTANT SELECT SLOT & MONTHS (PILL BUTTONS) ================= */
function selectSlot(planName) {
    currentSelectedPlan = planName;
    const slotEl = $("slot");
    if (slotEl) slotEl.value = planName;

    // Highlight active pill button
    document.querySelectorAll(".plan-pill").forEach(btn => {
        btn.classList.toggle("active", btn.dataset.plan === planName);
    });

    onPlanChange();
    updateSummary();

    if (planName === "Reserved") {
        toast("🌟 Reserved प्लान चुना गया! सीट फीस ₹1,200 (कुल ₹1,500) नीचे 80 सीटों का नक्शा खुला है।", "info");
    } else {
        const amt = calculateBookingAmount();
        toast(`✓ ${getPlanDisplayName(planName)} चुना गया! सीट फीस: ${money(amt.baseFee)} | कुल: ${money(amt.total)}`, "info");
    }
}
window.selectSlot = selectSlot;

function selectMonths(mCount) {
    currentSelectedMonths = String(mCount);
    const monthsEl = $("months");
    if (monthsEl) monthsEl.value = String(mCount);

    document.querySelectorAll(".dur-pill").forEach(btn => {
        btn.classList.toggle("active", btn.dataset.months === String(mCount));
    });

    onMonthsChange();
    updateSummary();

    const amt = calculateBookingAmount();
    const mLabel = (String(mCount) === "6") ? "4+2 Month (6 माह - 180 दिन)" : `${mCount} माह (${mCount * 30} दिन)`;
    toast(`✓ ${mLabel} चुना गया! कुल राशि: ${money(amt.total)}`, "info");
}
window.selectMonths = selectMonths;

function onPlanChange() {
    const plan = selectedPlan();
    document.querySelectorAll(".plan-pill").forEach(btn => {
        btn.classList.toggle("active", btn.dataset.plan === plan);
    });
    renderSeatGrid();
    updateSummary();
}

function onPayMethodChange() {
    if (currentBookingDraft) {
        // Render payment directly on current active page
    const activePage = document.querySelector(".page.active")?.id || "booking";
    showPaymentPanel(currentBookingDraft, activePage);
    }
}

/* ================= AVAILABILITY (LIVE FROM FIREBASE) ================= */
function startLiveAvailability() {
    try {
        const availRef = ref(db, "public/availability");
        onValue(availRef, snapshot => {
            const data = snapshot.val();
            if (data) {
                if (data.seats) availability.seats = { ...availability.seats, ...data.seats };
                if (data.lockers) availability.lockers = { ...availability.lockers, ...data.lockers };
                renderSeatGrid();
                renderLockerGrid();
            }
        }, error => {
            console.warn("Firebase availability read info:", error.message);
        });
    } catch (err) {
        console.warn("Firebase availability setup:", err);
    }
}

function getSeatStatus(seatNo) {
    const item = availability.seats[String(seatNo)];
    if (!item) return "available";
    if (typeof item === "string") return item;
    return item.status || "available";
}

function getLockerStatus(lockerNo) {
    const item = availability.lockers[String(lockerNo)];
    if (!item) return "available";
    if (typeof item === "string") return item;
    return item.status || "available";
}

function isUnavailable(status) {
    return ["reserved", "booked", "occupied", "pending_verification"].includes(String(status).toLowerCase());
}

/* ================= EXACT ARCHITECTURAL FLOOR MAP (IMAGE 3 REPLICA) ================= */
// Clean Production Launch: All 80 Seats and 24 Lockers are 100% Vacant & Available

function renderSeatGrid() {
    const wrapper = $("floorMapWrapper");
    const container = $("floorMapContainer");
    const msg = $("seatMessage");
    const count = $("freeSeatsCount");
    const cardTitle = $("seatCardTitle");
    if (!container) return;

    const plan = selectedPlan();
    const isReserved = (plan === "Reserved");

    // 4, 6, 8 hours or Full Time: DO NOT SHOW SEATS!
    if (!isReserved) {
        if (wrapper) wrapper.style.display = "none";
        selectedSeat = null;

        if (count) count.textContent = "लाइब्रेरी आवंटन";
        if (cardTitle) cardTitle.textContent = `सीट आवंटन (${plan} प्लान)`;

        if (msg) {
            msg.innerHTML = `
                <div class="notice" style="background:#eef2ff; border:1px solid #c7ccff; color:#252f87; padding:16px; border-radius:14px; font-size:14px; line-height:1.7;">
                    ℹ️ <b>${plan} प्लान:</b> 4, 6, 8 घंटे और Full Time प्लान में सीट <b>लाइब्रेरी काउंटर</b> द्वारा आवंटित की जाती है।<br>
                    👉 यदि आप बिल्डिंग का पूरा नक्शा देखकर अपनी <b>मनपसंद फिक्स्ड सीट (Reserved)</b> चुनना चाहते हैं, तो 'समय प्लान' में <b>'Reserved'</b> चुनें।
                </div>
            `;
        }
        return;
    }

    // ONLY FOR "Reserved" PLAN: SHOW THE FULL ARCHITECTURAL FLOOR PLAN!
    if (wrapper) wrapper.style.display = "block";
    if (cardTitle) cardTitle.textContent = "🏢 संपूर्ण लाइब्रेरी सिटिंग फ्लोर मैप (Flat Floor Plan)";

    // Calculate counts
    let freeSeatsCount = 0;
    let resSeatsCount = 0;
    for (let s = 1; s <= TOTAL_SEATS; s++) {
        if (isUnavailable(getSeatStatus(s))) resSeatsCount++;
        else freeSeatsCount++;
    }

    if (count) count.textContent = `${freeSeatsCount} सीटें खाली | ${resSeatsCount} आरक्षित`;

    // Helper to generate seat button HTML
    const renderSeatBtn = (seatNo, label = null) => {
        const num = seatNo;
        const status = getSeatStatus(num);
        const unavailable = isUnavailable(status);
        const isSelected = (selectedSeat === num);
        const disp = label || num;

        return `
            <button type="button" 
                class="bp-seat ${unavailable ? 'reserved' : 'available'} ${isSelected ? 'selected' : ''}" 
                data-seat="${num}" 
                ${unavailable ? 'disabled' : ''} 
                title="सीट नं. ${num} (${unavailable ? 'आरक्षित' : 'खाली / उपलब्ध'})">
                ${disp}
            </button>
        `;
    };

    // Helper to generate locker button HTML
    const renderLockerBtn = (lockerNo) => {
        const status = getLockerStatus(lockerNo);
        const unavailable = isUnavailable(status);
        const isSelected = (selectedLocker === lockerNo);

        return `
            <button type="button" 
                class="bp-locker ${unavailable ? 'reserved' : 'vacant'} ${isSelected ? 'selected' : ''}" 
                data-locker="${lockerNo}" 
                ${unavailable ? 'disabled' : ''} 
                title="लॉकर L${lockerNo} (${unavailable ? 'आरक्षित' : 'खाली'})">
                L${lockerNo}
            </button>
        `;
    };

    // Generate complete Architectural Blueprint HTML matching Image 3
    container.innerHTML = `
        <div class="blueprint-building">
            
            <!-- LEFT BLUEPRINT SUMMARY SIDEBAR (EXACT MATCHING IMAGE 3) -->
            <div class="blueprint-sidebar">
                
                <!-- SEATING PLAN SUMMARY -->
                <div class="bp-summary-box">
                    <div class="bp-summary-header">SEATING PLAN SUMMARY</div>
                    <div class="bp-summary-body">
                        <div><b>कुल सीटें: 1 से 80</b></div>
                        <div style="font-size:11px; color:#555;">← → = (रास्ता / मार्ग / Pathway)</div>
                        <div class="bp-legend-item">
                            <span class="bp-color-box bp-green"></span>
                            <span><b>खाली / रिक्त सीटें:</b> ${freeSeatsCount}</span>
                        </div>
                        <div class="bp-legend-item">
                            <span class="bp-color-box bp-red"></span>
                            <span><b>आरक्षित सीटें:</b> ${resSeatsCount}</span>
                        </div>
                        <div class="bp-legend-item">
                            <span class="bp-color-box bp-blue"></span>
                            <span><b>आपकी चयनित सीट</b></span>
                        </div>
                    </div>
                </div>

                <!-- LOCKER SUMMARY -->
                <div class="bp-summary-box">
                    <div class="bp-summary-header" style="background:#a81219;">LOCKER SUMMARY (24 Total)</div>
                    <div class="bp-summary-body">
                        <div class="bp-legend-item">
                            <span class="bp-color-box bp-green"></span>
                            <span><b>उपलब्ध लॉकर:</b> ${24 - Object.keys(availability.lockers || {}).length}</span>
                        </div>
                        <div class="bp-legend-item">
                            <span class="bp-color-box bp-red"></span>
                            <span><b>आरक्षित लॉकर:</b> ${Object.keys(availability.lockers || {}).length}</span>
                        </div>
                        <div style="font-size:11px; margin-top:4px; color:#555;">शुल्क: ₹100 प्रति माह (30 दिन)</div>
                    </div>
                </div>

                <div class="notice" style="font-size:11px; padding:10px; background:#fff8d8; border:1px solid #f0e2a3;">
                    💡 <b>फ्लोर टिप्स:</b><br>
                    • 57 से 80: शांत कॉर्नर विंग<br>
                    • 1 से 25: फ्रंट विंग<br>
                    • अपनी पसंद की सीट पर क्लिक करें।
                </div>

            </div>

            <!-- MAIN ARCHITECTURAL FLOOR DRAWING -->
            <div class="blueprint-plan-area">
                
                <div class="bp-plan-header">Vidya Library - The Study Zone.</div>

                <!-- UPPER SECTION (LEFT DESKS + CENTRAL CORRIDOR + RIGHT DESKS & LOCKERS) -->
                <div class="bp-upper-wing">
                    
                    <!-- LEFT DESK COLUMN -->
                    <div class="bp-left-desks">
                        <!-- Cluster 1 -->
                        <div class="bp-desk-row">${renderSeatBtn(1)} ${renderSeatBtn(2)} ${renderSeatBtn(3)}</div>
                        <div class="bp-pathway">← Pathway →</div>

                        <!-- Cluster 2 -->
                        <div class="bp-desk-row">${renderSeatBtn(7)} ${renderSeatBtn(8)} ${renderSeatBtn(11)}</div>
                        <div class="bp-pathway">← Pathway →</div>

                        <!-- Cluster 3 -->
                        <div class="bp-desk-row">${renderSeatBtn(16)} ${renderSeatBtn(17)} ${renderSeatBtn(18)}</div>
                        <div class="bp-desk-row">${renderSeatBtn(21)} ${renderSeatBtn(22)} ${renderSeatBtn(23)}</div>
                        <div class="bp-pathway">← Pathway →</div>

                        <!-- Cluster 4 -->
                        <div class="bp-desk-row">${renderSeatBtn(26)} ${renderSeatBtn(27)} ${renderSeatBtn(28)}</div>
                        <div class="bp-pathway">← Pathway →</div>

                        <!-- Cluster 5 -->
                        <div class="bp-desk-row">${renderSeatBtn(29)} ${renderSeatBtn(30)} ${renderSeatBtn(31)}</div>
                        <div class="bp-desk-row">${renderSeatBtn(32)} ${renderSeatBtn(33)} ${renderSeatBtn(34)}</div>
                        <div class="bp-pathway">← Pathway →</div>

                        <!-- Cluster 6 -->
                        <div class="bp-desk-row">${renderSeatBtn(35)} ${renderSeatBtn(36)} ${renderSeatBtn(37)}</div>
                        <div class="bp-desk-row">${renderSeatBtn(38)} ${renderSeatBtn(39)} ${renderSeatBtn(40)}</div>
                        <div class="bp-pathway">← Pathway →</div>

                        <!-- Cluster 7 -->
                        <div class="bp-desk-row">${renderSeatBtn(41)} ${renderSeatBtn(42)} ${renderSeatBtn(43)}</div>
                        <div class="bp-desk-row">${renderSeatBtn(44)} ${renderSeatBtn(45)} ${renderSeatBtn(46)}</div>
                        <div class="bp-pathway">← Pathway →</div>

                        <!-- Cluster 8 -->
                        <div class="bp-desk-row">${renderSeatBtn(47)} ${renderSeatBtn(48)} ${renderSeatBtn(49)}</div>
                        <div class="bp-desk-row">${renderSeatBtn(50)} ${renderSeatBtn(51)} ${renderSeatBtn(52)}</div>
                    </div>

                    <!-- CENTRAL VERTICAL CORRIDOR (← Pathway →) -->
                    <div class="bp-vertical-corridor">
                        ← Pathway →
                    </div>

                    <!-- RIGHT DESK & LOCKERS COLUMN -->
                    <div class="bp-right-desks-and-lockers">
                        <!-- Top Desk Cluster 1 -->
                        <div class="bp-desk-row">${renderSeatBtn(4)} ${renderSeatBtn(5)}</div>
                        <div class="bp-pathway">← Pathway →</div>

                        <!-- Top Desk Cluster 2 -->
                        <div class="bp-desk-row">${renderSeatBtn(9)} ${renderSeatBtn(10)}</div>
                        <div class="bp-pathway">← Pathway →</div>

                        <!-- Top Desk Cluster 3 -->
                        <div class="bp-desk-row">${renderSeatBtn(19)} ${renderSeatBtn(20)}</div>
                        <div class="bp-desk-row">${renderSeatBtn(24)} ${renderSeatBtn(25)}</div>

                        <!-- LOCKER ZONE (4x6 GRID FROM IMAGE 3) -->
                        <div class="bp-lockers-block">
                            <div class="bp-lockers-header">🔐 LOCKERS (24 Total)</div>
                            <div class="bp-lockers-grid">
                                ${[1,2,3,4, 5,6,7,8, 9,10,11,12, 13,14,15,16, 17,18,19,20, 21,22,23,24].map(l => renderLockerBtn(l)).join('')}
                            </div>
                        </div>
                    </div>

                </div>

                <!-- HORIZONTAL MAIN HALLWAY -->
                <div class="bp-horizontal-hallway">
                    ← Pathway (हॉलवे / मुख्य गलियारा) →
                </div>

                <!-- BOTTOM L-WING (QUIET CORNER ZONE 53 TO 80) -->
                <div class="bp-bottom-wing">
                    
                    <!-- BOTTOM LEFT WING (Seats 57-80) -->
                    <div class="bp-bot-left-wing">
                        <div style="font-size:10px; font-weight:800; color:#203580; text-align:center;">शांत कॉर्नर विंग</div>
                        <div class="bp-desk-row">${renderSeatBtn(59)} ${renderSeatBtn(58)} ${renderSeatBtn(57)}</div>
                        <div class="bp-desk-row">${renderSeatBtn(66)} ${renderSeatBtn(65)} ${renderSeatBtn(64)}</div>
                        <div class="bp-pathway">← Pathway →</div>
                        <div class="bp-desk-row">${renderSeatBtn(73)} ${renderSeatBtn(72)} ${renderSeatBtn(71)}</div>
                        <div class="bp-desk-row">${renderSeatBtn(80)} ${renderSeatBtn(79)} ${renderSeatBtn(78)}</div>
                    </div>

                    <!-- BOTTOM VERTICAL CORRIDOR -->
                    <div class="bp-bot-vertical-corridor">
                        ← Pathway →
                    </div>

                    <!-- BOTTOM RIGHT WING (Seats 53-77) -->
                    <div class="bp-bot-right-wing">
                        <div style="font-size:10px; font-weight:800; color:#203580; text-align:center;">बैक स्टडी विंग</div>
                        <div class="bp-desk-row">${renderSeatBtn(56)} ${renderSeatBtn(55)} ${renderSeatBtn(54)} ${renderSeatBtn(53)}</div>
                        <div class="bp-desk-row">${renderSeatBtn(63)} ${renderSeatBtn(62)} ${renderSeatBtn(61)} ${renderSeatBtn(60)}</div>
                        <div class="bp-pathway">← Pathway →</div>
                        <div class="bp-desk-row">${renderSeatBtn(70)} ${renderSeatBtn(69)} ${renderSeatBtn(68)} ${renderSeatBtn(67)}</div>
                        <div class="bp-desk-row">${renderSeatBtn(77)} ${renderSeatBtn(76)} ${renderSeatBtn(75)} ${renderSeatBtn(74)}</div>
                    </div>

                </div>

            </div>

        </div>
    `;

    // Attach click events to all seat buttons
    container.querySelectorAll(".bp-seat.available").forEach(btn => {
        btn.addEventListener("click", () => {
            const seatNum = Number(btn.dataset.seat);
            selectedSeat = (selectedSeat === seatNum) ? null : seatNum;
            renderSeatGrid();
            updateSummary();
        });
    });

    // Attach click events to locker buttons
    container.querySelectorAll(".bp-locker.vacant").forEach(btn => {
        btn.addEventListener("click", () => {
            const lNum = Number(btn.dataset.locker);
            selectedLocker = (selectedLocker === lNum) ? null : lNum;
            text("lockerChoice", selectedLocker ? `L${selectedLocker} (शुल्क ₹100)` : "कोई नहीं");
            renderSeatGrid();
            renderLockerGrid();
            updateSummary();
        });
    });

    if (msg) {
        msg.innerHTML = selectedSeat
            ? `<div class="notice" style="background:#eafaf1; border:1.5px solid #18833b; color:#127938; padding:14px 18px; border-radius:14px; font-size:14px;">
                   ✓ आपने <b>सीट नं. ${selectedSeat}</b> चुनी है! (${selectedSeat >= 57 ? 'कॉर्नर / शांत ज़ोन' : 'मुख्य हॉल'})
               </div>`
            : `<div class="notice" style="background:#fff8d8; border:1.5px solid #d4c060; color:#5c4c00; padding:14px 18px; border-radius:14px; font-size:14px;">
                   👉 ऊपर दिए गए <b>लाइब्रेरी नक्शे</b> में अपनी मनपसंद खाली हरी सीट (Green Seat) पर क्लिक करके चुनें।
               </div>`;
    }
}

/* ================= RENDER LOCKERS ================= */
function renderLockerGrid() {
    const grid = $("lockerGrid");
    if (!grid) return;

    grid.innerHTML = "";
    let freeLockers = 0;

    for (let locker = 1; locker <= TOTAL_LOCKERS; locker++) {
        const status = getLockerStatus(locker);
        const unavailable = isUnavailable(status);

        if (!unavailable) freeLockers++;

        const button = document.createElement("button");
        button.type = "button";
        button.className = "locker " + (unavailable ? "reserved" : "available") + (selectedLocker === locker ? " selected" : "");
        button.textContent = `L${locker}`;
        button.disabled = unavailable;
        button.title = unavailable ? `लॉकर L${locker} आरक्षित है` : `लॉकर L${locker} उपलब्ध है`;

        if (!unavailable) {
            button.addEventListener("click", () => {
                selectedLocker = (selectedLocker === locker) ? null : locker;
                text("lockerChoice", selectedLocker ? `L${selectedLocker} (शुल्क ₹100)` : "कोई नहीं");
                renderLockerGrid();
                updateSummary();
            });
        }

        grid.appendChild(button);
    }

    text("freeLockersCount", `${freeLockers} उपलब्ध`);
    text("lockerChoice", selectedLocker ? `L${selectedLocker}` : "कोई नहीं");
}

/* ================= FEES CALCULATION ================= */
function calculateBookingAmount() {
    const plan = selectedPlan();
    const months = (currentBookingType === "locker_only") 
        ? Number(value("lockerOnlyMonths", "1")) 
        : Number(selectedMonths());

    const phone = normalisePhone(value("studentPhone") || currentUser?.phoneNumber || "");
    const deposit = (currentBookingType === "locker_only") ? 0 : calculateCurrentDeposit(phone);

    let baseFee = 0;
    if (currentBookingType === "seat" || currentBookingType === "seat_and_locker") {
        baseFee = FEES[plan]?.[String(months)] ?? (FEES[plan]?.["1"] || 500);
    }

    // LOCKER FEE: Strictly ₹100 per locker whenever any locker is selected or locker booking is active
    let lockerFee = 0;
    if (selectedLocker || currentBookingType === "locker_only" || currentBookingType === "seat_and_locker") {
        lockerFee = 100;
    }

    return {
        baseFee,
        lockerFee,
        deposit,
        total: baseFee + lockerFee + deposit,
        months,
        plan: (currentBookingType === "locker_only") ? "Locker Only" : plan
    };
}

/* ================= ADVANCED SECURITY DEPOSIT LIFECYCLE ================= */
// Statuses: 'not_paid' (first time: ₹300), 'active_held' (re-booking/continuing: ₹0), 'refunded' (re-joining: ₹300)
function getStudentDepositStatus(phone) {
    const cleanPhone = normalisePhone(phone || currentUser?.phoneNumber || "");
    if (!cleanPhone || cleanPhone.length !== 10) return "not_paid";

    const userRecord = registeredUsers[cleanPhone];
    if (userRecord && userRecord.depositStatus) {
        return userRecord.depositStatus;
    }

    // Check all confirmed bookings across student session and local database
    const allKnown = [...(myBookings || []), ...(allAdminRequests || [])];
    const userBookings = allKnown.filter(b => 
        normalisePhone(b.studentPhone) === cleanPhone && 
        (b.status === "confirmed" || b.status === "approved" || b.status === "paid") && 
        b.bookingType !== "locker"
    );

    if (userBookings.length > 0) {
        if (userBookings.some(b => b.depositRefunded === true)) {
            return "refunded";
        }
        return "active_held";
    }

    return "not_paid";
}

function calculateCurrentDeposit(phone) {
    const status = getStudentDepositStatus(phone);
    // If student already has active deposit held at library, charge 0.
    // If first time ('not_paid') or previously refunded ('refunded'), charge 300.
    return (status === "active_held") ? 0 : DEPOSIT;
}

function updateSummary() {
    try {
        const plan = selectedPlan();
        const months = selectedMonths();
        const phone = normalisePhone(value("studentPhone") || currentUser?.phoneNumber || "");
        const amount = calculateBookingAmount();
        const validity = calculateValidity(selectedStartDate(), months);

        const planDisplay = getPlanDisplayName(plan);
        const durLabel = (amount.months === 6) ? "4+2 Month" : `${amount.months} माह`;

        // Update live calc box on Booking Page
        if (currentBookingType === "locker_only") {
            text("bSumPlanText", `निजी लॉकर L${selectedLocker || '?'} · ${durLabel} (${validity.totalDays} दिन)`);
            text("bSumLockerFee", money(amount.lockerFee));
            if ($("rowLockerFee")) $("rowLockerFee").style.display = "flex";
            if ($("rowBaseFee")) $("rowBaseFee").style.display = "none";
            if ($("rowDepositFee")) $("rowDepositFee").style.display = "none";
        } else if (currentBookingType === "seat_and_locker" || selectedLocker) {
            text("bSumPlanText", `${planDisplay} + लॉकर L${selectedLocker || '?'} · ${durLabel}`);
            text("bSumBaseFee", money(amount.baseFee));
            text("bSumLockerFee", money(amount.lockerFee) + (selectedLocker ? ` (L${selectedLocker})` : ""));
            if ($("rowLockerFee")) $("rowLockerFee").style.display = "flex";
            if ($("rowBaseFee")) $("rowBaseFee").style.display = "flex";
            if ($("rowDepositFee")) $("rowDepositFee").style.display = "flex";
        } else {
            text("bSumPlanText", `${planDisplay} · ${durLabel} (${validity.totalDays} दिन)`);
            text("bSumBaseFee", money(amount.baseFee));
            if ($("rowLockerFee")) $("rowLockerFee").style.display = "none";
            if ($("rowBaseFee")) $("rowBaseFee").style.display = "flex";
            if ($("rowDepositFee")) $("rowDepositFee").style.display = "flex";
        }

        text("bSumBaseFee", money(amount.baseFee));
        text("bSumDeposit", amount.deposit > 0 ? "₹300 (पहली बार - रिफंडेबल)" : "₹0 (सुरक्षित जमा है · दोबारा देय नहीं ✓)");
        text("bSumTotal", money(amount.total));
        text("bSumExactText", money(amount.total));

        // Update validity text on booking page
        text("seatValidityText", validity.summaryText);

        // Update Fees Page Summary
        text("sumSeat", selectedSeat ? `Seat ${selectedSeat}` : (plan === "Reserved" ? "सीट चुनें" : "लाइब्रेरी द्वारा आवंटित"));
        text("sumSlot", planDisplay);
        text("sumMonths", `${amount.months} महीना (${validity.totalDays} दिन)`);
        text("sumValidity", `${validity.startReadable} से ${validity.endReadable} (${validity.totalDays} दिन)`);
        text("sumFee", money(amount.baseFee));
        text("sumLocker", money(amount.lockerFee));

        const depStatus = getStudentDepositStatus(phone);
        if (amount.deposit === 0) {
            text("sumDeposit", "₹0 (पहले से सुरक्षित जमा है ✓)");
        } else if (depStatus === "refunded") {
            text("sumDeposit", "₹300 (पिछला रिफंड हो चुका था)");
        } else {
            text("sumDeposit", "₹300 (प्रथम बार - रिफंडेबल)");
        }
        text("sumTotal", money(amount.total));

        // Update locker page
        const lockerStartDate = value("lockerStartDate", todayDate());
        const lockerMonths = Number(value("lockerMonths", "1"));
        const lockerValidity = calculateValidity(lockerStartDate, lockerMonths);
        text("lockerValidityText", lockerValidity.summaryText);
        text("lockerPrice", money(100));

        syncToFeesPage();
    } catch (e) {
        console.error("updateSummary error:", e);
    }
}

/* ================= FIREBASE USER AUTHENTICATION ================= */
function setAuthMode(mode) {
    currentAuthMode = mode;
    const loginTab = $("loginTab");
    const registerTab = $("registerTab");
    const authForm = $("authForm");
    const forgotForm = $("forgotForm");
    const nameWrap = $("authNameWrap");
    const submitBtn = $("authSubmit");
    const helperLinks = $("loginHelperLinks");

    if (mode === "login") {
        if (loginTab) loginTab.className = "btn btn-primary";
        if (registerTab) registerTab.className = "btn btn-outline";
        if (authForm) authForm.style.display = "block";
        if (forgotForm) forgotForm.style.display = "none";
        if (nameWrap) nameWrap.style.display = "none";
        if (submitBtn) submitBtn.textContent = "लॉगिन करें";
        if (helperLinks) helperLinks.style.display = "flex";
    } else if (mode === "register") {
        if (loginTab) loginTab.className = "btn btn-outline";
        if (registerTab) registerTab.className = "btn btn-primary";
        if (authForm) authForm.style.display = "block";
        if (forgotForm) forgotForm.style.display = "none";
        if (nameWrap) nameWrap.style.display = "block";
        if (submitBtn) submitBtn.textContent = "नया रजिस्ट्रेशन करें";
        if (helperLinks) helperLinks.style.display = "none";
    } else if (mode === "forgot") {
        if (loginTab) loginTab.className = "btn btn-outline";
        if (registerTab) registerTab.className = "btn btn-outline";
        if (authForm) authForm.style.display = "none";
        if (forgotForm) forgotForm.style.display = "block";
    }
}

async function handleAuthSubmit(e) {
    e.preventDefault();
    const phone = normalisePhone(value("authPhone"));
    const password = value("authPassword").trim();

    if (!/^[6-9]\d{9}$/.test(phone)) {
        toast("कृपया सही 10 अंकों का मोबाइल नंबर दर्ज करें।", "error");
        $("authPhone")?.focus();
        return;
    }

    if (password.length < 4) {
        toast("पासवर्ड कम से कम 4 अक्षर/अंकों का होना चाहिए।", "error");
        $("authPassword")?.focus();
        return;
    }

    if (currentAuthMode === "register") {
        const name = value("authName").trim();
        if (name.length < 2) {
            toast("कृपया विद्यार्थी का पूरा नाम दर्ज करें।", "error");
            $("authName")?.focus();
            return;
        }

        // Security Check: Is this phone already registered?
        let alreadyUser = registeredUsers[phone];
        if (!alreadyUser) {
            try {
                const snap = await get(child(ref(db), "users/" + phone));
                if (snap.exists()) alreadyUser = snap.val();
            } catch (err) {
                console.warn("Check user existence error:", err);
            }
        }

        if (alreadyUser) {
            toast("⚠️ यह मोबाइल नंबर पहले से रजिस्टर्ड है! कृपया सीधे पासवर्ड डालकर लॉगिन करें।", "info");
            setAuthMode("login");
            if ($("authPhone")) $("authPhone").value = phone;
            if ($("authPassword")) {
                $("authPassword").value = "";
                $("authPassword").focus();
            }
            return;
        }

        const userData = {
            name,
            phone,
            password,
            depositStatus: "not_paid",
            createdAt: Date.now()
        };

        // 1. Save to Firebase Realtime Database
        try {
            await set(ref(db, "users/" + phone), userData);
            console.log("User successfully registered in Firebase:", phone);
        } catch (fbErr) {
            console.warn("Firebase User Save Notice:", fbErr.message);
        }

        // 2. Also keep in local storage
        registeredUsers[phone] = userData;
        saveLocalData();

        currentUser = {
            uid: "user_" + phone,
            displayName: name,
            phoneNumber: phone
        };
        localStorage.setItem("vidya_user", JSON.stringify(currentUser));
        updateAuthUI(currentUser);

        // Pre-fill booking form
        if ($("studentName")) $("studentName").value = name;
        if ($("studentPhone")) $("studentPhone").value = phone;

        toast(`रजिस्ट्रेशन सफल! स्वागत है, ${name}`, "success");
        go("booking");

    } else {
        // LOGIN MODE: Strict Security Verification
        let userFound = registeredUsers[phone];

        try {
            const snap = await get(child(ref(db), "users/" + phone));
            if (snap.exists()) {
                userFound = snap.val();
                registeredUsers[phone] = userFound;
                saveLocalData();
            }
        } catch (err) {
            console.warn("Firebase get user notice:", err.message);
        }

        if (!userFound) {
            toast("❌ यह मोबाइल नंबर रजिस्टर्ड नहीं है। कृपया पहले 'नया रजिस्ट्रेशन' करें।", "error");
            setAuthMode("register");
            if ($("authPhone")) $("authPhone").value = phone;
            $("authName")?.focus();
            return;
        }

        if (userFound.password !== password) {
            toast("❌ गलत पासवर्ड! कृपया सही पासवर्ड दर्ज करें या नीचे 'पासवर्ड भूल गए?' पर क्लिक करें।", "error");
            $("authPassword")?.focus();
            return;
        }

        // Login Verified!
        currentUser = {
            uid: "user_" + phone,
            displayName: userFound.name,
            phoneNumber: phone
        };
        localStorage.setItem("vidya_user", JSON.stringify(currentUser));
        updateAuthUI(currentUser);
        toast(`लॉगिन सफल! स्वागत है, ${currentUser.displayName}`, "success");

        // Load their bookings
        loadUserBookingsFromFirebase(phone);

        // Pre-fill booking form
        if ($("studentName")) $("studentName").value = userFound.name || "";
        if ($("studentPhone")) $("studentPhone").value = phone;

        go("booking");
    }
}

async function sendForgotOTP() {
    const phone = normalisePhone(value("forgotPhone"));
    if (!/^[6-9]\d{9}$/.test(phone)) {
        toast("कृपया पहले सही 10 अंकों का मोबाइल नंबर भरें।", "error");
        $("forgotPhone")?.focus();
        return;
    }

    let userFound = registeredUsers[phone];
    if (!userFound) {
        try {
            const snap = await get(child(ref(db), "users/" + phone));
            if (snap.exists()) userFound = snap.val();
        } catch (e) {}
    }

    if (!userFound) {
        toast("यह मोबाइल नंबर रजिस्टर्ड नहीं है। कृपया पहले नया रजिस्ट्रेशन करें।", "error");
        setAuthMode("register");
        if ($("authPhone")) $("authPhone").value = phone;
        return;
    }

    activeGeneratedOtp = String(Math.floor(1000 + Math.random() * 9000));
    const otpInput = $("forgotOtp");
    if (otpInput) otpInput.value = activeGeneratedOtp;

    toast(`सुरक्षा OTP कोड: ${activeGeneratedOtp} (ऑटो-फिल कर दिया गया है)`, "success");
}

async function handleForgotSubmit(e) {
    e.preventDefault();
    const phone = normalisePhone(value("forgotPhone"));
    const enteredOtp = value("forgotOtp").trim();
    const newPass = value("forgotNewPassword").trim();

    if (!/^[6-9]\d{9}$/.test(phone)) {
        toast("कृपया सही 10 अंकों का मोबाइल नंबर दर्ज करें।", "error");
        return;
    }

    if (!activeGeneratedOtp || enteredOtp !== activeGeneratedOtp) {
        toast("अमान्य OTP कोड! कृपया 'OTP भेजें' पर क्लिक करके सही कोड दर्ज करें।", "error");
        return;
    }

    if (newPass.length < 4) {
        toast("नया पासवर्ड कम से कम 4 अक्षर/अंकों का होना चाहिए।", "error");
        $("forgotNewPassword")?.focus();
        return;
    }

    try {
        await update(ref(db, "users/" + phone), {
            password: newPass,
            passwordResetAt: Date.now()
        });
        console.log("Password updated in Firebase for:", phone);
    } catch (fbErr) {
        console.warn("Firebase password reset notice:", fbErr);
    }

    if (registeredUsers[phone]) {
        registeredUsers[phone].password = newPass;
    } else {
        registeredUsers[phone] = { name: "User", phone, password: newPass };
    }
    saveLocalData();

    currentUser = {
        uid: "user_" + phone,
        displayName: registeredUsers[phone].name,
        phoneNumber: phone
    };
    localStorage.setItem("vidya_user", JSON.stringify(currentUser));
    updateAuthUI(currentUser);

    activeGeneratedOtp = null;
    toast("पासवर्ड सफलतापूर्वक बदल गया! आप लॉगिन हो चुके हैं।", "success");
    setAuthMode("login");
    go("booking");
}

function logout() {
    currentUser = null;
    myBookings = [];
    localStorage.removeItem("vidya_user");
    localStorage.removeItem("vidya_bookings");
    updateAuthUI(null);
    renderHistory();
    toast("आप सफलतापूर्वक Logout हो गए हैं।");
    go("home");
}

function updateAuthUI(user) {
    const authSec = $("authCardSection");
    const profSec = $("profileCardSection");

    if (authSec && profSec) {
        authSec.style.display = user ? "none" : "block";
        profSec.style.display = user ? "block" : "none";
    }

    if (user) {
        if ($("studentName") && !$("studentName").value) $("studentName").value = user.displayName || "";
        if ($("studentPhone") && !$("studentPhone").value && user.phoneNumber) $("studentPhone").value = user.phoneNumber;
        if ($("lockerStudentName") && !$("lockerStudentName").value) $("lockerStudentName").value = user.displayName || "";
        if ($("lockerStudentPhone") && !$("lockerStudentPhone").value && user.phoneNumber) $("lockerStudentPhone").value = user.phoneNumber;
        if ($("complaintStudentName") && !$("complaintStudentName").value) $("complaintStudentName").value = user.displayName || "";
        if ($("complaintStudentPhone") && !$("complaintStudentPhone").value && user.phoneNumber) $("complaintStudentPhone").value = user.phoneNumber;
        const myActiveSeat = (myBookings || []).find(b => (b.assignedSeat || b.requestedSeat));
        if (myActiveSeat && $("complaintSeatNo") && !$("complaintSeatNo").value) {
            $("complaintSeatNo").value = String(myActiveSeat.assignedSeat || myActiveSeat.requestedSeat);
        }
        renderStudentComplaints();
    }

    text("profileName", user?.displayName || "अतिथि विद्यार्थी");
    text("profilePhone", user?.phoneNumber || "अभी लॉगिन नहीं किया");
    text("profileStatus", user ? "लॉगिन है (Active)" : "अतिथि मोड");
    if (user && user.phoneNumber) {
        const dStat = getStudentDepositStatus(user.phoneNumber);
        if (dStat === "active_held") {
            text("profileDepositStatus", "🟢 ₹300 जमा है (2nd, 3rd बुकिंग पर ₹0 देय)");
        } else if (dStat === "refunded") {
            text("profileDepositStatus", "↩️ ₹300 रिफंडेड (पुनः जुड़ने पर ₹300 देय)");
        } else {
            text("profileDepositStatus", "⚪ पहली बार ₹300 देय (रिफंडेबल)");
        }
        renderDepositBadge(user.phoneNumber, dStat);
        updateSummary();
    } else {
        text("profileDepositStatus", "अतिथि (पहली बार ₹300 देय)");
    }

    const avatar = $("profileAvatar");
    if (avatar) {
        avatar.textContent = (user?.displayName || "वि").charAt(0).toUpperCase();
    }
}

/* ================= BOOKING FLOW ================= */
function getPaymentArea(parentId) {
    let area = $("paymentArea");
    if (!area) {
        area = document.createElement("div");
        area.id = "paymentArea";
        area.className = "card";
    }
    const parent = $(parentId);
    if (parent && area.parentElement !== parent) {
        parent.appendChild(area);
    }
    area.hidden = false;
    area.style.display = "block";
    return area;
}

function prepareBooking() {
    const name = String(value("studentName") || currentUser?.displayName || "").trim();
    const phone = normalisePhone(value("studentPhone") || currentUser?.phoneNumber || "");
    const startDate = selectedStartDate();
    const plan = selectedPlan();
    const months = Number(selectedMonths());

    if (name.length < 2) {
        toast("कृपया विद्यार्थी का पूरा नाम दर्ज करें।", "error");
        go("booking");
        $("studentName")?.focus();
        return;
    }

    if (!/^[6-9]\d{9}$/.test(phone)) {
        toast("कृपया सही 10 अंकों का WhatsApp मोबाइल नंबर दर्ज करें।", "error");
        go("booking");
        $("studentPhone")?.focus();
        return;
    }

    // Auto-authenticate student seamlessly without kicking to login
    if (!currentUser || currentUser.phoneNumber !== phone) {
        currentUser = {
            uid: "user_" + phone,
            displayName: name,
            phoneNumber: phone
        };
        if (!registeredUsers[phone]) {
            registeredUsers[phone] = {
                name,
                phone,
                password: phone.slice(-4),
                createdAt: Date.now()
            };
        }
        localStorage.setItem("vidya_user", JSON.stringify(currentUser));
        saveLocalData();
        updateAuthUI(currentUser);
    }

    if ((currentBookingType === "seat" || currentBookingType === "seat_and_locker") && plan === "Reserved" && !selectedSeat) {
        toast("Reserved Plan के लिए कृपया पहले फ्लोर मैप में अपनी सीट चुनें।", "error");
        go("booking");
        return;
    }

    if ((currentBookingType === "locker_only" || currentBookingType === "seat_and_locker") && !selectedLocker) {
        toast("कृपया उपलब्ध लॉकर (हरा बॉक्स) चुनें।", "error");
        go("booking");
        $("lockerSelectionCard")?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
    }

    const amount = calculateBookingAmount();

    const validity = calculateValidity(startDate, months);

    currentBookingDraft = {
        name,
        phone,
        startDate,
        endDate: validity.endDateFormatted,
        endDateISO: validity.endDate,
        totalDays: validity.totalDays,
        validitySummary: validity.summaryText,
        plan,
        months,
        seatPreference: selectedSeat,
        seatAssignment: plan === "Reserved" ? "reserved_fixed" : (selectedSeat ? "requested" : "admin_to_assign"),
        locker: selectedLocker,
        bookingType: currentBookingType,
        ...amount
    };

    // Render payment directly on current active page
    const activePage = document.querySelector(".page.active")?.id || "booking";
    showPaymentPanel(currentBookingDraft, activePage);
}

function showPaymentPanel(draft, targetPageId = "booking") {
    let paymentArea = (targetPageId === "fees") ? $("paymentArea") : $("bookingPaymentArea");
    if (!paymentArea) paymentArea = getPaymentArea(targetPageId);
    const method = value("payMethod", "UPI");

    const amtStr = draft.total.toFixed(2);
    const txnNote = `VL-Seat-${draft.total}`;
    
    // Standard UPI Intent
    const upiUrl = `upi://pay?pa=${UPI_ID}&pn=${encodeURIComponent(PAYEE_NAME)}&am=${amtStr}&cu=INR&tn=${encodeURIComponent(txnNote)}`;
    const gpayUrl = `tez://upi/pay?pa=${UPI_ID}&pn=${encodeURIComponent(PAYEE_NAME)}&am=${amtStr}&cu=INR&tn=${encodeURIComponent(txnNote)}`;
    const phonepeUrl = `phonepe://pay?pa=${UPI_ID}&pn=${encodeURIComponent(PAYEE_NAME)}&am=${amtStr}&cu=INR&tn=${encodeURIComponent(txnNote)}`;
    const paytmUrl = `paytmmp://pay?pa=${UPI_ID}&pn=${encodeURIComponent(PAYEE_NAME)}&am=${amtStr}&cu=INR&tn=${encodeURIComponent(txnNote)}`;

    let contentHTML = "";

    if (method === "cash") {
        contentHTML = `
            <div class="payment-card" style="border:2px solid #22c55e;">
                <h3 style="color:#15803d; margin-bottom: 4px; display:flex; align-items:center; gap:8px;">
                    <span>💵</span> नकद भुगतान बुकिंग (Cash Payment at Counter)
                </h3>
                <p class="small muted" style="margin-top:0;">विद्या लाइब्रेरी राजनांदगांव · The Study Zone</p>

                <div class="summary-row"><span>विद्यार्थी का नाम:</span> <b>${escapeHTML(draft.name)}</b></div>
                <div class="summary-row"><span>मोबाइल नं:</span> <b>${escapeHTML(draft.phone)}</b></div>
                <div class="summary-row"><span>समय स्लॉट व अवधि:</span> <b>${escapeHTML(draft.plan)} (${draft.months} माह / ${draft.totalDays} दिन)</b></div>
                <div class="summary-row"><span>सीट विवरण:</span> <b>${draft.seatPreference ? "Seat " + draft.seatPreference : (draft.bookingType === 'locker_only' ? 'केवल लॉकर' : 'काउंटर द्वारा आवंटित')}</b></div>
                ${draft.locker ? `<div class="summary-row"><span>निजी लॉकर:</span> <b>Locker L${draft.locker}</b></div>` : ''}
                <div class="summary-row"><span>प्रारंभ तिथि:</span> <b>${escapeHTML(draft.startDate)}</b></div>
                <div class="summary-row" style="background:#eef2ff; border-radius:8px; padding:8px 10px;">
                    <span>वैधता (Ending Date):</span> 
                    <b style="color:var(--navy);">${escapeHTML(draft.endDate)} (पूरे ${draft.totalDays} दिन)</b>
                </div>
                <div class="summary-row summary-total" style="background:#f0fdf4; border-color:#86efac;">
                    <span style="color:#15803d;">कुल नकद देय राशि:</span> 
                    <b style="color:#15803d; font-size:22px;">${money(draft.total)}</b>
                </div>

                <div class="cash-instructions" style="background:#f8fafc; border:1.5px solid #cbd5e1; border-radius:12px; padding:14px; margin:16px 0; text-align:left;">
                    <div style="font-weight:800; color:var(--navy); margin-bottom:6px; font-size:14px;">
                        📍 नकद जमा करने का स्थान:
                    </div>
                    <p style="margin:0 0 6px; font-size:13px; color:#334155;">
                        <b>विद्या लाइब्रेरी काउंटर (प्रथम तल)</b><br>
                        शिव टॉवर, दिग्विजय कॉलेज के पास, दुर्गा मंदिर के सामने, राजनांदगांव (छ.ग.)<br>
                        हेल्पलाइन: <b>9111701828, 7000545675</b>
                    </p>
                    <div style="font-size:12px; color:#166534; background:#dcfce7; padding:8px 10px; border-radius:6px; border:1px solid #86efac; margin-top:8px;">
                        ✓ <b>कोई UTR की आवश्यकता नहीं:</b> नीचे दिए गए बटन पर क्लिक करते ही आपकी सीट बुक हो जाएगी और आधिकारिक डिजिटल रसीद तुरंत कटकर डाउनलोड के लिए तैयार हो जाएगी।
                    </div>
                </div>

                <button type="button" id="submitBookingBtn" class="btn btn-success full" style="font-size:16px; padding:15px; margin-top:10px;">
                    ✅ नकद बुकिंग दर्ज करें व डिजिटल रसीद प्राप्त करें (₹${draft.total}) →
                </button>
                <p class="secure-note" style="text-align:center; font-size:11.5px; color:#64748b; margin-top:8px;">
                    रिफंडेबल सिक्योरिटी डिपॉजिट ₹300 सहित। रसीद कटने के बाद आप काउंटर पर नकद देकर अध्ययन प्रारंभ कर सकते हैं।
                </p>
            </div>
        `;
    } else {
        contentHTML = `
            <div class="payment-card">
                <h3 style="color:var(--navy); margin-bottom: 4px;">💳 सीधा ऑनलाइन भुगतान (Direct UPI Payment)</h3>
                <p class="small muted" style="margin-top:0;">विद्या लाइब्रेरी राजनांदगांव · The Study Zone</p>

                <div class="summary-row"><span>विद्यार्थी का नाम:</span> <b>${escapeHTML(draft.name)}</b></div>
                <div class="summary-row"><span>मोबाइल नं:</span> <b>${escapeHTML(draft.phone)}</b></div>
                <div class="summary-row"><span>समय स्लॉट व अवधि:</span> <b>${escapeHTML(draft.plan)} (${draft.months} माह / ${draft.totalDays} दिन)</b></div>
                <div class="summary-row"><span>सीट विवरण:</span> <b>${draft.seatPreference ? "Seat " + draft.seatPreference : (draft.bookingType === 'locker_only' ? 'केवल लॉकर' : 'लाइब्रेरी द्वारा आवंटित')}</b></div>
                ${draft.locker ? `<div class="summary-row"><span>निजी लॉकर:</span> <b>Locker L${draft.locker}</b></div>` : ''}
                <div class="summary-row"><span>प्रारंभ तिथि:</span> <b>${escapeHTML(draft.startDate)}</b></div>
                <div class="summary-row" style="background:#eef2ff; border-radius:8px; padding:8px 10px;">
                    <span>वैधता (Ending Date):</span> 
                    <b style="color:var(--navy);">${escapeHTML(draft.endDate)} (पूरे ${draft.totalDays} दिन)</b>
                </div>
                <div class="summary-row"><span>सीट प्लान फीस:</span> <b>${money(draft.baseFee)}</b></div>
                ${draft.lockerFee ? `<div class="summary-row"><span>लॉकर फीस:</span> <b>${money(draft.lockerFee)}</b></div>` : ''}
                <div class="summary-row" style="background:${draft.deposit > 0 ? '#eff6ff' : '#f0fdf4'}; padding:6px 10px; border-radius:6px; margin:4px 0;">
                    <span>सिक्योरिटी डिपॉजिट (रिफंडेबल):</span> 
                    <b style="color:${draft.deposit > 0 ? '#1e40af' : '#15803d'};">
                        ${draft.deposit > 0 ? "₹300 (केवल 1st बुकिंग पर देय)" : "₹0 (पूर्व से सुरक्षित जमा ✓ · 2nd/3rd बुकिंग पर ₹0)"}
                    </b>
                </div>
                <div class="summary-row summary-total"><span>कुल देय राशि:</span> <b>${money(draft.total)}</b></div>

                <div class="direct-pay-box">
                    <div class="exact-amount-pill">
                        ⚡ सटीक देय राशि: <b>${money(draft.total)}</b>
                    </div>
                    <p class="small muted" style="margin: 6px 0 12px; text-align:center;">
                        नीचे दिए गए बटन पर क्लिक करें, सीधे PhonePe या Google Pay खुलेगा और उसमें <b>₹${draft.total}</b> की सटीक राशि अपने-आप सेट रहेगी:
                    </p>

                    <!-- DIRECT GPAY & PHONEPE BUTTONS -->
                    <div class="upi-buttons-grid">
                        <a href="${phonepeUrl}" class="btn btn-pay-phonepe full" style="text-decoration:none;">
                            <span class="pay-app-icon">🟣</span> <b>PhonePe से ₹${draft.total} पे करें</b>
                        </a>

                        <a href="${gpayUrl}" class="btn btn-pay-gpay full" style="text-decoration:none;">
                            <span class="pay-app-icon">🌐</span> <b>Google Pay से ₹${draft.total} पे करें</b>
                        </a>

                        <a href="${paytmUrl}" class="btn btn-pay-anyupi full" style="text-decoration:none; background:#002970;">
                            <span class="pay-app-icon">🔷</span> <b>Paytm से ₹${draft.total} पे करें</b>
                        </a>

                        <a href="${upiUrl}" class="btn btn-pay-anyupi full" style="text-decoration:none;">
                            <span class="pay-app-icon">📲</span> <b>BHIM / अन्य UPI ऐप से पे करें</b>
                        </a>
                    </div>

                    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; margin-top:14px; padding-top:10px; border-top:1px dashed #c7ccff;">
                        <div class="upi-pill" style="margin:0;">
                            <span>UPI ID: <b>${UPI_ID}</b></span>
                            <span class="copy-badge" onclick="copyUPI()">कॉपी करें</span>
                        </div>
                        <button type="button" class="btn btn-outline" style="padding:6px 12px; font-size:12px;" onclick="togglePayQrCode('${draft.total}')">
                            📱 कंप्यूटर / QR कोड से स्कैन करें
                        </button>
                    </div>

                    <div id="dynamicPayQrArea" style="display:none; margin-top:14px; text-align:center; padding:14px; background:#ffffff; border-radius:12px; border:1px solid #d5daf5;">
                        <p style="font-weight:700; color:var(--navy); font-size:13px; margin:0 0 6px;">
                            यदि आप कंप्यूटर या लैपटॉप पर हैं, तो मोबाइल से QR स्कैन करें:
                        </p>
                        <img id="dynamicPayQrImg" src="https://api.qrserver.com/v1/create-qr-code/?size=170x170&data=${encodeURIComponent(upiUrl)}" alt="UPI QR" style="width:160px; height:160px; margin:auto; border:1px solid #ccc; border-radius:10px; display:block;">
                        <small style="display:block; margin-top:4px; color:#555;">सटीक राशि: <b>${money(draft.total)}</b></small>
                    </div>
                </div>

                <!-- STRICT 12-DIGIT UTR VALIDATION SECTION -->
                <div class="field" style="margin-top:16px;">
                    <label for="paymentUtr" style="color:var(--navy); font-size:13px; font-weight:800;">
                        🔒 भुगतान के बाद 12 अंकों का असली UPI UTR / Ref No. दर्ज करें:
                    </label>
                    <input id="paymentUtr" type="text" maxlength="12" inputmode="numeric" 
                           placeholder="PhonePe/GPay से 12 अंकों का UTR (उदा. 429182749102)" required 
                           style="font-size:16px; font-weight:700; letter-spacing:1px;">
                    <small class="muted" style="display:block; margin-top:4px; font-size:11px;">
                        ⚠️ <b>सुरक्षा नियम:</b> केवल इसी ₹${draft.total} भुगतान का 12 अंकों का असली UTR ही स्वीकार होगा।
                    </small>
                </div>

                <button type="button" id="submitBookingBtn" class="btn btn-primary full" style="font-size:15px; margin-top:10px;">
                    ✅ ₹${draft.total} UTR सबमिट करें व डिजिटल रसीद प्राप्त करें →
                </button>
                <p class="secure-note" style="text-align:center;">
                    डिपॉजिट ₹300 रिफंडेबल है। बैंक खाते में सत्यापन के बाद सीट कन्फर्म रहेगी।
                </p>
            </div>
        `;
    }

    paymentArea.innerHTML = contentHTML;
    paymentArea.hidden = false;
    paymentArea.style.display = "block";

    $("submitBookingBtn")?.addEventListener("click", submitBooking);
    paymentArea.scrollIntoView({ behavior: "smooth", block: "start" });
}

function copyUPI() {
    navigator.clipboard?.writeText(UPI_ID).then(() => {
        toast("UPI ID कॉपी हो गई: " + UPI_ID, "success");
    }).catch(() => {
        toast("UPI ID: " + UPI_ID);
    });
}


/* ================= SEQUENTIAL RECEIPT SL. NO. COUNTER (1, 2, 3...) ================= */
async function getNextReceiptNumber() {
    let maxExisting = 0;

    // 1. Check in-memory arrays (both admin requests and personal bookings)
    const allKnown = [...(allAdminRequests || []), ...(myBookings || [])];
    allKnown.forEach(b => {
        const n = Number(b.slNo || b.regNum);
        if (!isNaN(n) && n > maxExisting && n < 50000) {
            maxExisting = n;
        }
    });

    // 2. Check Firebase Realtime Database counter
    try {
        const snap = await get(child(ref(db), "public/counters/receiptCounter"));
        if (snap.exists()) {
            const fbVal = Number(snap.val());
            if (!isNaN(fbVal) && fbVal > maxExisting && fbVal < 50000) {
                maxExisting = fbVal;
            }
        }
    } catch (e) {
        console.warn("Firebase counter read notice:", e);
    }

    // 3. Check LocalStorage fallback
    const localVal = Number(localStorage.getItem("vidya_receipt_sl_counter") || 0);
    if (!isNaN(localVal) && localVal > maxExisting && localVal < 50000) {
        maxExisting = localVal;
    }

    // Next receipt number starts at 1, then 2, 3, 4, 5...
    const nextNum = maxExisting + 1;

    // 4. Atomically persist updated counter to Firebase & LocalStorage
    try {
        await set(ref(db, "public/counters/receiptCounter"), nextNum);
    } catch (e) {
        console.warn("Firebase counter write notice:", e);
    }
    localStorage.setItem("vidya_receipt_sl_counter", String(nextNum));

    console.log("Generated next sequential receipt Sl. No.:", nextNum);
    return nextNum;
}
window.getNextReceiptNumber = getNextReceiptNumber;

/* ================= SUBMIT SEAT BOOKING TO FIREBASE ================= */
async function submitBooking() {
    if (!currentUser || !currentBookingDraft) {
        toast("पहले बुकिंग तैयार करें।", "error");
        return;
    }

    const draft = currentBookingDraft;
    const method = value("payMethod", "UPI");
    let utr = "";

    if (method === "UPI") {
        utr = String(value("paymentUtr")).trim().replace(/\s+/g, "");

        // 1. Strict 12-digit validation
        if (!/^\d{12}$/.test(utr)) {
            toast("❌ अमान्य UTR! कृपया PhonePe/GPay से 12 अंकों का शुद्ध नंबर (UTR) दर्ज करें।", "error");
            $("paymentUtr")?.focus();
            return;
        }

        // 2. Reject obvious fake numbers
        if (/^(\d)\1{11}$/.test(utr) || utr === "123456789012" || utr === "012345678901") {
            toast("❌ यह फ़र्ज़ी UTR नंबर है! कृपया अपने असली ट्रांजैक्शन का UTR नंबर भरें।", "error");
            $("paymentUtr")?.focus();
            return;
        }

        // 3. Block reused/duplicate UTRs
        if (usedUtrs[utr]) {
            toast(`❌ यह UTR (${utr}) पहले ही उपयोग किया जा चुका है!`, "error");
            $("paymentUtr")?.focus();
            return;
        }

        // Record UTR as used
        usedUtrs[utr] = {
            amount: draft.total,
            phone: draft.phone,
            date: Date.now()
        };
    } else {
        // Cash Payment at Library Counter
        utr = "CASH_COUNTER";
    }

    const slNo = await getNextReceiptNumber();
    const regNum = String(slNo);
    const bookingId = "VL" + Math.floor(100000 + Math.random() * 900000);
    const record = {
        bookingId,
        slNo,
        regNum,
        uid: currentUser.uid,
        studentName: draft.name,
        studentPhone: draft.phone,
        plan: draft.plan,
        months: draft.months,
        startDate: draft.startDate,
        endDate: draft.endDate,
        endDateISO: draft.endDateISO,
        totalDays: draft.totalDays,
        baseFee: draft.baseFee,
        lockerFee: draft.lockerFee,
        refundableDeposit: draft.deposit,
        totalAmount: draft.total,
        bookingType: draft.bookingType || "seat",
        requestedSeat: draft.seatPreference,
        assignedSeat: draft.plan === "Reserved" ? draft.seatPreference : null,
        locker: draft.locker,
        assignedLocker: draft.locker,
        paymentMethod: method === "cash" ? "नकद (Cash Counter)" : "UPI Online",
        utr: utr,
        paymentStatus: method === "UPI" ? "submitted_for_verification" : "cash_pending",
        status: "confirmed",
        depositPaid: true,
        depositStatusAtBooking: (draft.deposit > 0 ? "newly_paid" : "already_active"),
        createdAt: Date.now()
    };

    if (draft.seatPreference) {
        availability.seats[String(draft.seatPreference)] = "reserved";
    }
    if (draft.locker) {
        availability.lockers[String(draft.locker)] = "reserved";
    }

    // 1. Save to Firebase Realtime Database
    try {
        const updates = {};
        updates[`users/${draft.phone}/bookings/${bookingId}`] = record;
        updates[`users/${draft.phone}/depositStatus`] = 'active_held';
        updates[`users/${draft.phone}/name`] = draft.name;
        updates[`bookingRequests/${bookingId}`] = record;
        if (draft.seatPreference) {
            updates[`public/availability/seats/${draft.seatPreference}`] = "reserved";
        }
        if (draft.locker) {
            updates[`public/availability/lockers/${draft.locker}`] = "reserved";
        }
        await update(ref(db), updates);
        console.log("Booking saved to Firebase Realtime DB:", bookingId);
    } catch (fbErr) {
        console.warn("Firebase booking save notice:", fbErr.message);
    }

    // 2. Save locally
    if (draft.phone) {
        if (!registeredUsers[draft.phone]) registeredUsers[draft.phone] = { phone: draft.phone, name: draft.name };
        registeredUsers[draft.phone].depositStatus = 'active_held';
    }
    // Only add to myBookings if it belongs to the active currentUser
    if (currentUser && normalisePhone(currentUser.phoneNumber) === normalisePhone(draft.phone)) {
        myBookings.unshift(record);
    }
    allAdminRequests.unshift(record);
    saveLocalData();

    // Auto-sync to Google Sheets webhook if configured
    syncBookingToGoogleSheets(record);

    // 3. Render success card on booking page
    const successCardHTML = `
        <div style="text-align:center; padding: 24px 16px; background:#ffffff; border:2.5px solid #18833b; border-radius:18px; box-shadow:0 10px 35px rgba(24,131,59,0.18);">
            <div style="font-size: 52px; margin-bottom: 8px;">🎉</div>
            <h3 style="color:var(--green); margin:0 0 6px; font-size:22px; font-weight:900;">
                ${method === 'cash' ? 'नकद बुकिंग सफलतापूर्वक दर्ज हो गई!' : 'ऑनलाइन पेमेंट बुकिंग सफलतापूर्वक दर्ज!'}
            </h3>
            <p style="font-size:16px; margin:4px 0;">पंजीकरण क्रमांक: <b style="color:var(--red); font-size:22px;">Reg. No. A. ${record.regNum}</b></p>
            <p class="small muted" style="margin:8px 0 16px; font-size:13.5px; line-height:1.7;">
                विद्यार्थी: <b>${escapeHTML(draft.name)}</b> | मोबाइल: <b>${escapeHTML(draft.phone)}</b><br>
                सीट: <b>${draft.plan === 'Reserved' && draft.seatPreference ? 'Seat ' + draft.seatPreference : (draft.bookingType === 'locker_only' ? 'केवल लॉकर' : 'काउंटर द्वारा आवंटित')}</b>
                ${draft.locker ? ` | लॉकर: <b>L${draft.locker}</b>` : ''}<br>
                वैधता: <b>${draft.startDate} से ${draft.endDate} (${draft.totalDays} दिन)</b><br>
                कुल देय राशि: <b style="color:var(--navy); font-size:17px;">${money(draft.total)}</b> 
                (${method === 'cash' ? 'नकद काउंटर भुगतान' : 'UPI ऑनलाइन'})
            </p>

            <div style="display:flex; flex-direction:column; gap:10px; margin: 20px 0;">
                <button type="button" class="btn btn-primary full" style="font-size:15px; padding:14px;" onclick="printReceipt('${bookingId}')">
                    📄 आधिकारिक डिजिटल रसीद देखें व PDF डाउनलोड करें
                </button>
                
                <button type="button" class="btn btn-success full" style="font-size:14px; padding:13px;" onclick="sendReceiptToWhatsApp('${bookingId}')">
                    💬 सीधे WhatsApp पर रसीद भेजें
                </button>

                <button type="button" class="btn btn-outline full" onclick="go('profile')">
                    👤 मेरी प्रोफाइल व बुकिंग हिस्ट्री देखें →
                </button>
            </div>

            <p style="font-size:11.5px; color:#64748b; margin:0;">
                ✓ आपकी आधिकारिक रसीद तैयार है। आप नीचे डाउनलोड कर सकते हैं या 'मेरी प्रोफाइल' में सुरक्षित रख सकते हैं।
            </p>
        </div>
    `;

    const bArea = $("bookingPaymentArea");
    if (bArea) {
        bArea.innerHTML = successCardHTML;
        bArea.hidden = false;
        bArea.style.display = "block";
        bArea.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }

    renderSeatGrid();
    renderLockerGrid();
    renderHistory();
    toast("बुकिंग दर्ज! आधिकारिक रसीद तैयार है।", "success");

    // Automatically open the official receipt modal so the student can view & download PDF immediately!
    setTimeout(() => {
        printReceipt(bookingId);
    }, 600);
}

/* ================= LOCKER BOOKING TO FIREBASE ================= */
function saveLocker() {
    if (!currentUser) {
        toast("लॉकर बुक करने से पहले कृपया लॉगिन करें।", "error");
        go("login");
        return;
    }

    const name = String(value("lockerStudentName") || currentUser.displayName || "").trim();
    const phone = normalisePhone(value("lockerStudentPhone") || currentUser.phoneNumber || "");
    const months = Number(value("lockerMonths", "1"));
    const startDate = value("lockerStartDate", todayDate());
    const locker = selectedLocker;

    if (name.length < 2) {
        toast("कृपया पूरा नाम दर्ज करें।", "error");
        $("lockerStudentName")?.focus();
        return;
    }
    if (!/^[6-9]\d{9}$/.test(phone)) {
        toast("सही 10 अंकों का मोबाइल नंबर दर्ज करें।", "error");
        $("lockerStudentPhone")?.focus();
        return;
    }
    if (!locker) {
        toast("कृपया उपलब्ध लॉकर (हरा बॉक्स) चुनें।", "error");
        return;
    }

    const total = 100; // Flat ₹100 per locker
    const lockerVal = calculateValidity(startDate, months);
    currentLockerDraft = { 
        name, phone, locker, months, startDate, 
        endDate: lockerVal.endDateFormatted,
        totalDays: lockerVal.totalDays,
        total 
    };

    showLockerPayment(currentLockerDraft);
}

function showLockerPayment(draft) {
    const area = $("lockerPaymentArea");
    if (!area) return;

    area.hidden = false;
    area.style.display = "block";

    const amtStr = draft.total.toFixed(2);
    const txnNote = `VL-Locker-${draft.locker}`;
    const upiUrl = `upi://pay?pa=${UPI_ID}&pn=${encodeURIComponent(PAYEE_NAME)}&am=${amtStr}&cu=INR&tn=${encodeURIComponent(txnNote)}`;
    const phonepeUrl = `phonepe://pay?pa=${UPI_ID}&pn=${encodeURIComponent(PAYEE_NAME)}&am=${amtStr}&cu=INR&tn=${encodeURIComponent(txnNote)}`;
    const gpayUrl = `tez://upi/pay?pa=${UPI_ID}&pn=${encodeURIComponent(PAYEE_NAME)}&am=${amtStr}&cu=INR&tn=${encodeURIComponent(txnNote)}`;

    area.innerHTML = `
        <div class="payment-card">
            <h3 style="color:var(--navy);">🔐 सीधा लॉकर पेमेंट: Locker L${draft.locker}</h3>
            <div class="summary-row"><span>विद्यार्थी:</span> <b>${escapeHTML(draft.name)}</b></div>
            <div class="summary-row"><span>अवधि व वैधता:</span> <b>${draft.months} महीने (${draft.totalDays} दिन) - ${draft.startDate} से ${draft.endDate}</b></div>
            <div class="summary-row summary-total"><span>लॉकर फीस:</span> <b>${money(draft.total)}</b></div>

            <div class="direct-pay-box">
                <div class="exact-amount-pill">देय राशि: <b>${money(draft.total)}</b></div>
                <div class="upi-buttons-grid" style="margin-top:10px;">
                    <a href="${phonepeUrl}" onclick="window.location.href='${upiUrl}'" class="btn btn-pay-phonepe full" style="text-decoration:none;">
                        🟣 PhonePe से ₹${draft.total} पे करें
                    </a>
                    <a href="${gpayUrl}" onclick="window.location.href='${upiUrl}'" class="btn btn-pay-gpay full" style="text-decoration:none;">
                        🌐 Google Pay से ₹${draft.total} पे करें
                    </a>
                </div>
                <div class="upi-pill" style="margin-top:10px; justify-content:center;">
                    <span>UPI ID: <b>${UPI_ID}</b></span>
                    <span class="copy-badge" onclick="copyUPI()">कॉपी करें</span>
                </div>
            </div>

            <div class="field" style="margin-top:14px;">
                <label for="lockerUTR">भुगतान के बाद 12 अंकों का UTR दर्ज करें:</label>
                <input id="lockerUTR" type="text" maxlength="12" inputmode="numeric" placeholder="12 अंकों का UPI UTR नंबर दर्ज करें" style="font-size:15px; font-weight:700;">
            </div>

            <button type="button" class="btn btn-primary full" onclick="submitLockerWithUTR()">
                ✅ ₹${draft.total} UTR जमा करें व लॉकर बुक करें
            </button>
        </div>
    `;

    area.scrollIntoView({ behavior: "smooth", block: "start" });
}

async function submitLockerWithUTR() {
    if (!currentUser || !currentLockerDraft) return;

    const utr = String(value("lockerUTR")).trim().replace(/\s+/g, "");
    if (!/^\d{12}$/.test(utr)) {
        toast("❌ कृपया 12 अंकों का शुद्ध UPI UTR नंबर भरें।", "error");
        $("lockerUTR")?.focus();
        return;
    }
    if (usedUtrs[utr]) {
        toast("❌ यह UTR पहले ही उपयोग किया जा चुका है!", "error");
        return;
    }
    usedUtrs[utr] = { amount: draft.total, phone: draft.phone, date: Date.now() };

    const draft = currentLockerDraft;
    const bookingId = "LCK" + Math.floor(10000 + Math.random() * 90000);

    const record = {
        bookingId,
        uid: currentUser.uid,
        studentName: draft.name,
        studentPhone: draft.phone,
        bookingType: "locker",
        locker: draft.locker,
        months: draft.months,
        startDate: draft.startDate,
        endDate: draft.endDate,
        totalDays: draft.totalDays,
        lockerFee: draft.total,
        totalAmount: draft.total,
        paymentMethod: "UPI",
        utr,
        status: "confirmed",
        createdAt: Date.now()
    };

    availability.lockers[String(draft.locker)] = "reserved";

    // Save to Firebase
    try {
        const updates = {};
        updates[`users/${draft.phone}/bookings/${bookingId}`] = record;
        updates[`users/${draft.phone}/depositStatus`] = 'active_held';
        updates[`users/${draft.phone}/name`] = draft.name;
        updates[`bookingRequests/${bookingId}`] = record;
        updates[`public/availability/lockers/${draft.locker}`] = "reserved";
        await update(ref(db), updates);
        console.log("Locker saved to Firebase:", bookingId);
    } catch (fbErr) {
        console.warn("Firebase Locker notice:", fbErr.message);
    }

    if (draft.phone) {
        if (!registeredUsers[draft.phone]) registeredUsers[draft.phone] = { phone: draft.phone, name: draft.name };
        registeredUsers[draft.phone].depositStatus = 'active_held';
    }
    // Only add to myBookings if it belongs to the active currentUser
    if (currentUser && normalisePhone(currentUser.phoneNumber) === normalisePhone(draft.phone)) {
        myBookings.unshift(record);
    }
    allAdminRequests.unshift(record);
    saveLocalData();

    toast(`लॉकर L${draft.locker} सफलतापूर्वक Firebase में बुक हो गया!`, "success");
    currentLockerDraft = null;
    selectedLocker = null;
    $("lockerPaymentArea").hidden = true;
    renderLockerGrid();
    renderHistory();
    go("profile");
}

/* ================= RENDER HISTORY & RECEIPTS ================= */
async function loadUserBookingsFromFirebase(phone) {
    if (!phone) return;
    try {
        const snap = await get(child(ref(db), `users/${phone}/bookings`));
        if (snap.exists()) {
            const data = snap.val();
            // Strictly filter and keep only bookings belonging to this student's phone
            const bookingsList = Object.values(data)
                .filter(b => normalisePhone(b.studentPhone) === normalisePhone(phone))
                .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
            myBookings = bookingsList;
        } else {
            // No bookings found in cloud for this student
            myBookings = [];
        }
        saveLocalData();
        renderHistory();
        updateSummary();
        renderDepositBadge(phone, getStudentDepositStatus(phone));
    } catch (err) {
        console.warn("Load bookings notice:", err);
    }
}

function renderHistory() {
    const list = $("historyList");
    if (!list) return;

    if (!currentUser) {
        list.innerHTML = `<div class="empty">अपनी व्यक्तिगत बुकिंग और रसीद देखने के लिए <a href="javascript:go('login')" style="color:var(--navy); font-weight:bold;">यहाँ लॉगिन करें</a>।</div>`;
        return;
    }

    const myPhone = normalisePhone(currentUser.phoneNumber);

    // Strict privacy lock: filter ONLY bookings belonging to the currently logged-in student
    const studentOnlyBookings = (myBookings || []).filter(b => 
        normalisePhone(b.studentPhone) === myPhone
    );

    if (!studentOnlyBookings.length) {
        list.innerHTML = `<div class="empty">आपके नंबर (${myPhone}) पर अभी कोई बुकिंग नहीं है। <a href="javascript:go('booking')" style="color:var(--navy); font-weight:bold;">यहाँ सीट बुक करें</a>।</div>`;
        return;
    }

    list.innerHTML = studentOnlyBookings.map(b => `
        <article class="history-item">
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <strong>${b.bookingType === "locker" ? `🔐 लॉकर L${b.locker}` : `💺 ${escapeHTML(b.plan)} प्लान`}</strong>
                <span class="badge badge-confirmed">Confirmed ✓</span>
            </div>
            <p>बुकिंग ID: <b>${escapeHTML(b.bookingId)}</b> | Reg. No. A: <b>${b.slNo || b.regNum || "—"}</b></p>
            <p>${b.bookingType === "locker" ? `लॉकर: L${b.locker}` : `सीट: ${b.assignedSeat ? "Seat " + b.assignedSeat : (b.requestedSeat ? "Seat " + b.requestedSeat : "काउंटर आवंटन")}`} · अवधि: ${b.months} माह (${b.totalDays || 30} दिन)</p>
            <p>भुगतान राशि: <b>${money(b.totalAmount)}</b> (${escapeHTML(b.paymentMethod || "UPI")})</p>
            <button type="button" class="receipt-btn" onclick="printReceipt('${b.bookingId}')">
                📄 डिजिटल रसीद डाउनलोड / प्रिंट करें
            </button>
        </article>
    `).join("");
}

/* ================= FORMAL RECEIPT & DIRECT PDF DOWNLOAD ================= */
let currentViewingReceiptId = null;

function amountInWords(num) {
    const map = {
        500: "पाँच सौ रुपये मात्र (Five Hundred Only)",
        600: "छह सौ रुपये मात्र (Six Hundred Only)",
        700: "सात सौ रुपये मात्र (Seven Hundred Only)",
        800: "आठ सौ रुपये मात्र (Eight Hundred Only)",
        900: "नौ सौ रुपये मात्र (Nine Hundred Only)",
        1000: "एक हज़ार रुपये मात्र (One Thousand Only)",
        1100: "ग्यारह सौ रुपये मात्र (Eleven Hundred Only)",
        1200: "बारह सौ रुपये मात्र (Twelve Hundred Only)",
        1300: "तेरह सौ रुपये मात्र (Thirteen Hundred Only)",
        1600: "सोलह सौ रुपये मात्र (Sixteen Hundred Only)",
        1800: "अठारह सौ रुपये मात्र (Eighteen Hundred Only)",
        2200: "बाईस सौ रुपये मात्र (Twenty-Two Hundred Only)",
        2400: "चौबीस सौ रुपये मात्र (Twenty-Four Hundred Only)",
        2500: "पच्चीस सौ रुपये मात्र (Twenty-Five Hundred Only)",
        3200: "बत्तीस सौ रुपये मात्र (Thirty-Two Hundred Only)",
        4000: "चार हज़ार रुपये मात्र (Four Thousand Only)",
        4500: "पैंतालीस सौ रुपये मात्र (Forty-Five Hundred Only)",
        5500: "पचपन सौ रुपये मात्र (Fifty-Five Hundred Only)"
    };
    return map[Number(num)] || (Number(num).toLocaleString("en-IN") + " रुपये मात्र");
}
window.amountInWords = amountInWords;

function printReceipt(id) {
    // Look up in personal bookings or admin requests
    let booking = (myBookings || []).find(b => b.bookingId === id);

    // If not found in myBookings, allow lookup from allAdminRequests ONLY if authenticated admin
    if (!booking && isAdminLoggedIn()) {
        booking = (allAdminRequests || []).find(b => b.bookingId === id);
    } else if (!booking) {
        // Fallback: check if matches current student phone
        const foundInAll = (allAdminRequests || []).find(b => b.bookingId === id);
        if (foundInAll && currentUser && normalisePhone(foundInAll.studentPhone) === normalisePhone(currentUser.phoneNumber)) {
            booking = foundInAll;
        }
    }

    if (!booking) {
        toast("🔒 सुरक्षा प्रतिबंध: रसीद केवल वही छात्र देख सकता है जिसने बुक किया है!", "error");
        return;
    }

    // Strict privacy verification: user can only view their own receipt unless logged in as admin
    if (!isAdminLoggedIn() && currentUser && normalisePhone(booking.studentPhone) !== normalisePhone(currentUser.phoneNumber)) {
        toast("🔒 सुरक्षा प्रतिबंध: आप केवल अपनी ही रसीद देख सकते हैं!", "error");
        return;
    }

    currentViewingReceiptId = booking.bookingId;
    const modal = $("receiptModal");
    const container = $("receiptPrintArea");

    if (!modal || !container) {
        toast("रसीद विंडो लोड नहीं हुई।", "error");
        return;
    }

    const bookingDate = new Date(booking.createdAt || Date.now()).toLocaleDateString("en-IN", {
        day: '2-digit', month: 'short', year: 'numeric'
    });

    // Exact Image 2 Physical Receipt Clone with Sequential Sl. No. & Wi-Fi Facility
    const slNo = booking.slNo || booking.regNum || 1;
    const regNo = String(slNo);
    const regDate = booking.startDate || todayDate();
    const renewalDate = booking.endDate || "30 दिन बाद";

    const receiptContent = `
        <div class="phys-receipt-slip half-a4-receipt" id="physReceiptNode">
            <!-- HEADER -->
            <div class="rcpt-header">
                <div class="rcpt-seal-wrap">
                    <img src="assets/vidya_logo.png" class="rcpt-logo-seal" alt="Vidya Library Seal" onerror="this.onerror=null; this.src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAACgCAYAAACLz2ctAAABCGlDQ1BJQ0MgUHJvZmlsZQAAeJxjYGA8wQAELAYMDLl5JUVB7k4KEZFRCuwPGBiBEAwSk4sLGHADoKpv1yBqL+viUYcLcKakFicD6Q9ArFIEtBxopAiQLZIOYWuA2EkQtg2IXV5SUAJkB4DYRSFBzkB2CpCtkY7ETkJiJxcUgdT3ANk2uTmlyQh3M/Ck5oUGA2kOIJZhKGYIYnBncAL5H6IkfxEDg8VXBgbmCQixpJkMDNtbGRgkbiHEVBYwMPC3MDBsO48QQ4RJQWJRIliIBYiZ0tIYGD4tZ2DgjWRgEL7AwMAVDQsIHG5TALvNnSEfCNMZchhSgSKeDHkMyQx6QJYRgwGDIYMZAKbWPz9HbOBQAAC6EklEQVR42uz9d5Bka5reh/2+7zsufVZmZXnTVd1d3bf9deN2djGDBQSziIBAagcAGZQiFCBBBkEAEqkQgAA5MwgFCVBSBEOQ4XIJEJAICJwN/KFAiBQCwM7s7GLsdX1ve2/Ku/SZx3xGf5ys6p5Zi8XuYnexFZFRbaqy6pzzfq99nucV/N7Hr/nDOSd/rV8qhHC/d8d+7+PXZWTOOfk155Rzznvtpf4F3kOcfN97zvlfz/8sJy/xe3f59z5OjES63NDk5O/iV/me4s7OTsk598u9is65ivvyl+Wv9WdPDF3862qY4l8ngwPk5JqdEMK8/v9f+9rX1O1WS/zlL3x2IySUQ61XfSm/MNbWt5Ba4S6UlbqUAUpKvMkbSSCbvCS4CGQMezF8H7ABhAZuR/CzIUTAw5/5mZ+Jv/SlL5kfjtpf/vo31BeAL3zhC1YIYX/PAH93GJ2aXKd5/aF2nWsC01W4kZnsLMg/gLBCO/c5X3jSSan8H7o/FkiBGBhoQ5zEYC2JtsRGY4wBa5Gehx/4WBxKKEyWYjKti2FIas3dYqHU9QPvkxnP+7aDrTLcAw6EENnJz/q6cx7f+Abf+MIX7Fd/Fxuj+F1qeHLinE49iXNO9sbZZ6JAngmU+IyFTxvLZV/K0uvf2z/xaBaX6NSOM4M2BukcqdZiOE7o9vscHB3S7ffIMg1Gk2QZ4yTFWYsQAmO0c84hhCPwfBEEgQzCgOmZGarlKuVikfpUHZOmFKPoYRQG3xuP+h+ODR+LLLv7meXlzZPf6ctf/rJ3+fJl96UvfckC7vcM8Lfhx5e//GX5la98hR8OXS5171jBH5OSd7Q1n/c8VQPQQOwsWkgtcs8mxkCcZmoUJ3T7PQ7aHfYODjk66jDo9RmNRhirERJ0lmG0wfMkSkqkkHhSIYREiFc3VggHQoBzOOfQWltrrXNCoIVzYRjJSrUuG40pwsAnDIO0XCrf86T3C/VW4396Y27u20tCHP0S1+l+Nxij+B3u6U7zOiGEfs37bWD1nzLWflHI4JKUTDMJn4B2FpdKZFdb0R2NZLvXY7/d5qjTozsY0O13idMM5yBJEtI0Q04edRQGVOtVAt/HE4pCFOB7Cl95hEGAUhLhHMKJ3O6EAwfGGrJUk8YJWqck1jLOMkY6dZk2djROLc4RhoEqRKEMwxDfUyOdJLue4B8Xg+AfTQnxz/+dP/pHe697RsB+9atftb9ngL/1xue9XkyMRserhUL181j37xsnbiilygCxdcRpZoynnPOE1NoIrBO91PBi95BnW5ts7e6wtb3FoN/HGEuWJZTKVRaWlmlNN2hNN5hptagWCxSDiHIhRAqBAzwhUCI3Nkn+WbhffGetc+AcGAfOYqQgczB2lrEx9PpDup0+3W7X7ezt2O2tLdfr9z2cpVgqUCpEtqC8vWq9/lONmaV/8GMz9WcbGxsJwL/3Uz/lz29vm9+Jhih+BxreicczAEnSv6ZU+MeVkP8BUs0DZNahsSZxQjglhQTRdY7Nozab2ztsbe1weHhMfzjEOofyvNyzFSIaxQK1UolSuUq1WqdaKzFVKVApFAkFKBwSizepgQ1gcEgE3uR31JPPJyX3SeLmAf6r60ALQTLxzBmQpIbhKKE7GtAfDOj2+67X77vuoOuGg4F0EiGUYjgYJ1L4/5805m95Ufj+X/9f/RtHOCe+/JWvqK9+5SuG30FNcPE7zPB4VVRk/7PMij/rS/EpkEuZzrDaaekpITwlMxBHqWZ/0GO/0+HZ9i5Pt3Y4aneIhyN8T9FsNJienqY1PcV8c5rZSoVmsUC9EBFKgXMgRV5Gq5M62KZYHec3Tvho6aGFQjqJmmRlBkA5pLA4HGbil5RxEMf4GlQUYANFKhxWCqTwkMgfMN4YGBnHYDTmqNPmuNexe51ju3NwrOLYikE/TaX0PkrG478/LcK/9dU/96UBwJedk1/9HZIjit8hhidPc7ws+4KR4j8WUvw+iawkWLIkzaxzyg9DaYVklGraw5gXB3vce/aQe48es71/gEXRaDRZW13h3Po5VhfnqRULBEoQKkVBCKRzqMzgK0GgJFiBtLnXc+MhSfeIdDjACkdYrRFNtRBRCWfJLc+BkLkBOqFxWJyxSAtZf8TRk+fowZDmTItopoEsFxBhBHhYwFryHNJaUmexQuGUwghLYg0jYxnpzL3YPTb3H76Q7aOuHMYjxsPuJ8aMflp0j/+7//tXvzpwzokv/czPyJ/5Rf3G3zPAfxHj8096Y+Nx+4wXFP+CdOrPS6VkjGGUaZ3iZOAHMkAydvBy74B7j57y5MULDjsHJDYjCH2aU03mZ+aZbbWYazRpTTWoBQpvYjdMvJx0LjcYZ5FSogx4TiCGfbbv3+XhzY/oHx5QLBZZuXyV1XfeJWhO4bQFJ3Auzw2RBoRBTooQoS2D5y/48J99k2e379NsNTn37tus3LhMNN0CzwcLzmj0YIhMU1QxhCgEJUF6IARGgEbQNo7tg7Y77vZtu9cXnX5bHvU67O7uvL9zuP2//dp/+tXvAOlPvfeev/2P/tFv2/zQ++3cQBZCZK79tG6Lc/8b6QV/BikX0nHijLLGeL4UvvIEjrGDzXabh882efz0Gc+3dxiOBpRKAavLy5xfX2d9ZYX5Wp0auYFoY5FaI4QAkRuOlOAJUJ7COgHGITBI6eEyQ29rl6cf3uLoxXNqtRrlsMrSG9eheRLs8njtLAgkwpn834yDOEEft+k9e87zDz7isFqlOT3LyoU3QDuscEgkwhiSg126z55ikgS/XKLYmCKaahCUq6hCCGHAlBdQm2uIbK6hYgvt0cA+393habPydvA8+rm/+P/6O/9Dqgd//c++885HQgi+9rWvqS/9NvSG3m8vw0Pkha2wgNbJ6E/hBX9eSvVZrTNspo0KfWVADZ1lpC2jJGFrd4/bt+9w/+FjsswyMzPL9StvcO7MMgvNKSpREd/3CZxFTqpRYTSekEgpcVKCAzvJ3QUWT5AngIbcujxFFEbUw5BEKvwkgTgGo3PPZUEokDJ/5ZeiAIvQGYxGmOGQgnNM+R4FL2CqWCIslnF4kFkIJFjLYGeLW1//p2w/ekxYKrGwvs7MmTNML61QnV8gaEwRVioQhYTSQwmQ5ZIsrJ1hcX7eXrpwwe71u3/y6dOnn/+P/7uf+rvvff/m3/zSl760+7WvfU395E/+pP3thNTxfht5vdMiwzm3YnX2VSnVv4WUQZyMssQYpfyCUjKvPAdZxiePnvDxrdtsbW3icLSmG5xdXWd9aZGFVpO5WoXyxDllzqGdIdEaH4GvPCR5gxhrEULicFhrcIK8eSwFQuYeEk+hAp8oDCj5klA4AjTC6fw9dIYQCpTC4tDOIZzBEw6Uw+iUNI4JnKASBPhKEgQBwg9wwmKdRQiFMAmjzed0798l7LRRvYgXB0ds3r5HfW6B2dUz1OfnqS0vMrW6jD/dJCxEeMInUj6Vki9bpbKcq9ez+XJ1cXfxzF+ZnV78n79548Z/9KUvfelnAb7+9a97X/ziF/XvGeAr48tdBd9Qzrk/BvxN6fkrOhtZ45R2fuBLHzSKTpqx2+3y8OVL3v/kDo8eP8b3FVcvXuAzb77F1bVVmkrlVWuW4LIxDgiDAF94JFg8FJ5UgMNalxcQKk+IBe4HS0cpcpcmAE/miAOjwThcFoNJcxOX5jQHtDiMs0hsHoI9hXGGeDQkjccIY/KfI2T+niL3skJnuG6HeHcX1ekwH/pU6k06GrpxyvDJM55s7xNM1WmuLLNy5RKzVy5QWJhDRUUQCiMcPjAdRH5jdsGuzC7YpbmFSzc/ufU//uW/8/f+H7tbz/7zL37xiwc/9d57/p99553sX3sDPCk0nHNV+MJ/CfxZazRpGhvnK2mE8rSQGCEYJAkPXrzg+x9/zMOnz3HC4+rVK1w8e5b1xXkW6lPUlSIwBj0cMNzeZnx8gBcoqjPzBNMtQj9AGgtZkif+kzrsZKQihQAcxuUjNHEyV5MSPx+VoRxkSUI2HOHSNP9/3wfhEMIghcB3ityVutwwtGXc7zMe9MFaCmGIV4zA9xBS4BkHowGjrW3Sow4qSUnihOXlGucvX8P4IQebOzze3KJ93OF5t0e7fchlm7IWBKimxIsiCsrDSklmDalzsqiUXKlWTPXGjeDyxoW/+OTZk9/X+OmZf/fPvvPO+ycH/19lSPb+FYdcKYTIEte/CvzfgB9Nstho64T1A5VJiZMeMY4X+7vcvHWbuw8f0On1qZcbXLpwkauXNlhptagoSQAERjPe3ubJhx9ycO8uyf4Bfuhz9tp1lt/5FGpuHidEDhqQFqF8cPl8TgFKSHA294pS5iWLA6EUQVCgWCgQegHZOMZpi8vMpHcicELkturIQ7p1YDVIhdaaUX/AeDRCSIiKEX7ggbQ4qRBOoAdDjl5sM+gOCb0yHlCYW6b0qc9CfYri7gHRo0ds3rvPvXt3eHn3PnOzs6yev4iankUKhXQCZwTSgsQhJdSVVDPVkhtWS3q6GL45PVX9/575J//4PxNC/DcAX/76172v/isKyd6/KuObFBpW6/G/p4j+GjDbH/e0lUoFQVFoIBWC4zjmydYLPrr1CfcfPcIYw/m1dd698iaXVs/QLIYowLOGwDlkEjN48YxHv/BNDu/cRXV7+YPpjIhkxPSbEtWahuDk0i1CSpyVeR6GQFqRGyISazTOcwilUH5AEET4QYCxApdanJ50np3Nw+nJ7EMC1oHNCxwTZ8TDMcZkSN9DhR7Sy9s1YuJ103HM4c4uvc4ALygTBBG6VMeWq8haA69YZsH30e0OTx7eg0GCG44h0yB9hMyLGYEjUB6Btbhxkl+XkiLyfW+pWNCNc2dn6/Xq//Xvfu9bX/g//1++/O9+9YtfHDrn1A9jJH9XGqBzzhNCaOf2ytD4P4D6C+BITJIJ5fsZkDiLkIp2HPPhndt85/vfY+/ogOWlRa5evsKFlTMs1ZvUfA/POSQOZQ3oFJIYNxxiul2COKauPHCO4ydPuecFXJKS6TevQWs6768B0hN4UuAMWGOQJ6WsBawBM2mXegKpJMI6dJagkxEuzcBYEHmvD+FwE4MCmeeQ1mDHMXE8xiHwfZXnkp4AqUBnkGrsYEj/4JC436dIjtY5Om5TfPKM8miMZyx6e5fu/h5ZllCtVCmXy3naoDVOhwjzKprqwYDu5gt67UOiconW6gqlRtMLwJ5vNPzp1vSf/q/+y7+9/OH/8u5fFUL83C3ngiuQ/VaO8rzfauMDjHPHNWtKf08q7yeSpG80QiACXwuJ9BSpEDzb3+f9m59w78E9Uq25/sZVrl+6wPnVNaajAhHgrMUai5AO5yzOOVAK4Xn4UhF5HvVSiC8Eu/0RL+7eAum4JBytt6/D9DTO90A7UB754EwghUI4h7MGJJMwbCiUCpTLJaSz6CTGjseI0RCyFBf4OHL4lVBeHr61wRkDRmN1itYJzhmkp/DDEBkGeeMxsdAfIPYPEZ0OIksRniPWI148us/OoEexUmE6CFCjEbvPn2B0Sn1pjurSPKpWweksN2QhcTpDpIZ0e4un3/4WLx89oFStsHHjTZYvXcafm5GNYtFFUuj6/NLnq37haz/zycM/eUWIbzjnPPFqnP27xwAnLl73+/3ZYrH601KpnxiNeqlD+E4qYaXCKsVAGx7v7vCd997nzr37FAsFPvepT/Hpa1dpFQp4UuLj8pGZcCAdToCQAuH7IH0IIqTn4aTAK0Y0G03C4YjHm7s8+fhjtM644jKmb1xDzbYgKmCdwwqJkAp7MhEhn4aAw1lLWC5TbzTwPYkyDpVqRK8HvT6yUkQoJlCYFGvyQyHVJASnCcl4xCgeEhUq1JsNCqVi7iWFgG4fs7uLGPTAJKhikUq5zgjJ4c4WO89Tdp2l7CzGWVqz08xcPEft/Do06yDA2RThhQiTYg8OOL57m80P3mfrwQOCMCTe3iXbP2TprRsUVlZEVCj6TnnZtenmzHKl8g/++UH73xZC/LMTfspvRXHi/VaG3fG4/QXfL/xtKdValiba8wpBZh1OSfAVI2P55NETvvGtb7O7v8fS4iLvXLvB1fPrzJYKRMbiWYcU4JxFCItTAovMK85JT0/JgCAoMBaCoFxi9o0LrPgBxU9u8b3bd7n38UcYk3ElTZj91Duo5UWk9BFaY3FY6eVjOOWDNbl3FQIRRfilMn4U4Xs+LtMMD/aJnr/AlYo4ZdFYBpmmN44p1Ou0lpfxEGTjmE5/wPFwRKPWpDk/R6Fczn9nJHrQp7+/QzYckqYpqjXN+qfepdBs0j9oc7S3z8Hzp4z3dilWyixfvMDCpz9N4cwZXBQinMA5g7MJIh5x9OgBjz94n9HuLiXAjhO27z9g2OvRaR9z7t1PMXX2PJXmtK8zY6fCYPYN3/uHt9rdvymE+E9PiFq/2dyU33QDvHXrViCESMfj/heDqPgzEtlM0rF2KM8JhfMkxoN2nHHzwQO+88GHHLaPOXtunc+9/RaXV1ZoeQo9Tuhs7yGzhGqtSlgrQ+SfNlHcZJSCEwjPR0UFMgdZlhGWSoTr6yyXSnSd49nDx/Sfv+Sl+j6ekzStQM3P45QHziB8NTk4AoHI0QUq7+chQTuRG1q/z9Pb99jc2SexhlQYUuHoZZqBhI0336Q5NwfKQ8cpibYMLaSejyqWUUrhTIZIYwb7u+xsviRJYgrlMtXlZRrvvkuwskLtsM3cwSGbH33Ii+9+h3EcI72AcmMaSkWstZyMY4SOsQd77N66xeNPPkEP+sy3WlTKFY67XQ6Oj/jkvffoHfc4/1aH+StX8OdnZVYMbSHwauv16l+93088IfgrzuF92Tl+Mzkp3m+B50v74/4XA7/wD5w1zTgbaoTv6clzTYDtoz437z/gvU8+YZSMufHmNd69fp2zjSZl4SDJ6D9/ycPvfx+Vas5dfoPmxjoyDLE2rxGEFQibv6kMQ1RUwApF2h9jOl2cp1CL87SWFjFHbTqHHfbvPsAkGTrVtN55B395ERVGiAkUy1qbh3Yh8t6KlBgpiDGMrIF+j+7DJ4zFE4ZpjJEOowSJlMjGFCvnN/KIrA2psWjpk/k+WRhCFOE8H9IU0z5m7/kzNjc3cWlKrdWiPLeArVShVMEFEV6jwfRoyOHDh+w8fMjmzg6zh0eU5+chUDiyvJrvtDn45CY7t24zPjjEL4Y0FxZYu3CeUZrx8sVLNl9s8/C9jxgedDDDEUvvvIW/tCCNDWyqPLtWDv7SfmKdEOqvvOec/xXn+M3yhN5vovFJIYTOsv4XPK/8/zbomSxNjZOelzmBpzyMlOy3B3zzW9/j57//XaqtBp/93Ge4euEcs5UKBaBgHf39Pe59/3vc+ua3mKvXWF9dQpxAn1yOMHaveSoZRfhRRBAVcRjidpfi5g6jZMzW9hb7R0e4QYJxgq3HTxlYy1njWPF9/LW1vIAwDqkE2jqccSgFqBCKZWg2sFN1MhXgihGlcoWpSV/PKkkW+vjTTRbPnMlbNuOEkRDoQgFXrhA0m0Tz81Cvo62h1+6wc3BIu9+noBQ6jOgnCe3nL5g2Dr9WB+UhgdQZMgz9eMRxu00hTlGlGs5JRJYweP6SO9/6NvtPnzJdLFFbmGX+3Flab72FK5WZfvmCme+9z50P7nD0+Bn3pcAGkoWCR7gwJ6XzhNbWNAP5lzeNYUmIv3LCW/7NyAm939ScLxt/UUr1DzXplLNY4RdUbBKQHrGUbLe7fOeDj7l57xZhMeDGtSu8feUyrSjAtxYPi8w0yfEB3e2XpJ0jROgj4gRhDDkI3qLcZPgvXr2Up/D9AB2P2N3e5qDTZbPfZ+f4iKBQZnZ6EU8pdtttXjx5wchKRkIym2WUlxYISyWc9EmcAyUoKgkKamfPc+0P/WHWb7xJqAKIIvxiibAQIaXEOEvmSUS5TKk1TSwleB6tjYv8SLnMsNthaW6W+sUNRKWKrzMolBH1KVSzQRbH7Pa7HNy9x/7ePsvzi7Rm55CBovPsCZ1eh1Q6vEJEUCkjAh+hPESqGT56xrPvvs/x4+eoccLs0iJrGxeYv3QJb+0MLgypVctEKGw35dHN23Sev+TF7dsUVmaZn28S+AUxSlLZdyqb872//CI3vL/snPPJgdu/vQ3wxPiO3XEtwP/bEjnVH3dNISyrDNAywErFZrvNt9//gA8++oRiqciPf+6LXDp3nrrv4TtDEUMBB1mCZzKmAp9WqUBkLUm3jxmnKAQI9YqF5vI8UOLwfYWnBKM4YXNnj7a2DJTHzNISa+fOMT+7gDMG/959+rcesLN9QPrJbeJaibNTZYJyEW0dmQRrc4Cocg5TKlC/eoXpq5fx/JCxtYzShHjCkjNZ7qGM73HQ72E6x0TSZ6pW4ez820inAcdYCcQ4RghJWJtm8fI1PCA+OqDf7tI97rH14iWd7R2qYQFlDUk8YDzqoQohjflZps+soMolSBLcwREvvvMej77/IVFiCb0IMkMYhKggxGkNzuAKEd7CAo1GgynP5yBJGB0eMjw6xOoEJVJCYYQQUg2t0bNS/qWHSfJYCPHfOudCIUTy29YAnXNKSqnb7Xa9ZEv/vZTqzNjG2g+L3jDTOD83voPRiO98+AG/8N3vUC1X+dTbb3F1Y4P5YoQPKGvwdf6gnDOUCwVa5TI7xjA4PmZweIgeDVDa5H08D8gMGJPngJGiUCnjhSG9NEMLSWtpictvXKJ15TLVxQUKlTLWWHSjwUj67BwcUGw2qc+0qDam8LyABEhSzXgcszsY0Dk+5nhvn173kCQZkzlBZnLkCzjkZPbrICcdGY3NNJ4TRELhK4mQljAMqFanqNUb1GoNWqUyM+vnOLO8hNAJ2WBEe3Obp3cfsP3kKYcHB9jxiNSk+MWAxbUVFi5s4DWaEAS43Q6duw/Zv/eQ0XGHKaFwnsfRcYebNz9mRQpWR0OKi3NQLKK6HdJhn8F4iBGWYiGiGIWILIM0RQCBUNI5gbHCrgTBV18690QI8bOvTbF+exngSe+o0+k0S+XS31FS/cQoGxqpAs8JhZYGKyX7wyE///3v8d3336NQjPj0O2/y6SuXmC9EFKzDy9K8ogNQEud5BKUyjUqFgpP0O11Gx23McJgjUVQ+7AcLwuSY0NDHL0YYJdDO0Gg2ufipd1n40R+DpSVQAicc0vOZqVQozM2y1utha2X82Wme7O9zOHhCdzhGpyYf5VkYxzGj8ZDYWAZpyjjNQChCPyQMQiKVN8CFFGTSYSbjOJcasnHKOE0wOsVIgadT3HjEKHN0O10anqKIRRhN5AeUV9ZYm5ph9o3LxN0u6XhEv9/BCs3yuXWaV67iPB8xToh3D9i+d4/23j5SSoJqmVZjit5wxNb+Htm3v4NoHzO1sgR+wODlFg/u3mZ33Kc6P0NrZZmpmRmkUmANQuQAiVBIOUwz4zy1MCfl3z9w7k8LIb7+Gzm2+430gJ4QIjMm+7KU6o8lWZw4I4JEa4Qv8XyPg1HMB3dv8bPf+nkkkj/241/gUxcvM1coUMk08d4Bw4N9PCxBtYxXK09I3ZZKschMpUq63yZud9CjAbh00vvz8/irAGkRSqAinxRLiiWaqlNcXcUtLOCiALRGeAIXeDDXojbToJhmHAx6PNnb4dbDh2xtbeEyQ6VUptVoMd+cZW1hnnqzQbFUwAqHNhohJJ6QBFLhc0LRFGjh0MLlnaEJXJ/JxMY4TaYtw3FKu9PjcG+fu1sHHO/u0D0+JIpKrCyvsH7mDKs33mS9VkMISAZddDYmqFdR1SoiM8QHbV4+f87DR485bB9RKxaYPr/GxpvXseME9Y1vsvf4KS8++pjtuw+Itea426Mb533K6YsbtDbOEbVauLCA8BRCKJyQGJ3hOVRqhFZSzirs33/u3CUhRPs3qijxfoO8ny+EyHQy/jNSev+hThONdWHOY5BYKUktPHj2gvc+vIn0PN568zrXL77BXLGMGw3Ye/KSp+9/wPbDh/hGMz0zzfziPM3pBpViET/LqCgPmSYMDg+IO8dU0xh8RT7EdZNuoMPzJcV6FVUpMZSKI6MZZCkVkzeavWKE8Dz6OmX/eJ+jozaHx0ccdTsM4hgjFec2LtKsVpkqV6gWypQLZWrVCqVyATUZDZ/of/yK92by+XXyjZm8xmVDtVKl1ZxiuLBAt3uGXq/HOE4YJ5qbWzs82D+iWa/RaEwx15xiem4Br1iYtIoydg+P+OTuXR4/e4zudplemGPh+lWiG9dJt7YplEp4VmOG40mAEIRhRLPZZOb8Wc6+fYOpc2eRtSnwvHyOLXNghoScsCXwRmmqq0Ew51v+1ted+1L+2N2/NJTL+w3K+7JPPnn/jTjTfz2SWjicxJNYCUJ6DLTl3rNNvvfhh/T6Az711jt8/t23mS5WEFbTP9rnyc0PufO9b7P7+BkiTWgUS8w36yy1mizONgkyh+13kemIuHtIcnwAwwGuGCFQuacEnDEIzyeq1kmCgN1MU5QSWyigihEyihjqjN2dbR5tveCofUwWa9IkBU/QqE+xuLTAyvwSrVLeCoJX3F7rILY6B5w6iYfAF+SsOStyaBYOKx2ZFPlYb8Iits7hhMsB1kIRelCoFJmrlBCzMzlXhRx8+nJzhyfPnnN83GGwf8D28RH3nwmKhYiF2Rbrq6vU6zWCVoPK8iKNs+uouTmWrl2ldukSzM6S7O6TOE1mNWGlxNLZDYqzcySFECoVqkuLNM+t4c/NQRhisWjncuNzAk8IJjB1KkGgNOii5E+8mfG/+4rP3/hC3p7X7l+VAX7ZfVkC7r/+H/7rWmlq6qfTNGmC06VS0UuxGOtIgedHR/zTb32LZy+f88alDT5z7QbrtSaes0iToUdjRvGQMIqYX1jES1LMYMDB5i69Fy/YKvg0goAgzvBNgkvHDPd3iQ8PCOs1hAon6GKFy/K5sCxUMKU6/vw8M1cuUz1/FlcuMchSHjx/xs1PPubF9jb16hSXNi6wsrxErVIhDHyUr/CUygWJJp5VSHkKWg2kRFuHMAaFREqBVOBkPgrEWaT0EALshLSOyf3zCbjaCYvA5N4bgXUn3lJQinzOry2xsjiD1pZRYni5ucMHH73H049vMjs7QzuJOX92nZnZGd7+A7+fs+fPEoxj6tPTeIvz4BeQnkeGY2ASosijuXGW6bfexU5NIaIIUSoha2Vc6OXoHKfJrMFZSyR9hHX5gRbgMMJzViKVLvv+X/0L8K2GED/3nnP+O6+pev2WGeDrA+vHuw//C5fZzx7sH2TzCwt+ikMj8KTP3njEh3fu8vDxY6amarx55SqrrRYRucqAh6M5VefKW9c5t7KKHKbI/pjB7j77z57Q3nlO0jngoNMh0JaCH+IHATvPnlF88JCV5VVcBMZoPCmRXoDLMmShxBvvfpoLb7/LhWvX0MWQ9z65yfOdXeKJ9MaN6zPMNFuszC8yM1UjOA2RDotDCEHmDNYaPNQEmADCOgIEKJUb3AlvxCZAhvDkpCrOFRCkkEjl52PfnFaPVCeCRTke0AmBcw47QVL7ShEWCiggq4Dvh1gBrfl5DIaDbpe9732PqVKBi8urnH3rbZSSuDjJGX0WEArtKbLAxxYKuFoFOdtCzi1AEEykG1zeohEO6wm8kzm48BBYiDP00SHbm5sYnFxYX3Xh3Gyx7OR/M3buj0bw5F+mMv6X8YBCCGGH2eGfSLX4D+7eumswymvOzeEhSBwkxnDr/kM++eQWtWqdT731FueXligJgbMGT1h8KQgbU1SajZwZNkqhN8Ye91na3ebwxWP6ey8Z7+0y2NnDxQmxtQy2dolu3qExt0r56hVUsQLaYpXEKUU4NcWlz34WIRWDNOXuk8fcefKIRBuWlha5ePEiC60Wgcg9GxYyp3HO4aRDCTnpMwqckHmjexKGjbN4QuApmYdUXI4bdCm50EY+mbEIcHkejJAIZB6hcfmIDoVA5giaE0OVCu0gNRpj869QQtAoh3zq+gX0tQu0+32evXzB06dPefL8Ob3jNsP+kJWFBeqVSg6iyFLG2tDXjlj4JF5IrPwc2mhM7qWdywG4SuGEwLMWoTUkY/R4RHrYIdk5oL29xdMnj0mExdy4oRavX9KF9Y0NY/VXhfT/HYeTr1oXvwUGmHu/r3B4+HIp9Cp/UzntxvFYDAapWMoMNRSHJuPe0+d8970P6HW6/OjnfowfefMGzSgkcqCcyxll5Ehih8rJ19KHoIRstqifWaR8eQMz6GD2d2nfvc/jj2+x/fwZLs7YvfMIwc9y2S9SuXY1Nw5rEJGPKZcYDEc8fvSE23fvMopjVtbXuHhhg+lKGT8MCZAT3N+kiBZ5KLXYHFniHAoFno+Z5NrO5d7R5L8xQgisSXA2xvMNkJDpIakzSBngqRzq5XAoEeawKedwVuYIZgnaaozNSeyeyov5gBz8KgWT/uJE2wjwKhVq589zdmmJzd0d7n78Cf/kmz/H+dU13n3rbVozLTwhGABjL6KPT9FKTKGEjIpYYeGEzYcAKyCOcZ0upt0hPm5zvLnN/oPHtJ9tEg96OOnIlODm1hZ6PPTOl4omml36t0cm+SfCE3/319ua+XUZ4De+8Q31xS9+VTv3lf8cWHTSmahQUHvHfWKr0cBep8d3PvqIvd19NtbO8ealCyxXCqhU4ymJh8NqjfNknv9kKcIJEB4EPiiJUD5erYzn5mBxkbDRQtbqqGKJl3fucbx/SCzuMy6WWUk1S1cvETaqpAiebm9z89YnbG/vUKvWOX/uLGfX1lhpTuGf+CkLwuVyHODQEzifQCAck5Ar8pA8EZ5ESJRUOJFDr3wBQmoQCU4kJKZLf3RInI0JCyXKxSZSVBDOIoVAyFxpRjiBsbkxS5lrDJ6IuQghUDL/jDHozCClQkiJsRZnHcUwoBoElCtlIj/g+eOndI7b/Px3vsvM7CxXL55ndv0s6zfeYmtzm7bWpFIhKhVUpZQbYLdD72Cf7s4u3ZdbDLe3SbsD4sGI+KhNuneI6/WRUlKqlnAYOu0Oh0+esHzjsixNNZzvRX+t7dw3gWe/HiP0fr0tl4Pj3X8rSUd/Ok1ibaxV7XaPUZKQIthJM27evcfjx8+Ybk7z+bffZrU5hW8toQORpGAypI1zNpnv51CoiaIAMidH2uwkVAFhEbm8xHylRFSpMEpS2nfuMxgO2L//ALF6huUbV4mzjMdbm9x+8ICnz18wPT3NZz/3OVZmWzggsYZsEtZy4hEIJfKQ6dzkBV4OxMI5g5mEKiZVoRI599e5DItByQzDmJHdpzvcpt3dIUlHFLMKVi5QjhYIhMQikKKAJA/JaJt7ITmB6NtcRMGKV/HMORBSopRAyRweZo1mlBo838cXiivr67yxeobb9x7wvffeY/vuAUJa3to4z/q7b9MeDTg+OMAvlUi6XdLjA9ywz3B7h+1HD9m5f5/Oy23i/oBUawIvoFks02pOUZ6fRRjHOB6RDftUooAw8LDGCpslxguKK2X4L4QQf+rXA1rw/kWr3p/5mZ+xf+O//RuVZy+f/jlfCE+nWjuUePZii7GUDHXGw4cP+NZ3v4uQgquX3+DC2iJTgcJLUsQ4wR4eYkZ9pDQ5z6JUQdQb4OUkbTx5mneJk+xCSigVoRBQE4ILacqxgCeb28wtL7KwcZ5UCO7de8CHtz5C43jz+nUunjtPY6qORJwWBJ7IsX6JzUgyg1US5Xs5EUkIjBOkzpJaO1FJkPjSQ07GbHJiGcZZDGOsGJG6I45HjznoPmHQ30XbhJEtkNFGNS2e703KG4eHD86hPImYhFWduVyUyBNkEw/tHEgvxyZmWYa0hsjzUTLAn4RPl2mshNDzuHzuLGEh5OP797j//Cn9YZ/LZ87w5h/5g5hxSgGPF3fu8Ojjm2RHR9h+l/HBAea4Q2hhqlgkK3vUmnU2zp2nNj2DNI7e7i7PHz1CxwNKzSlaC8sUm9PIsCCyNLUiCP74wLk/IoT4nyZUT/ObYoBf4StC/KSwz3ae/EXPU5893N/X1XLRS4yjtbRA3zoOuh0+uvkxB3v7fPZTn+bahQ3qUUAEZO0uW3fusn//PqP2IVJZPE8RVGvUllaYXT1DYWERann3zWmHcBOPOBENQgnkzDTzN25wyTpqR8dceOfTlOcX+O6HH/J86yVBIeL8+hoXNy4wXSyjnSVLM5QDL8gVETSWTFj2ux32uz3wfQrlEsVSmUqpSEHkoVJN2klgcqMRAoma1MkaS4x2PbrxNrudJxz2HhLrDlJoZOwR6yFC+LhGRNmXBBSwTucqg07lnt7lVbOeyIHoST9wDIzTjH6/x7Dfpeh5LDRa1AsFfCkQNvfWGItGE4Y+G+treMUij58/YXd7m5//+CbXzp3nzcuXkYnl+f37PLl3n/6LF5Sdoy4FDT/KDTlOmJmeYv3aNWbfvI6o1tFPn7L74DZP9rcRns/S4gIzZ9dRjSaZRcapNmU/iBDm/3in2/2eFOLoX8QLev8CoVcKIczQDReL89F/CNK06jNSCY+xTqksr/Dk6IiP799nc2ubteUV3r5ymTOtBmGmMf0eu7c/5qN/+g2e37nNoH2MFIaoEFKq1JibWyS5dInFK1eIVpdRU1NIPwKhcEIhRB5+nBM4X+HPzLDxI59jVVsolLn37Bn3Hjyg2pji7XffYmVhESUFw2yMLxShmmBKncnZkgqcFPSSmEfbL+iME6JqnanZBZrNaWqhT9VX1HyfonB5DocjcKAwOGFwIsUQ04332Dx6wm77Cd3xLlaNTgUPeknCKPFIbcTyTAGlaoDGoshs3iX0lAIpSIGhhZE1DKyhm6QcHh1xvL9LMhywWG9QKdQoRxE+As+B70/6jQ6yzOCUYHluluZ0g9ulu3z329/hW+9/gFSKi6vrNNZWWbpymeMoogos1mu0iiV2nz/n8f27qF4vn9T4Pl4ac/TyOQ8f3GXnYJ/VNy4ze/EChdUlrO+TJBkSoRKNLvnq8lKp9G84+OlJkDC/KTmgp+V/gidnExMb3w+lcSBkgVZUZHM04uHjJyil+LHP/ghvLK9SlxLb6/Ls+9/nzs//PC9v3yM+PsbLYhQGX0AoRpiXWzw7arP/4CGzb1xg+a3rFNbWcIUK1noIJXPSkcjRyq7kE1YrdPfbfOt732fnYJ/1CxfZuHCO2VaTQClwmshTKJcrHgjnsCbLcznnI5UiqBaR5TL77Q6phYoKscdtPOeYr1Y5Pz/Hcr1CRShCJ9HOIoVGkOFIGLo2W91nPN67z/Foi0S0cSrBVxLpFGhDZ/CCxAXIsIKrVynJAtJJnAhwyFOV1LZzbPeHbHZ77A8H9MdDBt0e6WBA3VPMeyEqDJEytzg3wd4IcmUvY3PylCcFBelxdnWNQPnc/PBDfvbb32YYx5xfWeHtn/jDDLZ3iYxmuj5FWAwoP3zIsBKwff8BD299RCX0CC3s3b6DGY+Znpth8cobNG5cRzRbOCPw/HCS2hiZZsIqyf/+2Ll//BXY/PKXvyx/LZJw3q/R+ynApqPRj0rh//l+3LVRWFCJyTBOooXkYDDk3pOndHt9Lq5v8OaFDaaDAPpj4p0tnnzwPo8/uUWgLRfXzjA3M42QEA/6jI86jDsDBu0evYMDBkcHmNGAFa0pnd9Aluvk+o8niXx+w58fHvH9Dz7kxe4OS8vLXL5+lfl6BeNA2wyJJZh87WnzUopT3q5EMFWtM7e8xP12m8PemO5oyNiCSDMOhzFHo5Td6TprjRoLlRIVqTCkKAxjO+DF8TOe7j1lb3BE38VkZFiboTQIp5DGEcoY3dsmfXYHc2aKpUYdhY8nQwySntYcJCnb/SHPDo940evRTlO0NcTdHn6WMb2wQK01Q1QIX5s/u9f+5BAyh+hiLcI4muUytTcu4vke73/4Id+/c4dUwLvXbzC3fhYxGqMCH5Sl1ZriciEgMxn7jx5xbziiFhZoHxyCtixcWGX9+lWKs7Oggpx7ryQCgbJGpkaboh+cTbT9z77qqz/zdee83zADPJl4aD3+S0op6bvAICR6IluWGccHDx7wvQ8+pFad4vLGBabLEWFqSPf32b5zixd3b5EMeqxduMCbb7/D/Plz4Pn0N1+wee8+x892SAcDRsM+7e1t0kxjlcfZSo3oXBXheWijsUpihaLd7vH9m5/w6OULLr9xmbfevE61FJFYCw58pZCOfK4p5ISw5JBSTST7LFhFWQXMNJpUpmqk3QGDJIWgiCpEtI2js3PAzsEhBwtNNpZmWKxXqEqHLwx742PuvHzK1uE2idCMhCLFx9p8noqFUEhKvkd/NGK/8wTrLyKKq9TDGtYZemnKbmfAy3aXzU6P/VFMxxpSTyGVIkUQKJ/mdItWo05B5VrUMucjIEQ+X7bWgfDyZjachmWc49q581RKZX72m9/g5t17RMUKV89vUKlWsUmcG1OjyeKb11H9HvdHMc8ePaI08XD4Pq3lMzTPnkOEAU4bnBdgXT4DF9KgbCZTK21Rin/zyLn/qgG3fy1tmV/VAN9z7/lCiCxz4x8XeD9udGqdcTIVFp0TYWmnCQ+evWD/8JjPvfMO584sE0mBRDPc3ebhB+/x4tFDplvTnH/nOnOf/zRybg4nBNUzS6xfuMDi8y32797n6Z1b8HJEZ2ubZ5/cobC0yvLMLH5renLqFMe9Hj/3z/85u/v7XLl8iatXLjFViiZ9VYE8UccQCiEVJwtjHCY3jBPy+URYvCR9mqUqYXDI0XCEySAolImFQnkhsU4Ybu6y3TtmY2mWc0tNAjni2dEBDw4POOr2IdAYFaBVBe1StE1RUhD4Ef2RJRslyCzA7u4Q1A84t7xCezzi0csddjsj9ocxXW2JPZ808EmMxo5ivExTKVWZrdVpBF4uP+IcUjiEsNhJXW5F3jkQE+SNciBs7hE94VifncV9/sf45re/zS98+zuUghJXzq9ipI+Sfg4V8yPmzm0gbuwxOjqke3hMVCozs7TC7MYGamYWimW0zg1eegKERZsUp7TAOROqcl1j/5wQ6t//tey/834N817r3Nc9Y/iPpPLCzMVaSs8zSISQDB1st9scdzoUi2VWV1eYrVWR1qJ7PbYe3mPz/j2miwWuvv0mi29fRy7Ooj0PgUROT1GYaVFYXkbVKlgskRXsbm0zaHc52ttl6uiYWr1GGATsdrt8fPs2u3s7zC8scuXyZWaqlYlHy40vr1RdrlJ6GqomC2Nsrop6omrvgNA5qn5IoHySUY/UeCQkOBSVYgnCkMNxj/Zhj75JaZsekRqyvb3N8+MuSabx8TBSoFEY4SFEhPLy+2MSDcZH4dPdPyZVTxgG8wxiyaODI7qxZYgi8QMy5ZM5GCVjzGBE3TjqxSKNKKQAuRSJm3CjX10ZdrI2Qr4G/5ITyRptHZ4nuLC4yPHly3zrW9/h5q3b+CpkdX4WpQQmy5BWYkzelwxLJXS3h9+YYv3NGzTOb+DCCKREypwIJqxDKI3zJqHfGGmzsQ2k92920uFPAx/8al7Q+1VGHkp88Ys66R9f9Yr+p7ROnJBKeNLLm7NCcDQccvfJY8ZZwurqCoutGWpC4PoDtu/d4eHNDzHtNlfOrHHj6jUqc7M4JZFaI5UHRmCVhXKJ8sXznMsshdgy6o3pGEh0hrYW4SCzlnsP7nPnzm3OrK1x/dp1ysUIax1qAjNxziGsQ0lxmibl4j8CgUNKf8KhdahJs7mgJNWgkJN14vyGZgaGyZgMwVS5TBBVMVKwOejTftQhkEOGgzZHPYMTPkUvR2WnLsUKhR8oRGrIdIYjRLgQnXqYMcS7HfreU0Q4Rd8qYj8kFX5eBacZaZqQDhIYpcggoFwoUPBkTlfIW/U5UOD0ql4Z3anLka/2lQgrMBYMlvPra1hj+eD9j/nuB+/jffozLM1MEXoe1kpePn7Cw0/u0B7EiEqF+plVZq9dI1iYxwoQWqOEyrWvdYazGcqluHjE4LAj45FOW5dvTNd8//NCiPd/NS/4KxvgF77gnPuayrLiH5dSzTtnMof0UwNG5W2DF3t7fPTJxyA8rl58g6VqjirpdTrc+f577D58SF0qitqiDo6Qhx0oVCCMcGKioWIMzlhEpY63skp4/wlaKUZW44RHeaoOgcf9Bw95+OABxShi/exZllot3GSQ62wup+FPHhA2Hza419Cgp8y5ST6oJpONAopGVKQsA+woxaiUoFBGKEU/HpMZQyUKibwIKSxjnYJxZFnI0NXIMsOgb/A98P0AS0aSpRjjcAQILyCOJXHsUy3PYsrz7CQezjky4ZOYHICQGUMSa9AWl1jsKMVXPmU/IFDyl1SU/2FArHgNvyhyztYEi2gxDuphxMbZdY67PR4/fMIHtz6g+ulPMdeocbi/z70793n8+BmBVMyuLTN9YYNgaQGKUd6BkBKMzlmJNkMMumR727T39nh8/ymddl99euxoXL/2v+71tv6eEOLwV+oLer9a388NDxZUKP+cNZkToDKbN3G1kLSzjOc72+wdHHDpwiUurKxSDYJcCyUZ0T3YIxuOCFD0jts8fv8jmqMUf+MCtY3zFJaWc4J2kkKa4nwPLRXdJKOTJLhqmebCIoVajb3DQ27duQXGcv3GDRbn5l49EJF7PWEdUqmJWpQ7KZ7y9R5MUPET4Srn8irYCfAlTBVLlFWEGSRkYoxftQhgnKQMBiOGYUStXKBUDPELdWwm0dbiippx16IHXSJfEEVgjSbVZiJwGZAZH20jgmKLaGoNWVsiUyVSqxhriJN82aHVDmUsoZDYzJANRhD4BErhn6B2xKsCWEz+kteiuSfMsYbuFHsIE91Cm3+Fc4ZKIeLG1cvEOmH7+Uueb76kWS7mPGjl0U81hVDSXFll5tIlXK2KU14esQBGA/TBPqOjQ4bb23RfvuRwf5/Hj54zTqyaKU3pxvr6tUqp9keB/+ev1Bf8lTxgfnWq/lmpvFmdjg3KV5kzCJXvtNjc22N7Z5datcr6ygoz1VL+k4whCAMWz6zg9vYQR21GWcqj5y+4s7lL4eYd3vjUu5z9zGfx5+ZwQYALfYTOiPf32dzepmcsK2trrLxxkX485uYntxgOY86d3eDKxgZRFKGtzdEiFqSzOR/jtDvhXnd9vwgXL16xOBHCUQhCAhWQxCkjkaBGab5EJjOkmUEno5x2aSNKJQ8pCjivgl9yeKlmHFtMHDOOY4zWCJmP9SySTPtU6/O0ZjeISosMbURmFNpIUm2JE0ecaoR2FKTIETJpyngwIC1GSES+EPEH2i/i9LrEqeH94GYa+9rFSinxnMkPDTBTrXL5jUuQah49fkJF+WzMznLu+g0OX77EZgmt9TPU1tZwfoiLE9AjXKdHurfN4ZOHbD14xOHmFvFwiMk0dpjgC5+tew9Y++imbVy98JNf/vKX//tfCarl/QptF+Ock6T6Pzl9hBPJCiEh1ZbHT5+xvb3N8vwi55YXKUuBbx3GOgpTU1z5whdYaM1wcOsWh0+f0ts9JBkMcckWj+KMzvNtFi9sMP/GBt7SHGQJB4/u8eTlU0S9xOq1y5QX5njvxVPuPnnM2TPnufzGJUpRlPMbnEB5IFyOVMnbezbXdDnpRUx6ZHn4nZAmxSR3EqDdBFql8hFbMjaMbEww0hB4SOMhtME6h4kNIxGTjh2e0hTCkGLUwlU94rFh2NkhS3LB88AvkGUabTzq04vUm+cJo0XwphgNHce9PqAIPR+dWUxqkdbhlMIJSEYZ42FuzFLKCbp6kj2cphI/0Ao89YGCHNDgXjdXAZ7IF++kxpJkmoWpFu78Rb75ja/zwa2PaTV+lKXrl/iMSEn7feY2ziPDCIZj9M4uxy83OXz6nN7WJsP9PYbHR/R7Q4wTlMslpksVRtbRaR96d977nnv3wvof+spXvvKOEOJ7vxxo1fsVwq8lSc4j5TWyDIFUBoGVoIWgM47Z3tnFZBnn19ZZbrXwrSOwDmc0MgiZOn+e2nSD2uIs5bsPaD56zvjlDt29Q/afPGP/2Sa9Z88wBzs0zp5BW83Djz9mv3PEG++8y+IbF9gZ9Hi4+QIRRZw5e46ZRpU0zfkYgTfxePIVHtKZyVNR3msPaMKYey1MnbDZrXN5tJ4o4+vMEOuUdKyRwsNzEqUFOl/+QWpS+nqE54GoRXgEBF6dWmWBbBSTJhprEkaZxRpFVGzSbJ6lVjuDdiXSWDEYxvS6Mb5UyChH5dg4B8MaLx/UZbHGZnayv+RV2XHyUvwSGxEd5M/YTTy8mHxfjveXQhCI/OClWULR91idm2N5ZZXnzx7z0cN7fOryJTa++PtI9vZJen2OP/4Es3tI/+VLNh8/ZvvxM7Jej7IQRFHITKlCoT5NbXmJQrnM4c4Od188ZevFC/tut+dTOfoTwPcmYdj+Wj3gSXLxJXy/SDw2SKmMtuApejrj+d4uw9GAVnOateVlWmGI0vYUW2d0TlmU9TrN69epraxhzr/g4MOPefT+xySZRacZe5vbjMZ9Gk8fkknJi509vGKBtSuXKDYbfPDgAb3RkAsXLzLdakyqV5Ayr8LdiSTfpORzIsdYvdrTe5IvcUoaP8F4udeuNq9LRB5mncTEGqTO3yMVGG1JjEYKS5xoglAwEhl6rCkXA0qFaZjOsS7Hh3sk8YhitU5jbo1ybR4pq2gjaXdjuoMRwuVtqCzLiw6bZFhH/rOFBW0wJm+qSzfpbZ4a4MSni9dSDHdS9r7+EqcX55zF4p1yWrxihJAOFSreevsGYxPzyYP7zM5Oc+3CFUQcs3XzE55+/wP6m1vY4RA3HGMHQ0o4KmFEqVBmZmmJmatXCS9dRPkBjZs3ebyzxfHegTh49JiF6eYfdM79NSD+pYoR75fr/QEYxx9UAFIJY3PEReB7DEYjHjx5yGA4Ym31DM1yiYh8U4FUEoIAqwVOp1gBUgb4jWl8P2KuWiFYXGTm4WO2Hz1l8+lzDtpdkiwhEw6ikPMX32B+bY1eMmZnd4dStcrG+fNUixHWOXw/B7Fq8pGTnCzztc5M4O/qZEHCaU4obP6MTgLyqTmKnNolHBitsZnBGomLM5AeVihs5lD2BC5vSQYZIpOk0kcYQSockRdRqy4wHGkO7AiHR1iep9xcQRSnGBnoDGPa7S6jcYbvBfi+xJhcRVWnOfnHKpOz01JNFidkcYrVOkfynPpw81oN7F7LaF/PCCcNd9zkHArAYCaeUE10bJxzzNSqLCzO8/jpQ+4/e87SwgqVsEBvEPPw3iMGB3sE1jBbrbC6toyKE9LOgKAY0bhwjsq7b8LcDOAo9o4JqyUGu7vixcPHLF27us7BwbtiZuabE4Vc/at5wLz6TdN3rFKXnM4QUghsHq4k0Ov1ebm9hZSShbk5SkGQR7g0JRkNEJ4gCMOTlUF5r886XLGId26d2aVFps6tUfj4LmGzSXdri7h7zKDbobm4yFuf+xyuEHHvyWM832dldZVWtZoTgaye9B7E5FTb14qKk8r3l2Lm/mDAcoj8AeTwUKydLKcex2TW5h5QZGTS5DLAQoKRYARSS7TNGBlDJh0jYYkrEfXpGqFXo1SZJ8NSaczjFxukeHSHI47bA4ajJAfa5o4PTwqMzjDGoITEZJrEGpKJ8ZkkzZlpzv1gn+9VKfyax5O/KIiJ07EdmInqq3ECJcwkn8y5KfOzs5w7e46XL17y4e1bfOH62zTml6nNzFMrFKgUfJaW51hdWmb0cofnH9ykE49oW02lGCACifQ85MIMjeU5tg/3xM7TZzrZ3Z8Kw/CPAN/kl9hN6P0yrSVjrP0J5fvNNM2Mp6RCSJyAAbDb6dDrDpidm2VlcYGS76OsY3R8yIvbt7FGMz8/T61RR9ZqUCjlqGOb5a6mXCA4t8Zqo8Hs6gpHt+/w8M5dOi+e0Vxd58y1a9zcesntR494480bbJxdz9sQzmIxZFojVICcEKgniFWUkPlMFJ1vHbKTjv3Jg5lsMQeJxuaiQxOYfaZtvs08TjDG5Q9fSIyUOXBZKKROUcISSQ+djtGjMc5phM2wPQ8RjwmqZeZbi7gwJKxWQRQY9DXtowGD3giMxEeBMdhMo5UkSzU6M1ipkNrk1aq2GD3RuzE/tDznZKrz+rESJ5jFV5Kd3ukBtDgnURP6h7UWY+wkHZE4Z1lsTKMvX+Hp02fcvf+Idy/dYHnjAu/82I8SjMc0mhUqy/P4YUg/+ITDR495trUF9+5RXluhUbyOm5pCBT4zrRkqUYGDnW12XrzkzIWLnztwrgIMfrgY8X64+AC0cy7E8ukJfMQZJxCexJOSdqo5POwwGo6pVUrMN2oUJSTHx2zfvs3tb36TpNfleG6e+dkZiq0WpelpqtMNVL0K5QJ4+RZINdOiFISElRLB0iJzx23Kiwv0lODlcRuCkKXlZaYLJRJjTsxsInGRa0MrkdMYhc3L85M1ucKd0LwnkPeJjK9z7jRflEJMRlgCZzJcluF0vvdDZxlIiVMexuT0zMD3kcJAMsI3Y+anqlxYWaRSKnDU3mfrcBfdszTm5vHrTTI/ZDA0dDtDht2YLLEEk1zcGUO+2VCiU0eaGqQwOCEoqJxHbFNNlhiEdkj7KrgKl6cg4qQDKNwEeXDyRe50UnLiFXMOspqgZfKOxgl3z7mMggxZaE5z9sw6ncM2OwcHrDeanP/RH8XLUnxfQMGH4yPSbodur4cvYHSwx8vvfZ9yGFFsTdN78pRsdw8xTsh0Ko/3tu2ZUe/taZm9JRozP/dqK9Yv7QGlEEIPh8M3wyj8EWGUFVJK7XJitkPQ7fTotLt40qNerlAPQwJrGLQPOXzxgoMnTxnu7pI8esp+uUSlVqXZmmZudYXKmSXk/Ax+s4FfKiP8EFeM8M4sM7e4yGwYMRqP+fjpI9pJwpmLF2g2pnMJjEm8kEohZH6/nXV509lOCBU4hJyEI5dMpvEnOZOX146T98m1LHMdlwxI0wSbxkgzuT3a5Ds8kGgNaWoJUTgTY/od1pem+OKnr/GpSxeYa1a4c+8J//B//EccdXpUZ+dIxmPSUUaWSZJegh5bfJGTvU2m83xPWpy1mAyy1OTC60phPYHOLGiHTjJMmiGdneSAk+z1pLg62ZItJgxDcSLXa07r5fzwyVMJY3k6q2MSIfJ0xFOKG1eu8ODeIz6+fRv/8mXW11dxicYkMaJzwOjOfZ7fuUOn26NeKWK0ZuvBfcpS0iyX2X35kp3tHbJhj9JUTUphMyrFEvXp3wf8HD+0RNv7JcRMhDf2ziupqmmqjUNK4/JqLLaG3YMDhoMhM61ZZlszhEgUFqEUhXKJ6ekWYaLx04Rhv8+w3+P46ICX25uEd6sUmlM0lxeZXV2jvrCI12qBH2CDAFkt0x+PefBiC1WIWD9/Hi+KyCBHDVubs9PI2WXWaMbDAS5O8ZzD9wRCibwaIsv3gHgn4oE+yAih1ISKaCd8oACcZNwfMh6O8nCnHSa2eBIcNucrJxZEitUjCtLw2Wsb/PEfu0ajEFDwFf1qRNmkqMBjtTHF46MOg+4YG1UhThFpzgHJx1j5chyd5AXHZJsi1lgIFGmakY0TQCENxIMhTpt8t7HTSJeccpZxE4olSX7QjAGT5Z/tCdFJgfARMkB6BYTvczIJV0JhJ/mhEpLV2Tm2Xu7wnW9/l0qlypn1FaS0KBzx/jEff/AhT19uEZaLqGIZ6yxxPObOrVsEUqGThNgaivUajbU1WmdWoFh2wCV361bwqxUhDoHzMu+dPK0QVnhSCWPz/AHHUbdHnKTMzc0xXWtOajJBVGuwfONNqo05ssNDsoMjjnc2OdrfodNrs7+7R/r8OYGSTM+2OFg5w/TKGaqLC1SXVygvr0CxxN7BIUfHx6xunGd2eppACbS1BELmBGprTnPv8XDI41u3OHj2nLISLE43KUUeyjOEkcoVsHyQvkKGJVRYQ5ZLEIQIqfBcPq3wDcTDMaNBgnUSZwTJKCU1oAIfX3pgHUm7Q1ElXDg3z6eunuNSPVcuaA8tJQy//923qMxMM31mnQ+f7vCzH97iwdYm40whVJEsyTeoK5nnq8bovLlsXL6oJnNYo3LSuw0QokA8Smi325hUTzxgjGSMEPkslmyMzgY4O8oLNJ1g4jRPJ6zEOo9R4ki0RBVq1JsLFKemQUY4JAgv56VMoowvJaVyGeUpdve32Ts+Yq5SRbePeXH7Dk8eP+NoNGR1cYHlc+fxPI8nL5/z/MUmaTKkWqsyNdOitbLE/KVLTF+6KhFSZMb8Pt1YmC8K8fz1doz3i6BXL1zDYj6T95+UdIBQEilywcVOr0OaJjSbU9TL1UnBL/FLdRobdabWz8EgwR4c0tneZG/7OQdbL2hvbtLb2iHudOhv7TM86vHs4TP8ep0LP/IjvDm/yLDbY3d3hzAIaFSnKKjJRnMnciQG+Q62k/xbpxmdg30efHIT1+9xODPNTL1ItehRLoX4BYHwXT7RKFXxS3WCSgWvUkNFVZxXxCuEeHhkozHj/hCbGaQV2NSQpSP8MKRULOFbR7/XwYss85VVytIwHMeIxPL4/hOOj/Z459IGM0uLDAU4b5W9w2NePttkPAbpC8Y63wvnBSHK5hMcrMVqi0sNIgWTZqjQpyAiEqMY9fv02kfYLAEqCNPHxkegR9isj4l7pGkP58ZgE1yS5BW8Njjnk2mf/sgSO59Sa5lKvZ5L2AmBydczY8npCm6SjjSa01y+cplOe59nL57TunyVzv4+d25+TL8/oFirM722xpnPfRa/UIT7d3HTM8RpSq3ZZHZlifm1NarLy4jGlDTGWiW9upiqbADPX+8beT8steESt+TgInqC5MFhpCQDjvt99g73yUxKs1ZnqhzhO1CTSb8TeSh2xQi1OEujNUX54jlW+sekW5sMnjxj/9lzDrZ3ODru0O4N6R53qJ87jwAOjw44Oj5mfn6RudYcBpGnNBOX5+wEgJQfFSrlEhc2LmCPjnn00UdsPXuOqRZx9TI6UpSqPn5RoZXFBofYMMJ5IVG5RrHaRJWnqM2dwckiWa9N1jtCjPp4vkfgcrFIMZmdekhCq3HjIcfbz3hxr0FVx8THx3zywQek2ZhSMWA07LLdG+A1ZjkzXePy6gJ3nh1wMBwincIIH6NFviVT5FMjl1lE6hCpQLgMbIaKh8hkAHaAHhzgkiOwirS9RXz8gmx0hI57YMdImSE9jXMpJBqZgRIB2ijGY4EhpNqYojnbolSvTHjXFuG8U9RMXsLkjLxmo87ly5d4770e+/u76HPnGPT6bO8fMAYunTvPxrvvEm5s4AKf5eYUrWvXsFKiKhWCcpmwVJzoz0hBZo2MZOSUvO6c+6evt2O8X9Q4CnhDWFUxidVCSu9kl+7YWQ57Hfr9Hn7g06hXKUuBl2R5KFN5sut0grW5AKQMQsJaRDhTg8VZGmfXmN7dp7O7T2dvn92dPV7sH1Cdm8WFAYfbHZI05ezCEq1mE2sdRuTVqngtAT9JY70wYv7MOkXp46eWD37h59ndOsIfZuiSjxkFlGoRUTnAmZRsPEY7SI4P0dEWslAhGPXR0RTDnYfEB08wnW1USRNGAejJ3HQ0xgqBMCPi9JCnDw55uTrF+YUWYaA4d3aVMPSYma4RZ4aCJ/CkQ6Ujsv4xae8Yl3p4MspPta/wpcAYh9Ump58mFpVpfGFQOoXhMeH4gCDroo8Cjl/eouvq9Hce4UZHKDfCZaPcYD2L9HLlBUxef41TTW/sGIuI2swsM0tnKM4vQVDGmpw/Ik6xhTmiJpuMLUueZKY1TVAs5bAyZ8mUR6wUJopoXDjP9FvXcY06VluCSolATGzA80CqfLmPzhA4VOCdAHn+kBDi/+RyDN0vU4QYVqVCaJFPDE5CX5ymtHt9Mm2oT9WplQoUgLjXp7O3jx8oirUafuQjg3xNFibGpfl0wpUCRHGR4uwsxQsZc4Mhy0dHLO0dUJ6bJQs8esMh0vNoNqYoF30Sk89whTxd2TtRRDX5lMIAXkDtzBoXbgzZeb7N85sfszlow3QdUgdjQzQticqCyLMIZXE6Jh11SMUB/WSMLjXwOrvMeCMWihlH2SG2bXAuQhJgtCDVCZ7MqJah1Zxifq7B0mKLmXqVqn+dwmQ1WD9LOGscPSvZPTwmbh+h+10UxdNiVJIbo9BgEodyDnSKTEcoG0PWJ0raTIUxC1VHU3YZvLjFVtfDDfapBpYo8lAuywVF0gyR5KR7gcd4JOi0BxzHjnBmivL0EsXWMgQVjBE47VCeQKqT2XheVXsujzjKyzk1YVAgsY5UeoTNJnMbG4g0Zer8WcTcLAiLcCnOC3JtRGch1Qgv768K6eF8D5NlwqUpzorm8fFxDeid5IGvG6B1zklr7E/k0hFOIN0k3xIM05jjThdnXU7cVvkEoXd4xLf+6f+PpNvl/Po6Z8+vM7WyiKhVQMkJZyFHNCNF7pa9AFkoUmlMUVhdBd+nkyUM0pSwWKRUilASXOZy1Qon8hGSzLkduZadmzSaBc73mF4/x5uf+hy9rSP2Hz6hGhoKImQ4TLDdmHLVozIVEJUUQSgoSUHiLEnnED0asxB5/P4b56lUp/jOvS2e7G7jU6YQ1Ym1Y9Dv40K4eP0af/In/zA/8ul1WvUK5bAwgcqDxhAFAQEKH7h8do0f/+xnKYT3ePBin/Y4wThwWmGzvH/pmXzVLHGCG/WxSZvA9VmswpXlFpeXSqy1BJWsjztOKamMogFvlObsOwE4g9aaTDu08YkTn/FA4BXrtObXqC+sQakBLshTGhVMeqMT5Iy2eV9R5W0q5wSBkhRLBUbxmM5wTGW6xad+/Mcp+oqpxdlJ6wbwQ/CCyUDGTbRFDM4anJRInZEcHcnNrS2qzdbVqDS1JoT4aNJz/gED5Bvf+Ib8/I993klk7vkmYx4FDIYxB/sHeErRqjcIVS4Z0T864P7Nm3Q2t4ifv6T38AFLa8u0zq1RW5xHTTUhKgIezgqsnrRABIgwwiuXSbOU/YM9DFBvTBGE+WjPl+JkQdGkULITJpg86Vrm/FhtkFMlVq5e48zdx3R3O/T6hlCn1JQAz8IwQYwsohnilT2CUOJFHtI4TDym7he5MFOmWCoy3ahy8/4Oj5636abHOG3JMMw05njzylU+/5l3WJ/xyCZt3thYpLVIZSeDf0dBKi4szFD60XeZn5vnn/38R/zC924xHiaoYgA6zUOvtXhOI+IhbtCmbDtcnCny7rkZLi2VWao5at6IyIyoIqj5ETLNSOKYJE1QUuIpibaCTMMoc4xTR0aZ0tQSzYWzBFPzOFEEAwKFUEE+L5+kMnoC3D1xNnrSKJ1uTnPc7nDr9l3eWD3DmWtX8PzJ/jztcp62n4co4V4N3p2QufbPRHFr69YnfHTrFrMrZ9zC6lnxi9owJ+ORftJ/wyHeia1BKqky506Tw9F4zNHRMYH0mK5P4XseWIsUlrnpJtU4QQwG3P32d3ny4Qesb5xl4+olps9t4M0toqamoVhF+N6Jvz2FQHVHMZu7ezgpaLamUV4uaesrdzpCUyKnOp7ouzghc0VS8m1Jzhf4Mw3Wr17n+MUBm7ceQH9MoV6nVo4QccowS5CZRZdiooqkPJUbYmAzxuM2UvZZLNZZvr7GhbkWP/+9+9x5tsOLoxFBIWChWcHDcPfuc9rHU1QLPvONAuUo1wD0ZY44ziazY6XgbKvEbOMSnvPZerbN4NEuLklRvo/OHHacIExKkHapupizzRKf21ji3bMzNP0YBtu4pEdYFJQKEV7m0KkhHWnGcYbwPcLQQwgPYyWj2NLTCn+qSXV6nai+AKqc90EneZqYGF8+G37V5XCT/rQRAuMcM9MzPHuxyUc3Pyb0fNbXVjAOjAZPyXyqkm+ynRSIkwjlHGI4wmxusnv/Pje/813u3X9gos9Yf7pR+18AH37jG9+QgP0BD1gOylpbE+UaeOKVLjIwimPicUwpKhJ4k5GOEMytLPEH/uAfIH65ydGzlzz85DYH+9vc/+gm3cNDmo+e0VhZZ/78RRrr64jpGYgCjJhMMoD2eMSLnT0KpYhSpYzwVL6EXAqUOwGb29f4DvYUaj4Rn8/DceizdOEi7YebPL/1hNFQY4oBycgjVAIpHYMsJR4ZrA0JfAGZRWcJSloiX2PooTzFerWEd2OdmXqJDx+85NFej3F7h+/9ws/x4YfvU5tqcPHcGj/y7nVuXFllZiqa5EFywt8QZDYHgZY8eOvCIo/ffYvO8bd5utVGFaHilzBG43ptKmbIG3MVPrMxy6WZCrV4RDgaIOIET1s8I8iGCdoYsjRhnCSkOPyCj3EBzsEog84gpYdkdW2O2TMb+JUWjgDnVK6ljXx19k+rz5M7bHMaATlIolQuEQQB/eGA7mhERo4cOkF+ucycOojTJd1GI8YD4qdPefre97n1/gfce3CPkTZUooAiMgL4wg8VIQJAa1aEFEJY64R0Qoh8h24GJEmGzjKCqk8YBjiZz1FLc7OUyiVYPcPM0ibV1gzPH95jd+sFW7u7bO8eUXv8kuMnz1m9dImZi29QWFrCq1RxoQ9At9PnxdYWZ8+eo1qtIaRkPBk9yQnF0jGp8k70lEU+C3YiX6WVK5QKgvkpWmfXKDanSPuHpDEMjUMEHoFfwKagrcELfYJIQaxJjMUpix8KXDoiHaWE5RobjQa1cJGiJ1DyOXe393l0sMfY+ggv4MmjpyRxRqlUpFxcIvLyR+yrfNu6tQYNGOFYmirw+z97lQcPXrD5bA8x7BMEGhUPiUzCWq3I2/PTXKpWmdYGrz/AmSHCWLAS7UkG2mDiMdZpMsD5Eb5fwOmINNV0B2O6Y4OpFChPzRM1FyAo4YzINa6FeE3yLZegs6ejvYmW9cmYDyh4kmq1gh+FpDol0ZqS7+H5k/fKJh0JNenNjmM4Omb8/CmPPnifD97/Pltbm4SFiNVz65y7dpnm+loLIeALB845J7zXETAW/ROB9GSmrTmpkU5+6SxL0VpTLJeo1qs4KUlxeEogykWECqiVpygtLDJzbo3nD+7x8tEjhrsHmHabpwcHdF++ZH1zk5mN81TXz+Kvn0EENYb9Pu2jNt6FkHqpjMOincGT8lTSTJ4iq9RkQ9xk4D6hwFmTay1TUBQWZphbXWJnr09vPMbTigAP4fL9cVjNOAZv4KF8gTY+2sa4UKOKPiqyyP4AtGUmKHJ1eQrrNBqDOhgzFBUGCewddPjw5j1WlleZm5tjqeWjVE6AFzi8idagcVALBRvLdTZW57lZKTHsxLh+h6LVnK1XeHu5xRu1ApX+gHBoKQmFjQXj2JJahw0UyjrSMaB8ZOAjPR9rItLEYzgydHqaBEWt1iKsz0BYnKgwOYR8xWaSp4SRE6CrO1VLdSJ/rto6SkpQn6pRKBXQOiFOx0SqgKcnsTFJwep8xBzHuINDkodPeXTrNrfv3qLbPmJ2cZ61q1dYu3FNLF67gmzNfdpt25IQYuickx7A+++/P3GH8iQNQJATfix5L2w8HmOdo1QqUS6XQUDmLEKQbweKPPAivEKZZr1KMD/P/MYbxI8e07lzh80nTxi9fMmDTpcnd+/SvH6VNfcFGhcvYbXBDwLCQkgwIbTZCdLDkUOwcALlJl0r8RorTEzmtUIgJlp6xVqJhTOr7N96Tnv/kKjoE8kQqSWeVGAUNnWkY4XKHFYrjJHI1CEsiMzgfINIM4Q/Zioqcnk5n1n7D/e4tz3CFQpoFbCzd8DjZ1sc90a0mjU85ZAm99ZSgZ+rN6GAcqBYnW2wPD3Fy/Zz5HjAfLHIRq3M2WKRGQPR2BCYBGMNOklzcKwIGCd5wWW1R+B7KD9C4mFSxXhs6A5Sur0MXS5TqreIGtMQRKei6qew718E5/pBSNfpZtpJszUIfar1MoHvY9IkX1d7fETabqPSFDMaMWr30IMe6c4exw+esvVyE+00G2urnHn7LWavX6W0uIBsNjEOpeZeARc9gLffftuRl+Nj6ckTsQcUEiME2hqSOMMaS+gHRJ4/UR6wSGROUj4Z8hc8KMxRnZqmurAKzRnSMKQmBS9fbnHQ6fJye5uOEkxdvEBpfgGcpl6rUShGE8iVmOQGAssE5n9ifD8ENJWIXFle5KrwZI5Cpczi2bPcqXzE1uAZFVmi7FmUsoSeygf5CrRnMdKCJn8Pk7d1bGpRgUVlFhloQiGZKQd4KzOkqWP/8Akmi9FCkiWW/qhHfzwisTWiiW5WcJJlibzPl+9fcyxP1ViZKnOUDClZw0a1wrlimUZqCOOEgtbYJGMUj9EmQwYK6QdkQmO0wJMBzpOTRxdiUkeSGcZjx3BgUMWQQnWaqFjLsYGnyZ74Ibj+DwF2T4n8ubq/J/KpiFCKxlSDkh+iB0NGvR6bt2+zc+8OUZoh4oTx4TF6MCTrdhkddTCZZnZpnivnzrF49TKcPQdRAYICSlsNjCe3xHmv5DecspndmJyYEzGBU5DtCRvLk4pASgLrCI3Fdzl+DpOduK78gSYpttNBDEYoP6RcrVGv9knihPZoQFFISp5HPBqgk5hmrUqpWML8MGzWMjHy1/YSvXbPTsBFTrgJstkiqyEz62coNpv0taGfaGpRhjISG1g8BTbRGHLA6klbyBov37urDaQOYQVREGK0w/W6NCpVLs7V2D/T4r0n+2x19/HKU0h5omo/aUEIeUqbtK/JqAVCMlspMh8GPEzGzArFuVKZeeFRGCS48QBtNFmqiVOLBryCh4+Pkzlw1DqNMbmiqovBKR9pJVYnxDGUREi13iIKi7jUIkJ5ymY8Zam+1mLLsYOvdpTkfcC865+RE+1np2dQcczwqE06HvLkk1vc/oWfp6Q19SDESzNkovGMo4BEhSGhlJjRiOTgCK92CNUpoZyPLRTqMuWCCLntHMo7nQE7V5K+vDahgOQ4sckBsjqvO5XyCL2AopQUcbgkxQz6SG3IRjHDTofhUY/RcZ+k3SVtH5Mc72G6x+jhgHjQpzvso4WgWKtSrJQYxTHWaGZmZqhVK5P6Njcrb7KOVZ6yG9wpmVfIVxzgU/D5SSoTOfyZMrX5WcJKmdhoRmlCpAJ05vJlMc5OSD8nsCyPHHSUj7NEAL4vEWOB0ClK5VrR00GVa6tzdAYxR90OVscUAiiEHtYYtJGEXi7/oZ3JR3iT9F46KCNoSEELj3kvoOU8wl6GG4zQ8RgpwFiRayJ6AUbmYhzCF6ACrDPoLB+3KetQgUQbRxILksRS8yNqrRayXsKeSJLIV0Ss3AAFrwQzxCl/5sQ7ysm2eKsUYRgyOzvDYHePeDTCxRlZnBEPU0IM0o/wg4jIg1AIpIH+aMDO/gG9jzNqBwdU796jsrwuptbO2eblyy2c+DRwm3wvAq9Rd6zl5EELd6oylRqLcY4wLFAoFIgkqNRy+GKL7pNHqNGIuNPncHefo919evttRp0eyWgALiOMPKqVIoViRKG8xFKxwvLVy0StFofxGC0EjelpqpVy/qDsCXz0FcHDnhAYTlsI4gdoET/AtZIgCpKZ5QXmFhYZvthnOE6oFUNM5sicQHpgJ2BOgcL6k50gE4V8S44McdqgAo2KLCIbUqiGrNRqvDHfYu/gmA6CRhTQKISIVGOlQ1UKpyNrgczV/12OOGEYU0oMS1GJWRMQDR02idHjFJE5kknejQyRLsA5i9YGGUpUOGkiS0B7OBSZdfTjhG5nRGocUblIWKtCQeG0fnWfcKc36XUKkzvVlnnFOXkd7B/4PqVyhZ48ZGxSGs0Zzl19C88Kqr5HvVBAOYevJD6OrD/kaGeX44NdOoMemx9/grj/kOrcfTdzdoPLnYENmlMpAO+ftmFOFFTyc+FO6H2TVoe2Lh+FeT6RF+ABehzz4uPb3P/m15GDIWKUMOoPSMdpvkPX5utLWgsLLJxZptysUW9MMTUzi1+tE62tomanGT99SiZgKoooBP5EgCffvSte48G6CYTyB1hHJ9IGvIJ0iEm4kVIwt7rA0rkzfPJih+5oTKswRaoF1jikFnlYlyL3pu6V9SpkzlQba4KCICwqhDUEgUOFKcbLWCwHXFps0VMRa9NT1H0PL00QCjwKE4iThwKctaea10l7gOrFtFSJhgvwhgLG4DKfTIMzGdZJhO/hOR9hLE6DMQ6Jh19U+UJu6yGcRxxreu0Bx70eqlag2mrkkxYAm058zIQ9d8IXmfBi3Cmr7ofyQTFZFQH4UiKkZJQZpJNUFpeZXVrmzMZFgtDHD3xwGqEmJeNgwNruPoOXz9l68pSnjx5wcHDE3uYWz7a2OOp1mLmQT0Pef//9HwYjvM6lP+mz5S+d0zRzdAMwisfsvXzJ8wcPKWWGehhS9kOqSy0qU1OEtSm8qRrVuRa1+RZevUJYKhOUa7nQTb1GqgQ6iHAqmHi+/L0n45kczStsTu2caES/4sK6H6QiTo51Ll+bf83M4hxzK4t8z1pMnGKEIs1yKVvlgVL5nrcTAZ8TdyqEwum8MSsmkh+h85BYzDBFZx0KznFheQbZXOTC8hwVTyCExRcq7wG+RnYXWc7DcCkkRwP0UY+K9ijZCC/2kbHEZvlaV51ZLApP52FbBQrpTwb9ymCExaQGGUl8fEyi6ffGjLOM+dlVFtZW8QvhhJ6gXoUH4X6o6P1BUtMJp05MdkXkZzNfZ+H7ARm5wpaNPMJKcUK4ygcsk9OVo7C1JVxcoLR+hvK588ycO0tna4vN7T1uP3pEu32Mv1+ffNMPGOAuMPOL2Oknq6m0saROY6Sb6NGBVyvTOnuG+VKZVn2aSqVGa2aG6nQTr9FA1GsQBRAqKBZymI61WCmRUpIah0ZN9mTIHxI2MXmCLE9EDOQrqQ3H6WrW092pJwdcgjA5wjdolGnMTaOiEN01GC1JrUQZh2/zB2tk3p6QE3KPELkqvqcU0nO4VGOkxQkPJy1aQGZSVKiYn5ll7uIbtBZmkE7niv++jzEWKyZ9SekxoeTCwJAeDTHHY4JUEboQYXxc6rCJwGiJ0z7SUwjlY5IJYEEoJAYbgzUWq+xkVawgjSFODE76TC8sMre0ih+GOT1EeZPD+EMG+EvobP0iuqfNM0PlKXzfR0iPxIyJdQqugBUGUntKt7FGQ5Yv9yYqIGYjSvUpSstLLHbaLOzsUnnwCOuHqGIx/zFvv/3DHnDCoHKT4fIErpPZfBhvJBg/H5PJUoGVG5dZWGyxMDNDod5EeBFBVEAUQvDlRPgHnK9yLsZElVS4XFBRO0uWOawVoLxc2ep1xSssarJjzeW8rh8QYDwdfk90Xk7+0TqXS4SWJdXpBvXpBr22ZZw4hHaECJTLVyUiLdZqkAJlZQ7hMg7hg0e+N8ulllQ5rPRIFYhIUihE1GZaLC/P4VUitEko+CU838M4g8XgKZVfvxKQgjlMiHf72IGlbIsENsSMHXbsQAtw/mQRjo90QW5sicVYi/VB2XyOK5yHiz0yC2liSFOBLQSU6g3K9UbulvKqcdJIcK8a0D8kXfS6hGdOEc6XVTvrXuviiBNeHVpMSmgJwndYYXFCIgMfoYLcb5Av/6ES4MpFRGua+uIi186fRwUFkt5oYn+/yADtazS+14RtlEB6OSdDTxTdiULmLpyjeP4MfrkCfmHCvjpRabI5k8rZPCxONItdzjjMcyMmIdNJrDm5UZPGsjWnK1IFDu0swkncJDfJC4Z8tagVE/X8k3aWeqVSEdWrNGdnGb8cMUxiSD2E9FDOy8V6ZG6wQuWAB4Sa7A40GOPwIw+nLOPY4JQi9gyjxFKrN1hYXCQqFsiERigPz/NytXpn8k4C5LtNrIARjPf7tF8cMj4cMx3WKKgIoxNMKpBWIYWXN94zNRlx5Q/dapcr/SsPpSVSeGRjzXAwZug0qQYtFFGpgl+tYr08hThRzEK80og5Je//AA3odRHFHJpvlTytjhUnaZjBTmKPJtdDFJCvDyO3jwmMHkNeN6B8lOejwgKVqSmQHsU0/eVISa8JgAlOPZiS+fpQNemzZYCSkmK1jo/O2VxZmgNPASFzjT7n51WcmMB73ARDZsRk27gUqEAiPYGxWR66JugWnEQ59cogJ+uyBK9gQ86dtBBOhCfyU3ua0HjgT5VoLs+zf2+b4e4QZQtEvsJqh1X5Q7ZO5cA0eTLyszmpTDiEB8JTJNZhEkMSgCqUaM7OU5ueQYt8UhOVSqhA4qSdrE2QCJMboDQe2VHM5qMXHO8coQYWzwmkD1YLhPNPiylrTU5yM5MmGQ4jLEIojMy5zdJ6pM7QjxN6jNFSUqiXKbcaUC4iAoGx+dLpk36u+4GK1/6AbIl7Lbd2zk6eYX6vDfns3Dp9svQzLwydy/F+wkNYk8uiMNl5pyaKrCesWMDIfN+eAtzEM/+QAc5NyoycN5xvO59oFFny8ZIxeGZSOzmwImdVSaXROt8Y7qngVPbMy7c4Y41GmNyQpZoQYE5MXgGewaExLl8YeLqb92S780RoWwr5mme2E0Hy/GKkyyFQk33luQf0IGpFLJ5f5uX7Dzjc6lCSAULKPLyleb/HeQ5n5Ok0IMc1OIQnSdKJJ1KCYWIJZ6osblxgZvkMzg9IAT/yiIoBwpsgnie/x2S8CRaONw+59/5t0qMhzbCKl2qSeJzrWqv8Z2udHydPgmdFnmNN1L/MxFpyYdJ8t692kk48gprH6vnz///2/jvIsuy+7wQ/55x777P50ntbPsubNtUG7eAaTQIkMCQY0syQK3F3qdXGTGgUM38I4pJobGhHM6EZDjUcxYqUKFGrmSABkJAIECAb6EY3gHborurq8t5lVXr3Ml8+c805Z/84973MagMCIEgCI76Iiu7Kyqp8797f/Z2f+Rq6Roch63ZpsqmOumXmIlp1yyY3vPW1VoesUuq8m8XG1lJrNNA6IvBka2GC8FpDG08154pN8r+LHf+dcoayqeCjzXspvKY9zRZB76ZGJSLldxtMvFk7aGtITIy2BqF8Vzjb1IFDCOLEBabjpG46jsutvVeqXh8nISaJN69UCjq1qQKARN5zbLDlXxObZeO9+ikGMh1Zxie30zs2gAnACE1iY8IoIgwTklATRwlxI0GHYBOBiUEnAms9Eu3RCKGWWBIVUOzuZ3hiJ/nObiIpkZkMfjYLnkpHEc2ZpRtAW+souxsLayzcniVeq5HHQ0UWE8boxEmwtXT/kAjjPq0wTS0NgU0ESSRoVDUblQaNUKOFRy1OkLksYzu20THQx7smK++QLBLv2YLc+50irfoSa4lTc21PwVZhK4Fw5vBWpEGrNsW5mhC5liqeIdExSZy4lKPIbA1Am67jYmOYbalGpRcFHPjQkxKbaOLEQYxkczwjUk6pdKpUumnzbiGJE3cUNLNZCkRtCu1YwPdcZ7y+XqERRjSTs0llZrXdIjRut45f0urQbkqDWuNEfJSUSE+6tVxW0bd9kNE9E+S726iakErUINSWONHEcapM0DBEoSZObOrh5qONh7EBYQzVxJLv7KJvbIJcVw8mk8f6GTLZHH4mC1K5h8Q6nq+yynWvWmArmvpKhWgtxNS0I6kb5UoMY0kSjUlofR5tDNpojLRY6cwTrZUYI9AJhI2EjXrIRhQTS59iby/920bJdba1lMCEFS10thD2HYJN9w7e7Pt8QRuDsRbP81BKpavAze82KfHdpu/bmM0uIhXSb/2j2miUUAKoBwQzzT+QKUFYCSHCJGq8npauVohNtSnluQ41NoYkxbglqUWUL3w84WO0ddb2afEda4PnB/i+78Y2qcooQqSC2c4nt5DLIYWgvFqmVq+6Ny+2XLTU7Nm+6zl1/m3CmtawUjSVKbZkQOtZVF+GwX3b6Ns2yoZIWI8iRJBzfGMjUDKDtB5RpKknCVpIrPCJjSSyggiJDbJ0j44yuH0bqtTmvNQyObxMgcDLOMGhBISR+MJ3Wi7W7ZPDlSqr0yvUV6tI7RHIHNJ4CKOQRoJ2pHAvNX7RIiGSmkgaVzvJVMnVpGeP9NiohyyuVxBteYYnd9O3azuyw3c1XOoPIlMRdr5v89TNua/F4kmJMFCr1oiTBN8PUstYNyP0PKfFY7SmRXSzqWnOZhOOsALf923GywgJM8BLadLTaVo6KQA8T9lmXySaGpvWEniKTOBjrKFSq1IJE+J04d700bXWlbhSSZRSeFLhe16q7mnvlZIVm0d7IV9AScHKygobG9VWTWDf4/i4F82R/rzmsqm5YRdburumILkPfdsGmdi3E9oybNgYrSSJUG77EAlMoohjQRRZwsQSG0EUQzXUREKS7+mhd8d2siODhJ4kFuDlc/iZAKU8J/JmXaEj07rPpnDysNKgvLBCZWUDtMBXWaz1cBSXZnkhWyMPIwSxsETCEKdTg8QaEu3qZCE9qnHEWtyga3SIHUf2kR9qh4yTyXEFYFOw6Ad/NQEJgXBA35XVFaIwIp/Nubp+yz10pUO6dJSglJPiS4y+p2lxR1nrJqo08Yl7RkOJ1vlmxIothWkgBEEQYDCsb1TYqDWaeEa01VibpK7fyqXiph6TNiRJgrXuGJbpm5bCSYVJIBc4O6i1cplavd4aBrUU78Tmw9AqMloLEHfstzYhrabFpULhpY2UhfbBTiYO7aJnfJA4A2txjQbWmcLUI8KGwWqJSSSNhqURWxoGyrUakYTOkUFKE8PYtjxVGxNJg5fLoAJv80eK1MXDbHnQtCUOYxq1BmG9gU5MKqaUzitpNlLNh1gglMII59Su0+LdCEtsExo6omEjajYiyQtG9u1gdP82VEG6TYUUrqMXtIbJ73v+vkeRKLbEiQSSOKZa2QBjyefyeEq1KiGduCNZpWhrIVzwaW3dHNFsSoFqrZtpJbO190i74PsMgJLq7JYl0ub7ao6IjHMU12ndZ9N9orWmxYpKEs1GZYMoapDN5shms3ieBGm3KNjT0iPJSA9fedTrNWqNaguO1Yox8eddNVpoXvcm3FhEWsDzHHTfs4geSf+BEXYcm6SyWGFtruqydJDFNIxrlqR0VgVWI4UlCTTrUZXObIGu8QHyPUUiIkKhEYFCZlQ6x2wWqlvgYmm3Zawl1glGWLwgC4lCazfXEylIVKVa1QBWOfkRi9PEEVLgSYlGE6GJ0dRFTJjTZAZLDOwdp228HRMYZ/8qBGrrjvwHfYlNoEcE1MKQOI7xfY98NounnPqs0TrdHm2eT+XyGpXKBu3tHRSLOeIkwUrXJauUBqoxNxQyfCct04HdffGC1lYrKT1h0jorlTHLBK6ei5LY2UjZNmw6BlEiSBOTxWo48/YZrt+8xrFjxzhw4ABKbfIRttYJErfyygYZlJJEUURobUtIWzS7ceuepqbyfRNlsikBKlo6vLaVftiUa8u4xqA43s7hD93P2myZs0snyRifrAzQwuDbtGGIFVpaYqGJbESExi/laRvqReYDaqaO8C1e1m9t2ZyApG3J4gq5xb1IOqS2l8uSKWSwIUQkZGU6bBbp+7YWbZwhtxFuXx1p7eZmUtCwMbEyNFTCYrSKP1LgwFMPMH54AlESWG9Tes1NRLZI91rx57W+W2+NG8wLZ+QTRhHTM3fJF4oUCwV85TK+57mtlhSuiZqaus1bb71NvR7x2AceoVQaRwib7pOl00ACYsybnlCRtdYTQiT3DKLjWBaVRLjOKcXdWQiAUluBQiFHpbbB0soqYz1dSOURJYk7gpWHkoooDnn5lVd46Vsv4vs+e/bsdsQZa1NUiMBKmyp4OvupYqFAqb2EThLWazU68gWUcJN7+S6lXdFSSt761Not44HmYMYY50yupOd4rB2KbY/uYPXOMnev36Y2tcZybMkLn6LMu9otsWilCCN31Mm2gPaebtq6OjGBGwDjKzzfOa9bo9M6WGKMdgEnpRsmW5CeoNhVpL23A1X0iNYTGjJENgEYFowwJFhiDMJIjDBEJiE2mhCNFIIGEQ1iatSp52L2H9nNE5/4IL37+tzEQEo8sQXhZ8UPXvulbFltQEiLD0SNBteuXGN0YpxCwd0XnYoCWJ2QCXziOOa7332DL33pP1AstrF7904mto2n2y+D1hZtIgI/h4ds23p83ZMBfd+/oZPkrPKDI0kUG5AyFSIgl8lQKBQJ44j1WpVYG6SClfIac1O3KRWd6/n03WmuXr3C5SuXuHjxIjdv3KSnt5dGo0EUhhRyOUodJTL5fOt4LRbb6O/rB2ClvEohm8NXEtPMwk0V0PcyYWk+59axR1SqoNVs/V39qdzuUoHokux5Yh/luUVe+MJzzE7NM5LvJyM1cQOI3ZGXaENIQj5XpLOni2xbHjxJErvazhPCUQW0o0yJFGBh03rHpu2kkYL8YImBbQNku3OEK2tUkxqGGF/4+EKiUegUym+s06R2MzhDZCLX4RckS9Uya3aDfQ8d5uFPPEbvgX5Eh9PK1mbTlkujU3Fy9Y6l2/vBD7Y6+FgcoEfSsJbVcplGo4EnJTnf7arXq1UqK6vYJGagr4/1SoXrN65z5fIVBgcHWV9bR2tDea3M2voage/TUSpJT2W0NvJrW2+h1/QCTs/kNYzYaDq6CClaR14m8GkrFakvLVGpVYm0E0xcLa/xzZe+xUa5wuDgMGtrFWZmZ5BCcvnyZb7y1a+SyWZYL6/T0dHO8QfuY29xL0pK4lT0vJjL0d/bT7VWpVKpYHqdBrT5c0YIW6W53812cOlfNxHUnkzh8YbizhLHfupB5hdnOPPNk6ytbhDFCXlVJKtyxAIacUwiNJl8lkJ7GyofOP+OJEHpVLFhCwzMtvxKNGjjOIXaZUbZLhnYPcT4vgmuLpxnZWGNrqCEsAId4b4PhZaC2BjncScEBAqDpE6DRhxSz8b07Rzh+McfZ9fjk9h2sMI4sEMTSi8cRcK2VpZ/Tv38XjVg+hfX6w3Ka2vkszk62tvJKoXAsri0xNkTb3Lz+g06OjqQQnLp0iXCsEFlfYPvvv4Gy6vLzC/Mo3XC3r2T3H/0AdHWJpQw3Nz6PHjvuJ/CSHtBwQeEELa5YzVAPpOlq7OduYV5yutrLcsnIyXrGxs8/41vsLJcJp8vkCQJQSbg5s0bTE9PU280EFLygUce4YH7jpHJ5dw8MNFoIcllcvR0ddNo1KlWq26AvNVcTLw7DptBp1tOQIL0UGzRDKX00tWfIzeZFANuhaVjsoen/tZHyeeynPiz11m5u4r2QWYCSKAaRhhhwHPbDuErYquJY42Hj7XSmcgohdWpuqnn3of0PESq4tDc6HeM93D4sWOU7y4xtXYDLzW2trETAXAuniqdKgiErzCeJZSWim6wIauMHhzn0U8+xb4njqB6fEzWOjgZTRKtTjd3vlt32u+vAX7nCKbZVtRqVcIwpNTeTldnN76UaGNIopCZmVme/8Y3mJ+bI5vPETYitNYsLy/yx1/+j25kpGP2HdjH4EC/DQJPCCFu12rl6vsFoBRC6MTabwO/gnGmNCLdYORzGbq7OjHWbS0inVAFunp6+chHP8b68hpff+55VpZX8AIPJFSrNcrlNUod7Tzy8MN87GMfY+fOnfieh9YJUkm0sPhBQHdvD9Mz06ytrRFFESKbbUGtRFPNPb3ATUiX2NIxS/HOSFWbe+N0q4InNkdMnYrBo+M8Kp8klwt484UTTF+ZYbmyTke2A1UArSDEEiXauYNLSZDJEgRZrFWEUULG97FStMaQTb6yFK6OQiZY6+H1ZRg/vofDK6uUK2vcOHWdnM7Qne3G97LOpstIl9GkRywiNsJ1qrJOtjfL3iNHuP8jx9n/1GEKE23YjJuEGusIVV5LZE22CObNIf7WcYJtbUc297qpubuT5UhHX9oY1tfWMEYzNjrCQH8fBlf/DfX188jDD7O8uMA3vvENZqdn8QOPXLaAjhNWV1fxAsWunTt44onHOXr0mCm1t6sEpn7zN39z6j0VUludcKMxj+8nQgpprLGuB4Z8kKGzvQNfedTqNWpxTAPoaisxePw4s3fnuHTpKnem7qB17Fhq6XxoYmKCT3z8E3z0ox/B8yRJnJAkCV4mg7GQkZLOUgltLOtrK+nMaFNa/PsYX73P0WJbnBErbLqJ8ZzKFhbaJL1Hx/hAW45Me5HXv/Ead6/codwoI9M9ZyasslZzRoWeFxAEOaT0HCjAOpk4399Ek+gU/dOEzbkuI8FmPLJjRfZ98Agb1SqVqMbC9XmieJWczZGRGdcsWUEjqVKN6piMoX2kk8mH9/HQ08fZfv9OgoEMNmdTmesUBKDsPc2ZTZvH9ztmbQsXI961jrOb+1lWymXiKGb3rt0M9vYSpwSuno4Oeu6/n8r6Gnem7lJdr6J1QjaTIZEeIo7o6+/hkUce5hMf/wQjw6Pu2kTJ2c997nOWZ58V73cEs7SxcaGzo+OO8v1tJoo01iiQ5KWku1gin82zXq+yvlGF7h60Ndyam+PSlSvMzM8RhiH5fNbxbuOERqPB8tIyd+7cYX5+jt6e7pbRjMP4WwKlKHoBSklq9Tq1Rugkt1Ns2rsP3vfwSXuXJWZLUhUrJNpEKRRfpHWOQSmwRUlhVx8P5Z5geHyYt145ydkTZ5mdmnO7zcoSd+ZnWC6v0dXTixCCMAqRVuAFHok2SM91oDqVNpNikzSPcpAsaxNk4FMa7+Hhn3mKnoF+vvNn3+Lim5dZr9TwbYwnfFCKMI4QbYqR3eM88NRDHP7gYXomO1FtHjZwjEBjDcbqe3zhZQqESJIElWpqt1aqzfNYuCZtK7RDyq3cm3QPbC3Lq6uEYchgfx8d2RyVOEKlu+qFhQWuXL7MzPQMjbCx2Qhaw1pljViH3Llzh+WlJQYHhhBKWZ3o5wH7LMjPvROOtaURWQJeBrYJZ6ejkiTG9326i220l9pYWS+zurpCY2SYxdk5vvJHf8TX/vRrLMzNkfF9tPYcfk1rwkaDy5cv8n/8H/+eer3KT3/8pxgbHcP3vNa8zKYrvMG+ftZWy1y8fAnf9xnu7nKmzto5oNsmFZNNr4/WwNW+Ix8KcB+nOQZTaeYT6casaWxtMTlBdkeJXV2HKI12MX5ggktnLnPh7BWu37rBG+e+S++FYY4PHqfQVaCaxMQ6QliL1MJxdJVEpKANgSVKIsDgSYX0JcSOnCSyksKOEgc7jlHq72L75AUun7vC9fOXWVhaoqOtg1179rDn4F7GDo4zdmCC9m0lKII2Gm0cOUhJgSeaFMtN3q8UwpmAtwbzovX/2pp3seI2N+tOjBQhCI1lcWWVtXIZcGKVTrBIIo3lwuUr/NnX/oQXnv8GV69eplEPyeWyhGHDgVEsLC0t8Z3vfJt8IWf+1t/+z+WBg4c3wrB2451DjPfyCYmSJDmllPpFixXWvYQHtGV8utrbuXV3muWlZVbXNyivrzG7OE93bw/jQ8NEjQZTd26zUi7T39/Prp07aYR1oqjB3NwsjUaYAjZFy+8jsQJtLOOjo6yWy1y7eoX2tjZGe7rAus2EsGoLcte+43m9F+T1zvmgwaKEcspOrT2x52o05UADxrOIHkV/aZy+vcPsuG8PPa+cxH8lR7m2xu2719i5MkFb7zgkhkRHzoZES4TVGCUdd8Jzs5AWujslOYlAYOMUWCEsottn++O7GZ2cYPTUNjpf7WDmzgw9/T088PDD7H/gAJmhDNazaDTCCKxqgTOx0kNaV+IYBInZJOtLpRzf2WiHVG5KzG51UzemtS4UIhV8MgalFMvVKldvXCNsNOjr70dKiQYC5YHVzE5Pc+vmTXK5LA89dBwdG2bmZllaXCTI5Dh69BjZrE+1tsbM7LSZX5j39lpOd3Z23vr+7FrjxkVULsGiBAZfSVQ6++pub6eYy7GyuMLi8jL9/QN8/FM/R+6T0FsocevmDX7nX/8r5t58kwMHDvALn/55erq6WFpaJFcoMDQ45Pwy0giRWGLrivzOjg4G+vu5efMGK2tlyvUGHbkcPmpLtryXMCC2ZLz3QnaYe5hf7umUW5Qomj4usgmqCQDfp3f/KE+NdLL/kcPcuHaDldoq1WqFSmWdho2w0iKNRdsGVgg87XxMrJFIJfFVkPJaNpsAoaS74onFJGACgz8csLdjHyNHRogaMX7Oo629jaCYwQQpMxCL8gVKpqRRkbpfphW6TEGsDlEuUvFTgzFuRmDSfXpTA9Cmq0MXfHJLSnR0h9W1Mjdu3sTzfSbGx8lnc5teqwK2bRvnZ3/2Zwl8n9GRESrrG3zh81/kK1/9Kt3dPfzcz/88Dx2/n5XVedYr6+b+Bx6kEASvCSnXrLVKCKHfLwCNtYhqtXZamtw5z/ePmCTWvnQQCGuhv6eHjvYSM3PzLK2usn/nDsa7uymm/1h7R4nu7m78wGf37p08+ugjFAoFJ6ZUr+NnfISS96wqBU6LJBCCUlsbxbY2EmPYaIQUs1kn6G2bntliCyRVtJj97/Uy7zG6MVuwPibtEt2NSdEjUqCFQeYUhbY2tg200b99kMXVBTxf4nmSvBe01ulaO5/fREh0FBFJgfSVU3mVnhuHSOsAB0ZuAn1TmWHjGfxen67+7q063c7A2gqnxSdECqc0CJNgVYpEssaRgKRoXRdjtKMSNBVCbMsFZMvDap0oZfp7bRyaHSWIrWVtfZ1atcr2HTsYHxlBeR6xdZ4/SinGR0cZGRoik8kgpSKOIyZPn+WNEyfo7O5m/7797Nu3D6132kZYU9l8yW7U62ewlpd4SbxvBnQSHSf8YrFvNgwbrwVB5ggWK7TBpJzHvq5uOkvtXL5ylZW1NWKtsUqyHmvHNlOKXbt2UN5YY8funSjlul6HH/NaO1MhVAvRIoVtoTDy+Ty9vX3UazXm5+Yo5XO0ZzIY0xRPTItu4fSnm0fQ1kbEbvGKfOe8X9jNrCmEaGUYhE3drAQ2kMSxwTZcEGR6c4wPjGETg4kSrDJoLHEco2WCNcYhP9LNiMFQTzTK88l4fpq9HdnA4GpZGbjsZa1w9IBEuzGTcXWd9DyE53S4pXE0Bp047oVK549COsNFa7Tj4TTVwpq1n/DuGb9sTqlECwihrSVOjEMyCcFKpcJauUx7RycDg4MUcjm3u7ebVzMIMlirSRLnuBlGMX2DAxx/6CFyhQLFUtHttrU22WxeYezlxfLcd5ww5ZN/jlUX91khBNLq54zR/xcghzEWI4WnLMV8ns5SB4HvUy6XmS+v4nV1k1MOvNheKvGRjz7NgSOHmZzc43gaUYz0PZTvgbA4gSQ3KG4CwFO3KkqlErt27+LkiRNcvHSB3q4uOvv7HNklRUU3jfqatZZ9j9HMO4GYm/J4FkPi+CWphJrGoadjY4mtcXByaTHpQj6WzizHOX5JjHWD35znY61uzdaaOLpYJ8Rao5SH52dd5tUalHMcjTBYa/CExGsCKaxxbufSsd9AkOhkk8ZqUm0IIZHNFZHnpdDj5kVxnsake3SzdSa4pVyxbL5fN0e0KAmJNtyZusPKyiqDw8N0dvcQW+dS5aXYgCRx0Ds3YnO770wQMDk5SUdHF9lslqHBgTRrC6tkQEzyyvah7bdffPFFTwjx5/oFG2OMYI3vxF502/eDvXEYWWEtykAxkHR3dpDL51mvrLOwskR3qZ2i56OkJcgG7N23j+27tpPN5lAIrE1AupvsTKXZgo6xLTEibS0FKRnq7uZMNsPs3Bwra2WG+nppAjyETekArfme2GJRv1XfRLzn4m5T1aN58R0sInWkdbzcpmLnO4Y+viIVDmn+mcVahSe4J+dm76lpaHFsEwHKk2RS9T0//TkRjk6ghEqPUuX24DaFMXnvmDIl7vvRtBBCmzWNY/kZYb5P9FVaW0pBbaPOlStXWV4rM7l/Hz0d7SRa43uyBcUUKRDZpoh2gSsvhgYHGBjoB+mjFCQmxmKlQetEh98GePLJJ/98v+BUKUuJDrFSjaqv+CrYq6Qw1qCwhjyKvu4O+rq6WSmXWVhYYvfIKL7vu77UOqgOXg4pHcNKKh+sQCcJ2mi8lGnfhHGLphZJE33jeQwPD7NR2WBubo6ujk6GenocHtFYpC9b2ELZxEYLp2otEO8YTm/RkUE7/B7C+Q5rg5A+YCnXYpbX6tQasXMx8hWJMURJjDWGnCfJepKs75HPBuRzQargalPLK2hEDSob6zTqIb5U5PNFcrkCge9hPLf7rugYnTilLXSMspJs4FHwFEq4qZ7RIIxAITE1Q7gWEtdjsAY/55HpzCGyCmNcaSOkvEcvx/GvZYuG837YwCYvWyGpJQm37t5heWWZTLFAd2cn7X5A3TqbXI2jDHgtnH1ariZuDekHHkJIYosDYySJzQS+xHAtUeZrTQj+99UFN2+X1PaPjK9/CfCdzaklsYrOUondO7bz+omT3Lk7Rf3AXsgVnPOPEm68kZK7t4aC6w59V5u0MH6uODZsatJZa5ncvgOrDWdOvU3gZxju6XGwpNQ32Ffp/tPe2w+Le3hy7zGSMUnLkkAAvpBUooQ3T5/jpe+c4MbUHLFVeLkAK2LiOHRCkcbiK0FPdxf79+7igaOH2Tk+Sj7jAJpxHHN3fp6XX/k2r77yKkmY8NjjT/DMM8/Q29ODRdDAcmHqNldvXWejUiWp1uhv7+LYvv3sGB5y/sTGYkzKp7CweGuRt156izs3pjA2YWznKMc/9BDdu/ta9W9TyOmegYBoqRe3/PWa3GmTup9q6wI+kII70zOcfvs0XV2dHDh6lFKxiElppdK6Rk1KmyYN0TpxpHBe0tbYlFctMMKClEYKT8U6frOkSovv7H6/ZwA2Ha2z2bVva+3PS88ftTo0Snoytpb2TJad20Y5c/Es09Mz3J6dZbCtg7Z0noSVKGGcukDa3DfnTaLp+/ZOCmXLs8c9sV1BhqGBAS5mMszNz3Jnfo7B3n58zw0PEyucRx0tpQh3kDdl0VokOnsPVcQNbE3L21kiiXXE1N0ZvnvyFOeu3sUKH6Rlo7aCNiGep3DEQ2hrK3D1xi2mZ5d5/PgD3H9oD92FgJrRLK6tcPrSBb7+rReorNcodHfzyIc+RAewlmhuzS3w6pmznDx/mkalwmCxk/Z9bSjfd+7vjuzqBDKRYATVhXVunbrCxbcvEomYqFbn4NFDdG8pD8xWbkwK5BVN4UkrW19vPqwmTUWOeC6ohyG3pu6wuLjAA8ePs29iwnG0bVPpNZXsbSJT2AS7Ou0eV165Y1mhHI/Zlcye/6U0+73ny/seqAgphKglUfS7QolnhRLGU0ImWLJCMNDRTl9vJ3dmp7l46SoT3b109vajU9/kTCCdQCOOpyBTbQ5rLFLaVkfbGkGl0CyEQwSH1lLIZ9kzuYfr165x4swZHn3gOCNdHSTG4d8SByDeoiPY5Fmku9J0HLx1hO1IUq5E36qRJwNnYtjWFaOyRYrFAEkDqWJymRwZP0dYr1Mur3BndoWF579FtdpgdHCQgUIPQgm0kshchlxXOybI4nV0YDJZasC1lTKvnz3P29dvsbBepy1XYNe+g9z3wIMM9felfBqbhrl2BoZakkkUXeTp89qJbERJ5BydU292Wo666a5Ds8AQTY+XJkoibWSck4RCY/GF0368cuMGs/MzDAwNMtTfT4a0UUqJ6rTwlu7IbroibdbxqfxK8/uMNb7yRAIXyvBcnxDWvsfxy/ex6ydprH1eqK5fFUq5c1NrYVHk/SzjwyNcvz3F9PRd7s4usr2332W+Vibb8tC0aj35jk3u5mZDpJffYomsJp/JsnvHDmZnZ5m6fYvt4xN0tZew1qKUaDmIa+MMw2UKh7JYEp1qy0jphptN2fMtSgByyzhGKh+VLWCDDSIr2H/oAM988BhtRY+GlpjI59atu5w8eYIz585zd3aWq7emWVypUpvowShFtljEK+ZIAg9bFPidbeh8juko4eztKc7fuc1qLaSzb4A942McPnKE0cEBAmcoiWdsCl9PxycxKDxyOiCfBHjCkjU+KpGbIIstl9G8Q2nAUeQsJAYjLcjNgX5kDUjFanWdU2dOU1uv8MTjjzM82E+SOtGLTQHkd6u63YNFanKaNUZbtEEHSvkx/H6vEJX3O36/ZwCmzYgEprSO/6NS/qcTHcUW42MVvpJsGxtndGqKc2fOM3VnlsrkJG2BE1C01pkyp8+j20AIp8W3qYMkU6iU3TQ6wY0+fOGm/n4+z46xbWyU17h05QrZQpHdI8MoDIl16llba75N+Qk3Y9sk2bxjMiicxpyTmnPqXFYqIu3Khr7+Xj7w4AH6FJTd8oKBvh42anVuTs8yv7xEPUyYWVxmpTGKn1WIjE8DqJiExJOEOZ9lmTCzsMypq5eYW11CeZLt4+M8fOwYe0aGyUuREvkd9N5tT9yssClqaUKDDN2+XCSpypNJ4WVp82WFU2K11lE9HV6tuQtPWhOD2DpcZF5KlutVLly8SLlcZnRwhJGhYQpBhlg7iwy5Fdgh7sXSNA1tWhZq2JS0ZkygfKWhXIc/eU8w9nuqEb3PnwshanEc/g7oWpJoJay1ItXyG+jqY2J0FIFgZm6G2aVlIuuajeacT0mFx3sQpOUWdZwtA+SmE0gG3yGZYsOe7Ts4fOgQ8/PzXLx8iSRJ3Jws7YqFtC2x4WaQeU7Zx9UmrdyqtuyNZUvpyZLuT9NhrOd7IAxhIyQyBpIEzxqKxYBiqQ0V+OBJYpuwurFGox6ldqeaSOC0EDuKrKiEi4t3OXXzElfn71DTIZ3tJXaNjDE5NESf5+EnmsAkZIRrcgSO4E9s3XwmckQvYaUbQG+FfutNpQhh3zFyt5ukLeF5WM9zggKmuY4UTN26w4Wz5xkeHOTY0SMEfkBsUprlO+LGNhPJe+3cccJDIPGlp5WS0sLvdcDpNPuZHzYAjbVWZLPFt43mfJAJpCeEdghwQ5sQTAyOMDY8zNp6mcvXr7ORymuY5mbgPTF7m1exORBt1oCbRPOmxAW0BYrxoWFGRoZZWJjju2dPU67XyHleU6aoNXPTZtOGzg1L01FsU8A85WrYFO/dbFiQAqEEVljCKMKk4IsOKSl6HkJKVip1FlaWiHXsOklh6Ghvo5DzUz8TSbGzk/7xMTpHRlhuNDh56RLX56ap24RCscjePbs5sGsnHUGA1RqsxhPO0qsppbEpquIaOIWfCge7U0U02d7apk5KprXpEJtz7dYdNilUTFtDIN0G6erdO1y6cBEB7N69h+3Dw2RbK1KxqVfTHLDfe9eaU9D0+rn3ZG1KKIEYeL5JPv+eGe57Dild5HpCiKVaWP19iUqkkEKmoiACGOzq4eD+fVgM5y5eZG5lNdUQtETaKU29MwHbd7UBmwlRbDFTcTovAmsMxXyeo4cPUSjkOPHWSa7evkGSojcsOK0XrVtK+tq4QlwJ8R6wy3f336ape5LySOYWlzl55RbfvTXNa9fu8s1Tt/j6t9/k5OkzLK2sgLEUC3n6+7toyyqn74Kk1N3N2I5d9I+MERnJ1OwCy2sV8m3tbN+5kwN79zHS2YEyrsuUwkltWCBO56RWCrd49Z02o1NITdUTpLqXD/1+/F+7eVJHWKK0afCEoLy2xom33mJlZYWD+w+wY2yMQLo16pb9wJYwa9JdN4PuXv6N28BYazUSP9LmW2X49he+YBXv03x8302IE0mycnV19d9EfvT3fM/fEyax8ZSU1lpKmQx7tu/i7PmL3Lp7h6u3bzHY00OHrzDaacQEyK3WGa0AdPtKkwafSjclm0x7KSVaayJj8QKP0YFBtm/bRnl5hStXrlPItTExOkJWecRGo6xx1mFAEjs1Bs8T93q0tPZysgXVN6nuSpIYhJRk8xkuXZniN373j8hkPMJIs1quUV5fo1HfwEewY/s4+yd30tnR1kJvxybBSomfzRPEBuXlwSrCqEFXW4n+wSGKhQIYm4IvmhnNDW+11UjhbRFjb3ri2ZTZp9wR2lQBcvKrjgmz5TM2Dzyd1q5xyq+2QrBcqXDpylWWlpYYGhni8IGDdOTz1FNPMU+KFmzNfq8hcWuBuiWbSSGMMY2Nuv1XvW2icu6cDd6v+fi+AzAFqqqurq61xEa/JRD/GwYCTxFZiy8E/e3tTEyMc3d+hguXLzA6OMSxiTGkdCJE9ybhzWPZuB3CJsm8CRBIj2E3aJatdZYnJft27kYCZ86d57tvncBYw66xCbKeIk6sE0USMhUgl+n4wWVDsUUY8d4+zhIb7eZpQoKnWK/WWFxcJjYRsdFEicb3FSMD/Rzbv5uDu7ZxYMcIg92llAguSJKY1eVl7t6dJVEZOmUelS0QqAz1Wp3bN28zmskzuG0bpVzOdehAotMsotxRi3YdcKoEibBOoSzEKXqZxLb8PkQqoi22mAY0zQgd6NxBtIQUVBt1Tp89y+XLl5iY2MbRgwcpFgqEsYPD+coBXd9FZBLqHrjHvSJtrUZbe0qqUOvvdhXVl6y1SkoR/Xnx9f1kwBShbSXw77SOfzmbCY6F2hiJkMZYAl+xZ+cOphfmuD11mys3r7FneIiir1qD53e4AGxaQdzTwd4LObVpHeeBo0TqhK58gYN791HeqHLp0mXePn2GwAvYOTpC4CuixBBbS8ZLL5o1LmMI8b7FyCZGLh0BRSEjw/3sHBuhWq1y6840i+Uy2iQMDwzygYce4eGj2+nNQaGlo2LAJFRWl5m5dg3r5elu62JseJxakjBzZ4rra9dos4auXJb86HgqTWfxLa5ZUy74bKo2JRI3wFciZXxa16BY0+SB2tZs5J4aTaWfWziYloegXN3g8pUrXLtyhWwmw+H9B9jW20u5ESMt5ALlsIVbnTDse8qXv0tn0Lghn7CGCKX+P0KIxFqrvh91EPn9RF+zmBRCbCjFf40xobJYmarPCAtjQ0Mc2DdJLpvl1t07XJ6dZU076yrdvMGGVLiRVk96rw5Mk9yz6TKphUHI1EQPS6QTcn7A/UeOMrlnkoWlZd4+c5ab03M0tFuQG+GOw1gnDr7kOQQ2Wrtf1nWNm8ADkcqZWRIdUd2osH10kF/+20/zK7/4szx63zE6CznqlTUqK0s0KmuYMN7i+aeRtkFgE/w4Rq8uUZmaokf5PH7wEIfHJ+gpFvGkx43Zed68dp3LK6usWOu0yZVoaStb7ZTnm8paUjvv3qZknac2s9tW9wWTajVqZTHSOEH51Pe5Uq9x9epVzp45Qyab4/iDD9HX00NsXfLIZjx8Kd8VDJv3w7yn0OVmdjJJxinN/U5WiK99r7nfDxWA6ZvR1lp569b0W8bar3qeVB4qVtYiEk2HF7B9dJyRkREWl5c4ce4M8+vrJEIQpRfCik1N4tQBLt0ZmxSdYtOLtoVVJtyeWG6BLllj6MkXOHrwIHsn93Ln7jQvvPgil67fQAtLXjkl/zi1yrKtXd29xXuzhlEp0kUKTRI3MFGDQtZjW2+JR3d084Hj+9g+OkhGCe7cus4r33qJS+cv0wgTN+S2gkAoAgOBBS/W2PV12gzsGejn8LYJdgwO0V5wXng35xd58+Jl7qyst+afNqWLKiVRWYUKFMTgRQnGxGgSpDR4gUTkxBZ/jnuPxtgaQu1AF4GUrFU2eOW113j99e9Samvn4QcfYPfEOIGSJECgXPcdJ2knveWMtem9ac4L3J+bpiZbs840SkiZGFMR8C+tteLZH0CR8Ps9gltxuG3btoa19p+AedDz5JCNrQ6EUMZYuool9u2e5M7dac6cPcv42DgDnR1IIfBT96N7CEQiVd0UTlLDpHg6pd7bx0IJB0AwqXJUf6nEA0ePsrFe4fKlS7x16i3wYNfoGFnPRyvhXMXTWtVBZ2Tr+LJbTA99DyQamTTIeRLiiOpGlcGgyO6JXu47sp+5uVmuXDrPydNvMdjfQX9fB207RsgpRWQyZFRAzvMJkChtCExCB9DT1cn8xASNapWF9SqVSo1LV68zVmpnolQk4yuoaaLlBvF6DWGcK6ZcClm9PU2lUiY2NfxSQLG7SJD3mhfEGRE2+b7NjK4UkbYsl5e5ePkq1y5fxgt87j92lP0TE8TWkmiDJ2VrZGZMc2WaHrO6KbV6j2rHPZuXdL2slcSPkf9jBi4C8nPfZ/b7gQMwzYK+EOJUHIb/uxf4/0ii4oxCVZKYrFLs27mDy9ev8dqJE1y8epmJoQF2dPWk+oRpIDSHVFv0/Uz6iYTkHrD9Zh3RFIRL4eeppFlbPsdjjz5CZ0cH586f4zsvv8L60SpHJ/eR8T3CJEJIj5bbSJpVraGlX6cAX4AvNJ6NkUKQVRZfeRgh6G4v8PB9h5idmWVtdZ56WOfNM2cotRfp73yaYm+J2EgCr0BB5Qi0cxMNjCFnLV1KsndwiKha49TVG1QWl6knmht3bnC1o0BpYoJsQ3Pj7Utce+MsphbR29aJ34Dy7SXKK0sYqekZ7mJ41wi5toxTYw3c7NLYVNJXCALlYazlxuwMp06eZG5ulonxcY4ePsxo/8AmCCTFzlnlHBCstJuy4Na6jPsOcFvrSE4bnURgPPATOLUCvzP4A2mx/nAZsNmQqNpy7X+jJH/G87x9NtE6tdGjM1vg2JFDLK+tce36NU51dTH06GN4nkec6JYZzSYs3h3GpmmTtaXGcF8370D2uXrNF9DQriDvaW/j2JHDeIHH6fNnePPkSWqNOgf37aOvUHKgT+OQzr5MC+0tgqoS4eZgOqaxvsJGrcrG2hxe2qVnFGwb7uL4sf0sL81w6uwZLly6iAnr9LYV+OiTj9DR0U7ciKmvbhBX64g4bjmEZtoKbOsoIbZvo1KpU6lsUGtUuXX7JqeVpVsFbFcdxJU6185donxnjsHOHooqR6MSkUQJnQM97Di4i7ED28n2FCG1PTBY8CSB5x6y1XqDS9euc+7iRarr62ybmODYsaOM9zoXrDAxzsNYCCTOGkyweeo09ciElO9WTTVuHaitxWrb1P3W9ST5J0O+v5gmp/gvNQCbgNVCT2E6rsf/jZb6qwJkRkgSKWhYw+ToNqoPNPjjP/kaZ8+dY3xklMmJ7ZSUs4P3pXCzLmNb2Dx7T6m7KcmxVVdQ2C1PY6oj2MBQrTUoZAMeOHoYL+Nz6vRpLl26RBSHTO7cRV9XD3nlg4DIWGeGKFOWGs4+oqe9xJ6JMVaXlyivlxnqKhIIgw9krFv1Hd09TmPjAWRSZ6oY0FXMMT99h+WFFfq7OshKRW97N8f2HSCMQiYGB1BJhDWGTk8iu7vY2DmBFIbF1QVMo4owmo3KKnR1MDA6wo7JPSxkc5SyRbIyoBAbAj/H8M4xdjwwSftEP7bkkZC09thCCEJtmV9d5sr1m1y/cZMojNi5ezcPHDlMd6mN0BiEsanXnyNXOVMax+nQicHP+Hjp17bugS22tdmyxt2XyGqdQ6o6/HbJ97+UNh7xDxxP/JCvZqcTh+FvekHwD+JIx1YJv5FK5d7dWOfFV17l7bNn6Ont4WMf/QgHB0dR2pJROCyfdk+elClQcovAhHgPpodoGq9g0t2jwAhJPYoxQuD5AdVGg8XVVW7cusnbp0+hlOLJp57i6K49KKBcqyMstOWzbtiNswdYKJeZW1hida2KNZqh/h4mRgbJex6JdXwMDSyuVrg5c5dGEpFRPjkhGBoYYKCvi0Y9ZGZujsXFBSyGgb4+BlM+i8BiMxmWo5CVRoMoiYmjkKyQ9Ofb6JNt+GsJlZlVwo0aItHEYYKSPtlSkVxnjmxXDlP0CVVChAZP4fsekbHcvHuX77z8MsvLyxzYf5A9u3bTXWqjlMuSUa4uNLHeJDAJ8Dwv1YWMiKKITC6VB8FhOZ0vi0ohVmkRZAVGWJNRUobaXJ5W8vEdTsyA77Xz/csIQBcrG/SQM19HyMP1RqxNIJQVkrqA2wsLfPXF57l8/SqPPPIwTzz4MH2FNsee066RC6RIpSHsPcbJ7xuAKQje7ShNqgzlo1NUtZ9uAO6srfPdN17n9tQdent7GB8bY2hgkK7OLnIZZznbxLipVl/kAjJowrxcoYhKP6oVjsCkZWtVS5I6rnvKa4117tFYwRDFkUMP+4oQSJDIVE6o+X3ZxBVTrXI3SllaynW8TYszx1t2f7xacwF/d2aGhaVFyqvL9Hb1cvyBB9k51IcHhEmCSWJyvo+SkiRJmL47zaVLl7AWduzcweDgINlsFqmaCh4pKqfleaxS8AaE2lghiLOeTDaS5G+1+/5XfpCxy48sALdmwbBSORjk8t+JtS1FOjH4nhKeYsNovnvhHC9991Vq9Qb3Hz7Gow88SFc2h5cY8kISpM2paeEm371p3BqA7tgwSCGIk5AwSvBUgNZQj2M8zyOTz4C1RHHC1OIip8+cYX5xkd6+fvbt3ctAXy9BJiCrlHMdT2c+xlpnrWWdFZkTObCpdRjEaaZVvk+CRmsHxJTSc49M4iR1vXSFCAblKbdGc9KVhFbTsM5zzcNHItFGkLWCIEk7Ut2UeXPkH5OkejAeRD6EOqa8UePW1F0uXrrMwuIiPd3dHDlygF3j28gGPn4T0qacDJ4U4EuP5eUlXn/tdV5++WUqlQpHjh3lmZ/6GMNDIyQ6ItYJvvJRSjnOs7FIz0cISQI20iRFhb+q9We7PO//ba1VrhIQP5QotfcXCcC0K/aEEGeTMPxv/SD4F1LjaYO12oq8UhzcvYdKvcbXnv8Gb759isGhYTLbttOuJMYaotTTwpNbtiBbYFqGTYelrZIHVlgSnVBZK7Na3mBudomNjQ16+/vYvWcP3R1tZDKKiaFhipkMl27c4ur16zz//PMMDg2x78Ak20dGyEh/U64iJUU1QRGOs7LpoSbSBkZi8FKof1MVFZv6ajhnA0xiHYDATzGRiXUmj1KRFV4KaHZ9pp8+gUlz95tx/9WpsLvKSjJOXoblVYc6unbtFuXyOvlCkWOHjrJz2xhDfd0UAgdctSlaRusE5Uk8qQjDiMuXL3Pl6lV6+/vo7+9PA023BIkc5VKl+E3PWbE2lb8wOq+kXzfmK5UN9VsnrPUB/cMG3184ALd0xYEQ4nd1FH9I+d7fFjpJjLFeYgydQZZ9O3Zxd2aGy9eu8fobbxAEGQ6NjpLCJJHpMHdT41i8bz+v7aYO9MLcAm+dOkWtGhGFGp1o2oslrl+5xsvzc5Q62jl4yK2cOkvtBEHAtevXaNRr3Lxxk7m5GbpK7Qz29tHT2UWb9Jw6aYqbS1It5CYKRKpUZyXtxT3pHhCbiqE38dzGOKK3UgKROoHGRjhEcpMg1AKypCr50qKVAF8i1OZRroFyvcbs7DwLi8usr61RqdbBCgb6h5gYH2fPrm30t2UwGnToONgiHdgLKYjCBvg+mUzA7Pw8b516i3179/LII48yPDbC8NAwsUlYWl2mLV8kU8iSNP2CRUsx33hIpWFmLYr+wXhHbvVFl3zMXyR4/sIBmEZ/lO6K/57RZrsMvOOm3oh93/PjOKK7WOTDH3gMXwWcPneeN7MnKWayjPf1UlBb+LP3EIhc9yXfuX1sgRskK8tlzp4+RyZbYM/uSTraO/F8j2+99CIvvPA8h44coLOjSH73LnJ+hvsPHWTf7l0sLC9x9dpVLp27iO957Ny+jYmxMXo7uykEznaLdPNimxJxKWfXItwIAicMTjrGsVhiG6VAZIkMZKtuilK1A185xphJZ5KtVZ61qYskxFLQ0AlREpHohDCKmbkzw+nTZ1iYX6Svp5c9e/YwMbGNUtFleU9KwkgjjUGlujGO8icJwypnzp5lvbLO9u27iKKIpaUlXn7lZfr6+9m9b5Ja2OD23dusra+zY3w7pUIpxRTaJoo6JfIgV5LklwZzuZtNlfu/aPz8KDLgllgUlVpU+4c5kfkPwld9wmgdCKWKUlHo7iM8fIxqNeTS5SvoxPCxDz7Ftu7OlA/sdp3+FsSgaC3c79Wya746urrZtmMX9WqD/v5B+vv7+bM//SrPf/05hIJ8NmDmzk2SpEGx2EZHVy8d7R1kBwfJ+gFDA4OsrC6zurrK3NybeCqgvaOLgf5hRkaH6GnLtTjhTXGehFQMPDURFKkygdEGuyUZJOkO1VqLTkdNDpnj1ASU8Fycp6SpptZXLY6Znp/h+q0bzC8sgIaslyWfLXL0yCjbxkbo7emmVCqRSw3FjbEpwsypdiWJIJ/NkxjDlevX+OKXvsSJEyfZsW07Rw4f5r777uMrf/IV/tXv/mumZ2fwMxmEEhzYtx/GNuezQgqMq3Z0Fryy4b8f8P0XUsJa8iMJmh9hAG6OZur1p7zA/wNtbW+sjUEGKpZQtZbzt6f46gvPMz+/wP1Hj/DYQw+yrbsb3xqUtc5GR1hkSp10fJF0b9xiaLkLtLGxwfzcIrV6ja7Obqampvj1X/81rl27zN//f/zfOf7g/fiZDJ6nuHDxEmtrFe578GEOHDlCMZfDAHNrZW5PTTE/v8jK6jqhNpTa2im2FfAzHrl8jkI+Tz6bJZvPUcoX6MgELbufd6vS0BJMMlsEuLaifEI0jahBvdqg1oioRxEb9TrrGxusrpdpNGrUa3VqtRr5XBtjI6NMjIwxPtBH0ckz0GiiUKwhEIJMS7TJsF5Z4fyFC1y8dJWZ2Xk2NqrcvHmTC+fOcujgIR555BHOnj3L2TNn8DyPzu5u7n/wQZ7+6EeZ3D1JsVBwnChjiLXRBd9Ta8b8jx1K/SNrrfcXrfv+sjJgsykJhBAvxvXyL3nZtj/UiS5Ii9HaSl/B+MgwTzzyAb718rd54+SbeApyj36AvmKBjBBE6ZtqolPeC3/R3H1mgoDh4SEy2YCZmVn+9Gtf5fTpt9m9czuPPfIoh44cIgxDKpV1fv/3/4ATJ96iVOrk0MGDCCyNRkTWz3Joci/smWSpUufO3ALzc3Ncv3GdmbkZgkyGzq5O2tra6OnpYXRohKGeHrLSRxhN4EsCzzkmGavTTl6QWNDvYRhojWGjus784jzltQpr6xssrCyzvrHB+sYGYRQyOjrC3slJ+nr7aC+WaM8XyPgeJo6ZX92gXqvjBwGl9nY8X2KNJjKJ058RkpXVVf70z77GF//wj+nu7uMff+Yz/Fd////Jb/zG/8yLL71IR0cHH/+pj/PUk09y8q0TDAwN89hjT7Bnz26y+QKR1SgkjdhEpYwXrCbJb3d63mestQEQ/6iC70cegGkQRmkQPheHlf81yBT/cRKbRCKFNFYUpMeR3TtJopAXXvomp8+dJQg8Hr3vPgbbO0mMRWFSAIHc4hW3dSNi0TbB8z38QNJoNPj2t1/iG88/x9DQAJ/8mU+wc9cuCqUuzMoCt29NMTs9S6FYYPv2bbSlIEyBIB/4BJ7rtIe7A9qLefo62+nv66G8sZMoDGlEblBbrWxw48Z1bl29Rr1aI0kSMr7ntFNEc61tU/FwiU3BoiYxztoqRZdIDJ5STqpOenR0dtE70E82myUTBHR2dNLf20N7sUQWiLVmdnqG2zdvceXyZS5fuMS2bRN88lM/y8jwEOu1KnenbnD+/Dlq9QadXZ30DwyyY9sEN69Pcfv6TT724Y/w85/6eaZu3ebcuXM8/uijPPHk4xw5cpB8vkhndzd+NoMRhtjCehjGbdlsUIG3Ys97Vgphv/miNU899aMLvr+UAExfcVon/KqNY+H53md0pLU0VvpKiqyvODy5h0SHfPfkm7x95gxozf1HjzLS04ewiiidlQVW4jUhWVsWdWCJdcjK0hKvvfY6n//932d5aYFf+PlP86lPfYpSqQRYFheXeO7P/oz5+UUOHz3GQP9AS+ioqXOSxIbIGqSEQsZnYqiPbUNud1ozhvWNKtVqlcpGhZXlFZaXl4h0iLGGpJGQRK5haHooGwSB5zRntDZ4nk8QZAh8D09I/EyGQrFAR3s7xVKRfL5AW3sbXdk8ufTojtPPubxWZnZmhuWFJRZm57l89gxf/vIfc//99/GJn34ak0TcvnmdS5cucuXKNa5fv04javCRD3+EX/rFX+QPP/8lvv7ccwz1D/H444/zxGNP8nv/7t9w+/YtivmPMTg44m6YSYhMDFIQGqNL2axfg7cX4Of2CjGXllfJjzpQ/lICMIXxi3Q5/Y91rMkE6jMm0YmUUkbGyI5shuMHDxP4Ad955du89vp3CeOEJx59mP72Lue/6/bsqRpEOpw2Kb9YepRXyrzy6qv8//7dv+fkW29x5PBhPvr0R9i+e49TjzKG6zdu89K3vgNC0t3ZzVsnTqKNYffuXU6aQmt8z8NDEuuEsF4nkwnwhHKATSnpKbXRW2rD2n7qoyG1MHQLCukQ2I0wJowa6MSRooSQzl1UG3SSUCgWyKa+yAXfQ1lNqDWe5yGU86bzhFNYDZs3Jt3xztya4tzZ0/R09zAyNMBUby+eJ8lmMnS2t1NeXebEm2+ysrrC0WPHyGYz/K+/9Vv4UvF3f/n/xhOPPcEXPv+HfP7zn+fQ4UPs3r2LsdEx+vv7kZ5HGIZ4nues1oQi1Dbu8jw/gTdxwXfnC3+BTcdfVwZsghawblj5qxhEzlP/qBYlWmGNF0iZyQQc3r2bMKzx+ptvcub8WRKreeyRR5no7EFgiY0bzSgEOtGuKXb+8SRJwvzCEpevXiOXL/D008+wb/8hmrzlO7du8fIrr7K4tMJPPfMME+Oj/NEffZFrV6/wD/+7/5ZiWwkvBWR6UhIoj1otRCYC6TvRHxMbVtdWWV1ZpaOjg76+Hrqy2daFS7bQvvSWalVvqVcb1QbT09PMz81TLOSZ3LWD7pIjMzVs4gbvJiaJXdesJCgVoJRidXWZmzduUsjmKWQL1OsN8rkCfX0DZDJZZm7NcO7cOaIo5Mknn2RidJSTb7zJ1WtXefONN7j/2HHGxsc4eeokFy+eo6enm8c+8ChHDh4im83RCCPHvTHKNmITFzIqiOHECnx6SIg7P6pxy195AG4NQicxIj6jtdVZT/6jQAgZGW00Qnbksjxw8DDZXJ7vvPYqb589S6wND93/ADv7hwhS+I8xpgXlb27qctkCO3bs4akPfphSsciTT32QUmcn1lrCOOLF77zMa69/lx27dvPRp59GJyEnT5zA6oTK2hpRGLGyuIiUkM1n6Si1kcsVHZfCWqobVU6+fZrp6WnyhQJJEtPR0cnhw4fo7e5EWycLpNLtjU60Q5IIgYkTlO9hjWVheppbV64wNXWbufkF3h4e5qmnnmBifBilJJ5stl1OuLO5CgPIB1l6unroaO9kfX2Dqbt3kFJRKpVIEkPgZxFCMX33Lnem7vBTzzzD3/3lX+Z/+ee/yWuvvc4Tj3+Qn/nUz1AsFchkA3p6e3jyicfZsX0HSvlkAkFsrDWgOzIq2ICTV1b5+fu6xO0TPwS86scqALcEocBhzv5fYRheC4LgfxBW9tdinfi+8npyee6b3IfnZ/jWd77NG2+8yVp5HfP4k+wZGUk9ykz6X0gSR3rNF4o89NBDbB/fjvBgeHgI3/exWO5MT/PNl15keXWJv/N3/g679+7i+W+8AECxWOTWzeuceOMEy8uLjE2METZC9u3fxwee+CBSKkwUcefWdf71v/wXxInhV/7er3D67BW+89I36e1qp6+7C6M1zUWARaDjyPn1BgFBinuMjSOe79m5g/GxYf74j7/M1778Ze7cvsF/+Yt/i/2TB9PBsSUTeERRQlgLkSrG830GBgZ45OGHGRkZ4eTJU5TLZaRS5HI5jDF0dXUxODDIhfPnefvUaSb3TDI8NMLeyf0sLC7iZzL81E8/w/3H76Ons5NsJsvgwADKy7rdt/RMlCS2EOBF8M/LNf6n+7rE3R8WXvVjF4Bba0KHqhe/V4/jW1nP+4NCxuuv1qNYKuF3Bz737dqF0pbA87lz5y5f/fpzzB09yrGDBxjK5lxTEDszwKyvCDxJe1uR9rZiU8YBgPLaGq++/gqnz55mZGyET37qZzDGcObc2xRLbVjgua8/x9e//g1y+SzHGnWm7tyhHoXc//AHKOTzVKMat6Zu8eYbb9DZ3UVvbxf7JieJwxAlBevrZeYX5lktl8lkAoaGh+nt7mvN+poaOJ6S9PT1kM1kkEqwsPQQFy9c5IUXnmf79nG6OnpZXVmivb1Ef/8gS0srnD19Bm0SHnjwAYaGBunv6SFfKpENFNX1NSSWzo4OfE9x7cplVpZW6O7q5dKlK/zbf/u/Mzm5l23ju9i77xD9A/0UC0WKhWLrfvhBlkZoqDUSLX0l27OeXDfmf2hX6jNb57l/FbHxVxKAW4JQW2uzQoiXYhv/556R/7YtF4xtVMPEksj2QMn7Jyfp7OjkhVdf5uz5c6xvVKhHIQ/s30dPsUSgFIFwigFJokm0bmniSanwPWcltlHbYM++SR64/z4KxQJf++rXOHPmDHsmd6N8xXdeeYVGHLF7fJK+gUGEUrR3dafeGhYjnApBsVQkbNRZmJ/jvmNH2bVrJ2B59ZWXOXP2LBu1KoMDA2zfsYPevgEGhvrp6OigUQuJwpB8W57O9nZW18tcunSRRtigq6eL11+f5/yFS/T29nHqrbcZHxvnwx/+MFEUcur02yzMzbJt+zb6+gYx6XFcq23QaNRob29jdGQY3/M4d/Ysc3NzHDx4hI1qndWVVdbXa0xO7mP77u109/YS6ogwCQmkjy8Cl60R2sv6Sltjl5Lkn/Z63q+mcz79VxV8f6UBuGVv3EifsG/ain2APL9dLGQ+Wa/FRptEF7K+mhjq56nHHqPUVuTts2d48VsvMTs3w/HD97FvYoKMp2gYgzTGdZJSpPB0p7dQbCvx+GNPcOToEQKleP311/mjP/pDrLX81Cc+ztTt25w+d4YHHzzO008/zdjoOIVigUJbCaE8Z91aaGPHzp0cPHiA1157heeee46JiXF27d7HpSvn+cpXv8IrL7/M7t2T5HN5Xn3lFc5fuMDDH3iUjz3zDGdOvc3tqSnuf/ABHnv4Ua5evcLv/tvfBQPllVWElIRhxM0bd3jzjROcPHmKQqHIY49/gM6uTq5cvki9VnPXzfOI4wYzczPUwjpj2ybo7Opko1olNpbBwREeeeRRRsfHicKQIMhQbGsj315AK0NkY4QvMSgig5XCxvmsDDa0mY+t/C97ffV8usv/kQ6Zf+wC8D1gXAvW2v8M+Ewu7/96oslUoyTJ+Z63c6Cf9ocfpq+rizdPnuTCuUuUV9ZZPHCA/bt3MtLdQy5wustJrFECMr5HZAyZbIa9uyfxpOT6rau88frr9Pb18dGPPs0zT3+Mz//hF6jUG2TbiuzZt5c9u/ambu8JcayR0sOTiuHhET74wQ8xNXWLb33rW+zcuYOxsW30dvc5Ue9anbHRMR559FHePnWKUydPkslmOP7gg1y/do2LFy7Q0V6iv6ubE2+8weWLF/nwUx/i4L79LMwvkPECxkZGOHrkKF/706/xH7/0H9i3dw8DAwO0ldpJ4jg1o06IogYzc/Pcnpqit7ePa9evUa5skMvneeiRhzhwYB9dPZ33XOcES00nzuJM+ITG11Ia0S5lsKLNf7iwWPu1xwbbzqfuleavIxb+WgIwDcIkfeoQQvz31trveop/0a68Pau10EilGGlvl/33309vRxcvvfYqt2em+eZrrzKzsMD9hw6xLQUVCOGkJ7QVGBOnYBmJNhqFYPvEdg4cOMixI/fR1lZiZHSMnbt2sba+zq2puwwNj+EJjyiMyWRy6MRJbGUyWR5//AmuX7/GH/zBH/D889/k+PGHOXjwEBNj29i2bTsPP/IIjzz8CBhDX18/vvIIlEcxX6CQzxM2Qq5fvcaVy1fIBTk+8fFP0N8/yKm3TmG1YdfOnUzu2cP03bu8feoUL37zJYJMQKnUiZ/JYbRbsVkr6OruYWRolEKx6ASSlM/o2Cg7d26no7uDRGtH/JIK6Tm2nFIKYTybWGmkRK0bmAvDZy9VMr/xycG2yl/2mOXHNgC3dsjpwPqF1dX6Mx2l4HPt2eAXEyloJCaRGLVn24QothU5d+Map8+f5+SZt5mZnubY4UMc2rePgc5ODFCLE/xU4yS2TvSob2CYjs5ulJStzvGRhx/F93zOX7jElcvXyGeK7Nixi/7ebqy1TN2+S61WZWR0kPGJCR566GFeeP6b3L17h9Nvv01Hewerq6sA9Pf34Xs+WmtyuRyFfAFPeXi+j/I8jNbESUIcRTTqdeI4JpfL0l4qEUUNwjDk0KGDfOpTn6RarfDCN79BoZDn4KGj9PT0opRPrA1KBTzxxJN0dXWSz+UYHhuju6uHzu5uCoW8s5uQpILhzvMksRaQSSylyiLVUqNx6U61+quP9fR8CeC9fDv+kwrALXVhnD6JN4FfSpLkWwHi1wJPji/WQlvIBHrP4IBq62ijs6OTC1euMHXzJt9+/XWmpqfZPznJjvEJuttLLY8OR8O0FLJ58tk8RjtuhudJhvqH+MiTH2JieJyllVXaCo4cHgQetVqdN954nVs3b/Hhj3yQ4w8dZ/v2HQwMDnD16lWuXb/O4NAQC/PzRFHUgoqtr69jraXY1kYmkyFsOPt6nWiK+Ty+8lheXmH67l06S+2srq5QLLYhpUUqwRNPPMHC4hz/6l//Nkp6PPnkB2lvL4EQKCExwm1vtu2YwBpDJpsjUEETLEpsjOOMpNqC1krje54R4FXiKLxZXfvdmzfLz/7Csd2L1lrvWTBP/TUH349FAL7HkSyEEL9rrX0BzD/tzec+ZSBTTnRSymTkQ/v3y10TE7x55gwnTp7k7OXLLCwvs7iyyu7t2+nr7KSYy5LzPHyDywLW8UkCP+vwe9qSz7Zx+NBhN0y2oiVOpLVmo1Zh6u4tTp1+m46uDm7dvglC0NXTTVuphFKKbD6PFIK7U1OslVfIZbPkcznKKyvcvH6dleVlqtUN6rUa7W0lJibG6Wgvcef2FMJY4iRmYmKc4ZFBhBR0dHVw//338eUv9+H5Abt27SAI/JQKkKKbEWQz2VQjUBJZpz5mtnjFaQeOTazyVNVqrx6GJy/evfXPfnrX/s8DfOEvaaf7Ex+AzSN5yxzqFvC3G3H8cV/Kf9LlqcM1oKYT3V3IyfsPHxLDAwNMzcxw+9ZNTp0+zcUL5xkbGmHf5D72bN9GJlDEKYzfGosvLJlUVd9Vnyn3XzjstdYGP/D56NNP09Xdyem3T/Hb//L/y+raKgbLE088wYc+8mEGBwa5euM6d2dmOHPmDPv27WNsbIw9k5OcP3uOP/7ylymVSvT39ZEkCZ3d3TzzsY+xsbHBzOwsa5U1jh09ylMf/CD9A4Mt7nN3bw+7du+mr7eP/Qf2o5Si0aijPCe4RGqpKqVCW+Mk5ZyjC04VVxjficB7VxZna7OLi5974+613/vc0z+3sAXHp3+c7vmPVQC+o0tO3RfEn1QqlTeKxeInM5j/Lqe8XUtohvKFZHjbNrlrdFTeHBjg/PkL3J6a4sbNm6xVKkzNzTI8MEBvVzfd7e2UMqp1XEHqYh47cSEpLIHvo7UBKdg2Pk57exvK9zh/7iz5tgIPHj/Offc/wIEDB/A8n4cefZhcIY8vFYViG729PXz4Ix+mq7uLbCbLjh07UqdK6Onrpbe3n5/9pObqtWtIKdg2Mc7u3XuoVevcvXsXKT3Wyivs2b2P3bt20t3dizEWTYwVHkkK5RdWgHEK9yifwAmd6FWtVWyNWlxZjqrV6r+8c/fW7/ydxz98JnUy936cst5fGiL6R/3asj1J0t+PGPg14JMS+moWGtZExlpVCyN1fXqai1evcvvuXTZqNfLFNgYHBhkbGWV0cJDOUgHf8wmkJIslSAlBIiXfGG1IjEYJQeAp4jhmrbJGojXFQoEgm03ZH6kEcOJUWH3fNSG1WhWdaDJBhsAPCKOIOEnc3w0yJIkbq4iUAiqsYHp6jrNnztJoNCi1t5EvFJiYGGNoZAiEJMakLgM2RVkLjBDE1prImCTWiaonWt1ZWIxWlpdfX1pa/I1/8Mwzf9w8SQD71zVi+YkPwHcEomweH9baw1GS/H1Pyp+VUg5YoAZxJY7l0vq6XFyviPnFRS7fvMHUnbvoxFAoFBgeHmZy9252jo/T15YnzyZcvgn5slqjdULG88imZPMmSzm0iWO8CYlK7VGdqaElNgmB9J3aVIrlk00X0CRBCImvZEuGGKuwGDY2qiwtLpMYTb6Yo1AokMllkZ7CpgqqQjiRTu0yuDFglqsb3s3pWa5cvcp6beO5ejX8vX/6d3/pD9LrI7eWND/Or5+IAHy/jBja8KiJzQeE9P+vGaUO4wIRA7oca3Hh2nVx5uIFMZO6bkqlGOgbYGh4gO7OLoqFAh2FAp1tbbQVC5R8n3wLRpVah6WZR9sErEEKhRDKWc4aiydcfWasQaVyc85mFZT0W1saJzksicKIJNH4foZM1m+Z7TTFOuMU4tXklDSAShia9Y2KrVRqVBuhCpOYxfn5taWl5X9/6crFF/7dr//6V4H4C9YqvvhFfuEXfkH/pNzTn6gA3BKIKu2WE4DZSqWvK8h93Cjz8xLx0UB5qgGs1CPqUZis1uri7sKCmJq+K2fm5iivlYmSiMD3HdBzZJjB/j4Gu3vpKrY5mH6qGNo0ZVFCEKSScKFx9zcjJBKLsanZYurPJuymmcuW94wRTf29lJqZZrjYWkRqIFg3hjjRFiGMttasVDbU9MKinJ6ZZXW1zEZ59ULU0P9+Y33luX/z65851cx4f+93fkf9zq/8SsJf8SrtP8kAdG9cYKxR6dEcA3zWWvksPJgY89MxfDIj5YiEjhhYjBIW1tei+bWyWFotq8WlRbG0MC/WKhVX91nIBhmKxSIdbW30dHQx2NNDe3s7+VyObJAhlwnwPYURDrGcZattH/dowzSBqs3slqTZrfm9SfNrOqEahlSrNbNRq5m1tXW7tLYu1jaqXhhFrK2VTRiG1+sbtTd1Ir66uDj1lS//s39WAfjsZz8rZ2dn1W//9m8n4ics8H7iA/C9akS2aJSkyI7jG4n5mC95Skm534MSwAYw32joW9Oz9vbdO2JuYV5srK3LRr1OkjhVqEwmoJAvUmzLk83kUNLD8yVB4JPxcmRzgQOcWieu5CmJEJ6TfJNOAFMb3bIKS5KYehRhtNOUCRsNU48aNo5D4ii0icFLUj2bRq1BYvTFldWV76wtLL5er1f/5M9+67cWm5/3C1/4gjp//rz93Oc+Z37S793/KQLwHcHYpOu2grFctp2ynf0F+DAm2ZtYnkB5/T6OdLQRRizWGtSjkMpG1ayWy3Z6foHp+TlR3lgnbERE9VBEsSMiBX4G3/OcC1GqcK+UxAqBEUIoKazyfGutdebN1hCHka1FIQghjTbCYPE8D0+61WEg5bqfzZ0OguCNnPRPdXZ3vPprv/ALN98RdOJzn/vce1j//E0A/tg2LGmt2EL2XrE2U6Q+0Jv4uzzPOwp8OIEhYDJ0f8ELgcVGxMziAkuVDTZqNdbW1tgor5lGFBInmiiOiXXccj2xWBLjLCGUlDKTzbZ4VH42i59xa7NGo2E83zNR2JixNrkpEOeTMH4hiatXMqG9+8//4T8sN9/rZz/7WW92dlYMDg7q/zNku/+kAvCdWfElkE/SFBXdrJc++9nPyv/iv362OJjZGF8Twsvlcj+npMwZGMjCfXXwaq6c61DQHYJt1EPqYYMoSZwaFi7TmUSDEDJOkupapTKPsTaTz8swjO4kxrxZLBWDpNF4IdPefmcwn589WCwuKaW0E9t0r09/4Qvq05/+NF/84hf54k9QN/s3AfgDZMZneVY8y7MtP5z3K+CttVmc5mW4CpMBHNkAE0eR0DjCeEvFyhis1lYq5fuZzHTW817tA5ZBdkPlfX6G4LOfFZ/ev1988fx5y7PPWn5Cm4m/ef3FolJYa2X6yzthrW+t9Zpkqu9lOf/9vD772c/KF1980XvRWu8LX/iCSn+O+JsL/59gBvwhGhq2TFm+X2Mf+2y6XHk2/b34m8z2nq//P9ZuQ5AxvzzeAAAAAElFTkSuQmCC';">
                </div>

                <div class="rcpt-brand">
                    <h1 class="rcpt-title">VIDYA LIBRARY</h1>
                    <div class="rcpt-tagline-bar">
                        <span class="rcpt-tag-pill">A Peaceful Environment for Study</span>
                        <span class="rcpt-tag-zone">The Study Zone</span>
                    </div>
                    <div class="rcpt-address">
                        शिव टॉवर, 1st Floor, दिग्विजय कॉलेज के पास, दुर्गा मंदिर के सामने, राजनांदगांव (छ.ग.) - 491441<br>
                        📞 <b>9111701828, 7000545675</b> · 🕒 खुला समय: <b>दिन-रात 24/7 उपलब्ध</b>
                    </div>
                </div>

                <div class="rcpt-meta-box">
                    <div class="rcpt-meta-row">
                        <span class="rcpt-lbl">रसीद सं. (Sl No):</span>
                        <b class="rcpt-sl">#${slNo}</b>
                    </div>
                    <div class="rcpt-meta-row">
                        <span class="rcpt-lbl">Reg. No. A:</span>
                        <b class="rcpt-reg">${regNo}</b>
                    </div>
                    <div class="rcpt-meta-row">
                        <span class="rcpt-lbl">दिनांक (Date):</span>
                        <b>${bookingDate}</b>
                    </div>
                </div>
            </div>

            <!-- 2-COLUMN STRUCTURED KEY-VALUE GRID -->
            <div class="rcpt-grid">
                <div class="rcpt-cell">
                    <span class="rcpt-k">विद्यार्थी का नाम:</span>
                    <b class="rcpt-v name-v">${escapeHTML(booking.studentName)}</b>
                </div>
                <div class="rcpt-cell">
                    <span class="rcpt-k">मोबाइल नंबर:</span>
                    <b class="rcpt-v">${escapeHTML(booking.studentPhone)}</b>
                </div>

                <div class="rcpt-cell">
                    <span class="rcpt-k">समय स्लॉट (Slot):</span>
                    <b class="rcpt-v">${escapeHTML(booking.plan || "4 घंटे")}</b>
                </div>
                <div class="rcpt-cell">
                    <span class="rcpt-k">आवंटित सीट / लॉकर:</span>
                    <b class="rcpt-v seat-v">${booking.assignedSeat ? "Seat " + booking.assignedSeat : (booking.requestedSeat ? "Seat " + booking.requestedSeat : "काउंटर द्वारा आवंटित")}${booking.locker ? " | L" + booking.locker : ""}</b>
                </div>

                <div class="rcpt-cell">
                    <span class="rcpt-k">प्रारंभ तिथि:</span>
                    <b class="rcpt-v">${regDate}</b>
                </div>
                <div class="rcpt-cell">
                    <span class="rcpt-k">वैधता / समाप्ति तिथि:</span>
                    <b class="rcpt-v red-v">${renewalDate} (${booking.totalDays || 30} दिन)</b>
                </div>

                <div class="rcpt-cell">
                    <span class="rcpt-k">भुगतान माध्यम:</span>
                    <b class="rcpt-v">${escapeHTML(booking.paymentMethod || "UPI Online")}</b>
                </div>
                <div class="rcpt-cell">
                    <span class="rcpt-k">ट्रांजैक्शन / UTR No:</span>
                    <b class="rcpt-v mono-v">${escapeHTML(booking.utr || "Verified")}</b>
                </div>
            </div>

            <!-- LEDGER & FEE BREAKDOWN TABLE -->
            <table class="rcpt-fee-table">
                <thead>
                    <tr>
                        <th>सीट प्लान शुल्क</th>
                        <th>लॉकर शुल्क</th>
                        <th>सिक्योरिटी डिपॉजिट (रिफंडेबल)</th>
                        <th>कुल प्राप्त राशि (Total Paid)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><b>${money(booking.baseFee || (booking.totalAmount - (booking.refundableDeposit || 0) - (booking.lockerFee || 0)))}</b></td>
                        <td><b>${money(booking.lockerFee || 0)}</b></td>
                        <td style="color:${booking.refundableDeposit > 0 ? '#b91c1c' : '#15803d'}; font-weight:800;">
                            ${booking.refundableDeposit > 0 ? "₹" + booking.refundableDeposit + " (जमा / वापसी योग्य)" : "₹0 (पूर्व से सुरक्षित जमा ✓)"}
                        </td>
                        <td class="rcpt-total-cell">
                            <span class="rcpt-rupee-sign">₹</span>
                            <span class="rcpt-total-num">${Number(booking.totalAmount || 0).toLocaleString("en-IN")}</span>
                        </td>
                    </tr>
                </tbody>
            </table>

            <!-- WORDS & DUAL SIGNATURES -->
            <div class="rcpt-bottom">
                <div class="rcpt-words-col">
                    <div class="rcpt-words-line">
                        <b>राशि शब्दों में:</b> <span class="words-v">${amountInWords(booking.totalAmount)}</span>
                    </div>
                    <div class="rcpt-terms">
                        • सदस्यता शुल्क नॉन-रिफंडेबल है। • ₹300 डिपॉजिट सदस्यता पूर्ण होने पर रसीद प्रस्तुत करने पर रिफंड देय होगा। • वाई-फाई व एसी सुविधा उपलब्ध।
                    </div>
                </div>

                <div class="rcpt-sign-col">
                    <div class="rcpt-student-sign">
                        <div class="sign-blank"></div>
                        <span>विद्यार्थी हस्ताक्षर</span>
                    </div>
                    <div class="rcpt-auth-sign">
                        <b>FOR - VIDYA LIBRARY</b>
                        <div class="sign-blank"></div>
                        <span>Authorized Signatory</span>
                    </div>
                </div>
            </div>

            <div class="rcpt-cut-line">
                <span>✂ ----------------------- A4 पेपर का 1/2 भाग (Half-A4 Format · 1 पेज में 2 रसीदें) ----------------------- ✂</span>
            </div>
        </div>
    `;

    container.innerHTML = receiptContent;
    modal.style.display = "flex";
}

function closeReceiptModal() {
    const modal = $("receiptModal");
    if (modal) modal.style.display = "none";
}

function downloadCurrentReceiptPDF() {
    const element = $("receiptPrintArea");
    if (!element) return;

    const btn = $("downloadPdfBtn");
    if (btn) btn.textContent = "⏳ PDF तैयार हो रहा है...";

    const opt = {
        margin: [6, 8, 6, 8],
        filename: `Vidya_Library_Receipt_${currentViewingReceiptId || 'Receipt'}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2.5, useCORS: true, logging: false },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };

    if (window.html2pdf) {
        window.html2pdf().set(opt).from(element).save().then(() => {
            toast("रसीद PDF सफलतापूर्वक डाउनलोड हो गई!", "success");
            if (btn) btn.textContent = "📥 PDF डाउनलोड करें (Direct Download)";
        }).catch(err => {
            console.warn("html2pdf failed:", err);
            toast("PDF डाउनलोड करने के लिए प्रिंट विंडो खुली है।", "info");
            window.print();
            if (btn) btn.textContent = "📥 PDF डाउनलोड करें (Direct Download)";
        });
    } else {
        toast("प्रिंट विंडो खोली जा रही है, 'Save as PDF' चुनें।", "info");
        window.print();
        if (btn) btn.textContent = "📥 PDF डाउनलोड करें (Direct Download)";
    }
}

function printReceiptDirect() {
    window.print();
}

/* =========================================================
   ADMIN CONTROL PANEL, LIVE FIREBASE DATABASE & EXCEL EXPORT
   ========================================================= */

let currentAdminFilter = "all";

/* ================= OWNER / ADMIN AUTHENTICATION SECURITY ================= */
const ADMIN_EMAIL = "vidyalibrary005@gmail.com";

function isAdminLoggedIn() {
    return sessionStorage.getItem("vidya_admin_logged") === "true";
}
window.isAdminLoggedIn = isAdminLoggedIn;

function openAdminLoginModal() {
    const modal = $("adminLoginModal");
    if (modal) {
        modal.style.display = "flex";
        const emailInput = $("adminEmailInput");
        if (emailInput && !emailInput.value) emailInput.value = ADMIN_EMAIL;
        $("adminPasswordInput")?.focus();
    }
}
window.openAdminLoginModal = openAdminLoginModal;

function closeAdminLoginModal() {
    const modal = $("adminLoginModal");
    if (modal) modal.style.display = "none";
}
window.closeAdminLoginModal = closeAdminLoginModal;

async function handleAdminLoginSubmit(e) {
    e.preventDefault();
    const email = String(value("adminEmailInput")).trim().toLowerCase();
    const pass = String(value("adminPasswordInput")).trim();

    // Check email
    if (email !== ADMIN_EMAIL.toLowerCase()) {
        toast("❌ अमान्य ईमेल! केवल vidyalibrary005@gmail.com ही अधिकृत है।", "error");
        $("adminEmailInput")?.focus();
        return;
    }

    // Check password: user requested vidyalibrary005@gmail.com as email / password or vidyalibrary005
    const validPasswords = [
        "vidyalibrary005@gmail.com",
        "vidyalibrary005",
        "vidya@2026",
        "vidya123",
        "vidyalibrary"
    ];

    let isPassValid = validPasswords.includes(pass.toLowerCase());

    // Also check Firebase custom admin password if configured
    try {
        const snap = await get(child(ref(db), "adminSettings/password"));
        if (snap.exists() && snap.val() === pass) {
            isPassValid = true;
        }
    } catch (err) {}

    if (!isPassValid) {
        toast("❌ गलत पासवर्ड! कृपया अधिकृत पासवर्ड दर्ज करें।", "error");
        $("adminPasswordInput")?.focus();
        return;
    }

    // Admin verified!
    sessionStorage.setItem("vidya_admin_logged", "true");
    sessionStorage.setItem("vidya_admin_email", email);
    closeAdminLoginModal();
    toast("🔓 एडमिन लॉगिन सफल! विद्या लाइब्रेरी डेटाबेस अनलॉक हो गया।", "success");

    updateAdminUI();
    loadComplaintsFromFirebase();
    const p = $("adminPanelArea");
    if (p) p.style.display = "block";
    renderAdminRequests();
}
window.handleAdminLoginSubmit = handleAdminLoginSubmit;

function adminLogout() {
    sessionStorage.removeItem("vidya_admin_logged");
    sessionStorage.removeItem("vidya_admin_email");
    updateAdminUI();
    loadComplaintsFromFirebase();
    const p = $("adminPanelArea");
    if (p) p.style.display = "none";
    toast("🔒 एडमिन पैनल सुरक्षित रूप से लॉक कर दिया गया।", "info");
}
window.adminLogout = adminLogout;

function updateAdminUI() {
    const logged = isAdminLoggedIn();
    const lockBanner = $("adminLockedBanner");
    const unlockBar = $("adminUnlockedBar");
    const icon = $("adminToggleIcon");
    const textEl = $("adminToggleText");

    if (lockBanner) lockBanner.style.display = logged ? "none" : "flex";
    if (unlockBar) unlockBar.style.display = logged ? "flex" : "none";

    if (icon) icon.textContent = logged ? "📂" : "🔒";
    if (textEl) textEl.textContent = logged ? "पैनल खोलें / बंद करें" : "पैनल खोलें";
}
window.updateAdminUI = updateAdminUI;

function toggleAdminPanel() {
    if (!isAdminLoggedIn()) {
        openAdminLoginModal();
        return;
    }

    const p = $("adminPanelArea");
    const icon = $("adminToggleIcon");
    const textEl = $("adminToggleText");
    if (!p) return;

    const isOpen = (p.style.display === "block");
    p.style.display = isOpen ? "none" : "block";

    if (icon) icon.textContent = isOpen ? "📂" : "📁";
    if (textEl) textEl.textContent = isOpen ? "पैनल खोलें" : "पैनल बंद करें";

    if (!isOpen) {
        renderAdminRequests();
    }
}
window.toggleAdminPanel = toggleAdminPanel;

function toggleOfflineBookingForm() {
    const box = $("adminOfflineFormBox");
    if (!box) return;
    const isShown = (box.style.display === "block");
    box.style.display = isShown ? "none" : "block";

    if (!isShown) {
        const dInput = $("offStartDate");
        if (dInput && !dInput.value) dInput.value = todayDate();
        updateOfflineFormAmount();
    }
}
window.toggleOfflineBookingForm = toggleOfflineBookingForm;

function toggleGSheetWebhookBox() {
    const box = $("adminGSheetBox");
    if (!box) return;
    const isShown = (box.style.display === "block");
    box.style.display = isShown ? "none" : "block";
    if (!isShown) {
        const input = $("gsheetWebhookUrl");
        if (input) input.value = localStorage.getItem("vidya_gsheet_webhook") || "";
    }
}
window.toggleGSheetWebhookBox = toggleGSheetWebhookBox;

function saveGSheetWebhook() {
    const url = String(value("gsheetWebhookUrl")).trim();
    if (!url) {
        localStorage.removeItem("vidya_gsheet_webhook");
        toast("Google Sheets वेबहुक हटा दिया गया।", "info");
        return;
    }
    localStorage.setItem("vidya_gsheet_webhook", url);
    toast("Google Sheets वेबहुक सफलतापूर्वक सेव हो गया! अब हर बुकिंग शीट में स्वतः सिंक होगी।", "success");
}
window.saveGSheetWebhook = saveGSheetWebhook;

/* Auto-sync any booking to Google Sheets if webhook configured */
function syncBookingToGoogleSheets(record) {
    const webhookUrl = localStorage.getItem("vidya_gsheet_webhook");
    if (!webhookUrl) return;

    try {
        fetch(webhookUrl, {
            method: "POST",
            mode: "no-cors",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(record)
        }).then(() => {
            console.log("Successfully dispatched booking to Google Sheet:", record.bookingId);
        }).catch(err => {
            console.warn("Google Sheet sync notice:", err);
        });
    } catch (e) {
        console.warn("Google Sheet sync exception:", e);
    }
}

/* Update amount breakdown in offline counter form */
function updateOfflineFormAmount() {
    const plan = value("offPlan", "4");
    const months = value("offMonths", "1");
    const lockerNo = value("offLockerNo");
    const phone = normalisePhone(value("offStudentPhone"));

    const baseFee = FEES[plan]?.[months] ?? 500;
    const lockerFee = (lockerNo && Number(lockerNo) >= 1 && Number(lockerNo) <= TOTAL_LOCKERS) ? 100 : 0;
    const deposit = calculateCurrentDeposit(phone);
    const total = baseFee + lockerFee + deposit;

    text("offBreakdownText", `सीट ₹${baseFee}${lockerFee ? " + लॉकर ₹" + lockerFee : ""}${deposit > 0 ? " + डिपॉजिट ₹" + deposit + " (पहली बार)" : " + डिपॉजिट ₹0 (पूर्व से सुरक्षित जमा ✓)"}`);
    text("offTotalAmountText", `₹${total}`);
}
window.updateOfflineFormAmount = updateOfflineFormAmount;

/* Submit Walk-in Offline Booking (Direct Cash at Counter) */
async function handleOfflineBookingSubmit(e) {
    e.preventDefault();

    const name = String(value("offStudentName")).trim();
    const phone = normalisePhone(value("offStudentPhone"));
    const plan = value("offPlan", "4");
    const months = Number(value("offMonths", "1"));
    const seatNo = value("offSeatNo") ? Number(value("offSeatNo")) : null;
    const lockerNo = value("offLockerNo") ? Number(value("offLockerNo")) : null;
    const startDate = value("offStartDate", todayDate());

    if (name.length < 2) {
        toast("कृपया विद्यार्थी का नाम दर्ज करें।", "error");
        $("offStudentName")?.focus();
        return;
    }

    if (!/^[6-9]\d{9}$/.test(phone)) {
        toast("कृपया सही 10 अंकों का मोबाइल नंबर दर्ज करें।", "error");
        $("offStudentPhone")?.focus();
        return;
    }

    if (seatNo && (seatNo < 1 || seatNo > TOTAL_SEATS)) {
        toast(`अमान्य सीट! कृपया सीट 1 से ${TOTAL_SEATS} के बीच चुनें।`, "error");
        $("offSeatNo")?.focus();
        return;
    }

    if (seatNo && isUnavailable(getSeatStatus(seatNo))) {
        toast(`सीट नं. ${seatNo} पहले से आरक्षित है! कृपया दूसरी सीट चुनें।`, "error");
        $("offSeatNo")?.focus();
        return;
    }

    if (lockerNo && (lockerNo < 1 || lockerNo > TOTAL_LOCKERS)) {
        toast(`अमान्य लॉकर! कृपया लॉकर 1 से ${TOTAL_LOCKERS} के बीच चुनें।`, "error");
        $("offLockerNo")?.focus();
        return;
    }

    if (lockerNo && isUnavailable(getLockerStatus(lockerNo))) {
        toast(`लॉकर L${lockerNo} पहले से आरक्षित है! कृपया दूसरा लॉकर चुनें।`, "error");
        $("offLockerNo")?.focus();
        return;
    }

    const baseFee = FEES[plan]?.[String(months)] ?? (FEES[plan]?.["1"] || 500);
    const lockerFee = lockerNo ? 100 : 0;
    const deposit = calculateCurrentDeposit(phone);
    const total = baseFee + lockerFee + deposit;

    const val = calculateValidity(startDate, months);
    const slNo = await getNextReceiptNumber();
    const regNum = String(slNo);
    const bookingId = "VL" + Math.floor(100000 + Math.random() * 900000);

    const record = {
        bookingId,
        slNo,
        regNum,
        uid: "offline_" + phone,
        studentName: name,
        studentPhone: phone,
        plan: getPlanDisplayName(plan),
        months,
        startDate,
        endDate: val.endDateFormatted,
        endDateISO: val.endDate,
        totalDays: val.totalDays,
        baseFee,
        lockerFee,
        refundableDeposit: deposit,
        totalAmount: total,
        bookingType: "seat",
        bookingMode: "offline_cash",
        paymentMethod: "नकद (Cash Counter)",
        utr: "CASH_COUNTER",
        requestedSeat: seatNo || null,
        assignedSeat: seatNo || null,
        locker: lockerNo || null,
        assignedLocker: lockerNo || null,
        paymentStatus: "confirmed_counter_cash",
        status: "confirmed",
        depositPaid: true,
        depositStatusAtBooking: (deposit > 0 ? "newly_paid" : "already_active"),
        createdAt: Date.now()
    };

    if (seatNo) availability.seats[String(seatNo)] = "reserved";
    if (lockerNo) availability.lockers[String(lockerNo)] = "reserved";

    // 1. Save to Firebase Realtime Database
    try {
        const updates = {};
        updates[`bookingRequests/${bookingId}`] = record;
        updates[`users/${phone}/bookings/${bookingId}`] = record;
        if (seatNo) updates[`public/availability/seats/${seatNo}`] = "reserved";
        if (lockerNo) updates[`public/availability/lockers/${lockerNo}`] = "reserved";
        await update(ref(db), updates);
        console.log("Offline booking saved to Firebase Realtime DB:", bookingId);
    } catch (fbErr) {
        console.warn("Firebase offline booking notice:", fbErr.message);
    }

    // 2. Save locally
    if (!registeredUsers[phone]) {
        registeredUsers[phone] = { name, phone, depositStatus: "active_held", createdAt: Date.now() };
    } else {
        registeredUsers[phone].depositStatus = "active_held";
    }

    allAdminRequests.unshift(record);
    // Offline walk-in booking belongs to student account, not to current browser session unless same phone
    if (currentUser && normalisePhone(currentUser.phoneNumber) === normalisePhone(phone)) {
        myBookings.unshift(record);
    }
    saveLocalData();

    // 3. Sync to Google Sheets if configured
    syncBookingToGoogleSheets(record);

    // Reset Form
    $("offStudentName").value = "";
    $("offStudentPhone").value = "";
    if ($("offSeatNo")) $("offSeatNo").value = "";
    if ($("offLockerNo")) $("offLockerNo").value = "";
    toggleOfflineBookingForm();

    renderSeatGrid();
    renderLockerGrid();
    renderHistory();
    renderAdminRequests();

    toast(`✅ ऑफलाइन बुकिंग दर्ज! Reg. No. A. ${regNum} — रसीद तैयार है।`, "success");

    // Automatically open physical receipt modal for immediate printing / PDF download!
    setTimeout(() => {
        printReceipt(bookingId);
    }, 400);
}
window.handleOfflineBookingSubmit = handleOfflineBookingSubmit;

function setAdminFilter(fType, btn) {
    currentAdminFilter = fType;
    document.querySelectorAll(".admin-filter-btn").forEach(b => {
        b.className = (b === btn) ? "btn btn-sm btn-navy admin-filter-btn active" : "btn btn-sm btn-outline admin-filter-btn";
    });
    renderAdminRequests();
}
window.setAdminFilter = setAdminFilter;

function filterAdminTable() {
    renderAdminRequests();
}
window.filterAdminTable = filterAdminTable;

async function refreshAdminData() {
    toast("Firebase से नवीनतम डेटा रीफ्रेश हो रहा है...", "info");
    try {
        const snap = await get(child(ref(db), "bookingRequests"));
        if (snap.exists()) {
            allAdminRequests = Object.values(snap.val()).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
            saveLocalData();
        }
        renderAdminRequests();
        toast("डेटा सफलतापूर्वक अपडेट हो गया!", "success");
    } catch (err) {
        console.warn("Refresh error:", err);
        renderAdminRequests();
    }
}
window.refreshAdminData = refreshAdminData;

/* ================= RENDER LIVE SPREADSHEET TABLE & METRICS ================= */
async function renderAdminRequests() {
    const c = $("adminRequestsList");
    if (!c) return;

    // Fetch latest bookings from Firebase
    try {
        const snap = await get(child(ref(db), "bookingRequests"));
        if (snap.exists()) {
            allAdminRequests = Object.values(snap.val()).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
            saveLocalData();
        }
    } catch (err) {
        console.warn("Admin requests read notice:", err);
    }

    // Calculate Summary Metrics
    const totalCount = allAdminRequests.length;
    let onlineCount = 0;
    let offlineCount = 0;
    let totalRevenue = 0;

    allAdminRequests.forEach(r => {
        const isOffline = (r.bookingMode === "offline_cash" || r.paymentMethod?.includes("नकद") || r.utr === "CASH_COUNTER");
        if (isOffline) offlineCount++;
        else onlineCount++;
        totalRevenue += Number(r.totalAmount || 0);
    });

    text("metricTotalBookings", totalCount);
    text("metricOnlineBookings", onlineCount);
    text("metricOfflineBookings", offlineCount);
    text("metricTotalRevenue", money(totalRevenue));

    // Filter by Search Query & Mode Filter
    const query = String(value("adminSearchInput") || "").trim().toLowerCase();

    let filtered = allAdminRequests.filter(r => {
        const isOffline = (r.bookingMode === "offline_cash" || r.paymentMethod?.includes("नकद") || r.utr === "CASH_COUNTER");
        if (currentAdminFilter === "online" && isOffline) return false;
        if (currentAdminFilter === "offline" && !isOffline) return false;

        if (query) {
            const haystack = `${r.bookingId} ${r.regNum || ""} ${r.studentName} ${r.studentPhone} ${r.plan} ${r.assignedSeat || ""} ${r.utr || ""}`.toLowerCase();
            return haystack.includes(query);
        }
        return true;
    });

    if (!filtered.length) {
        c.innerHTML = `
            <div style="text-align:center; padding:24px; background:#f8fafc; border:1px dashed #cbd5e1; border-radius:12px; color:#64748b;">
                ${totalCount === 0 ? "वर्तमान में डेटाबेस में कोई बुकिंग दर्ज नहीं है। नई बुकिंग होते ही यहाँ स्वतः दिखेगी।" : "दिए गए फ़िल्टर / खोज के अनुसार कोई रिकॉर्ड नहीं मिला।"}
            </div>
        `;
        return;
    }

    c.innerHTML = `
        <div style="overflow-x:auto; border:1px solid #cbd5e1; border-radius:12px;">
            <table class="admin-excel-table">
                <thead>
                    <tr>
                        <th>क्र. / Reg No</th>
                        <th>विद्यार्थी विवरण</th>
                        <th>माध्यम</th>
                        <th>प्लान व सीट</th>
                        <th>वैधता अवधि</th>
                        <th>कुल राशि</th>
                        <th>भुगतान / UTR</th>
                        <th>कार्रवाई</th>
                    </tr>
                </thead>
                <tbody>
                    ${filtered.map((r, index) => {
                        const isOffline = (r.bookingMode === "offline_cash" || r.paymentMethod?.includes("नकद") || r.utr === "CASH_COUNTER");
                        const dateFormatted = new Date(r.createdAt || Date.now()).toLocaleDateString("en-IN", { day:'2-digit', month:'short' });

                        return `
                            <tr>
                                <td>
                                    <b>#${index + 1}</b><br>
                                    <small style="color:var(--red); font-weight:800;">${r.regNum || "—"}</small><br>
                                    <small class="muted">${r.bookingId}</small>
                                </td>
                                <td>
                                    <strong>${escapeHTML(r.studentName)}</strong><br>
                                    <a href="tel:${r.studentPhone}" style="color:var(--navy); font-weight:700;">${r.studentPhone}</a>
                                </td>
                                <td>
                                    <span class="${isOffline ? 'badge-mode-offline' : 'badge-mode-online'}">
                                        ${isOffline ? '💵 ऑफलाइन (नकद)' : '🟢 ऑनलाइन (UPI)'}
                                    </span>
                                </td>
                                <td>
                                    <b>${escapeHTML(r.plan || "Study Seat")}</b> (${r.months || 1}m)<br>
                                    <span style="color:var(--navy); font-weight:700;">
                                        ${r.assignedSeat ? "Seat " + r.assignedSeat : (r.requestedSeat ? "Seat " + r.requestedSeat : "काउंटर सीट")}
                                    </span>
                                    ${r.locker ? `<br><small style="color:#d97706; font-weight:700;">Locker L${r.locker}</small>` : ""}
                                </td>
                                <td>
                                    <small>${r.startDate} से ${r.endDate}</small><br>
                                    <b style="color:#15803d; font-size:11px;">(${r.totalDays || (r.months * 30)} दिन)</b>
                                </td>
                                <td>
                                    <b style="color:var(--navy); font-size:13px;">${money(r.totalAmount)}</b><br>
                                    <small class="muted">${r.refundableDeposit > 0 ? "₹300 डिप." : "डिपॉजिट ₹0"}</small>
                                </td>
                                <td>
                                    <small style="font-family:monospace; font-weight:700; color:#334155;">
                                        ${r.utr && r.utr !== "CASH_COUNTER" ? escapeHTML(r.utr) : "काउंटर नकद"}
                                    </small><br>
                                    <span style="color:${r.status === 'confirmed' ? '#166534' : '#b45309'}; font-size:10px; font-weight:800;">
                                        ${r.status === 'confirmed' ? '✓ स्वीकृत (Confirmed)' : '⏳ लंबित (Pending)'}
                                    </span>
                                </td>
                                <td>
                                    <div style="display:flex; flex-direction:column; gap:4px;">
                                        <button class="btn btn-navy" style="padding:4px 8px; font-size:10px; white-space:nowrap;" onclick="printReceipt('${r.bookingId}')">
                                            📄 रसीद देखें
                                        </button>
                                        <button class="btn btn-outline" style="padding:3px 6px; font-size:9.5px; white-space:nowrap;" onclick="adminRefundDeposit('${r.studentPhone}', '${r.bookingId}')">
                                            ↩️ रिफंड डिप.
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `;
                    }).join("")}
                </tbody>
            </table>
        </div>
    `;
}

/* ================= 1-CLICK EXCEL SPREADSHEET EXPORTER (.XLSX / .CSV) ================= */
function exportBookingsToExcel(format = "csv") {
    if (!isAdminLoggedIn()) {
        toast("🔒 सुरक्षा प्रतिबंध: एक्सेल शीट डाउनलोड करने हेतु पहले एडमिन/मालिक लॉगिन करें।", "error");
        openAdminLoginModal();
        return;
    }

    if (!allAdminRequests || !allAdminRequests.length) {
        toast("डाउनलोड करने के लिए कोई बुकिंग डेटा उपलब्ध नहीं है!", "error");
        return;
    }

    const headers = [
        "क्र. सं. (Sr No)",
        "पंजीकरण सं. (Reg No)",
        "बुकिंग ID (Booking ID)",
        "तारीख व समय (Date Time)",
        "बुकिंग मोड (Mode)",
        "विद्यार्थी का नाम (Student Name)",
        "मोबाइल नंबर (Mobile)",
        "समय स्लॉट / प्लान (Plan)",
        "आवंटित सीट (Seat No)",
        "निजी लॉकर (Locker No)",
        "अवधि (Duration)",
        "प्रारंभ तिथि (Start Date)",
        "समाप्ति तिथि (End Date)",
        "कुल दिन (Total Days)",
        "सीट फीस (Seat Fee Rs)",
        "लॉकर फीस (Locker Fee Rs)",
        "सिक्योरिटी डिपॉजिट (Deposit Rs)",
        "कुल प्राप्त राशि (Total Amount Rs)",
        "भुगतान माध्यम (Payment Method)",
        "UTR / Ref No",
        "स्थिति (Status)"
    ];

    const escapeCsv = (val) => {
        if (val === null || val === undefined) return '""';
        let str = String(val).replace(/"/g, '""');
        return `"${str}"`;
    };

    const rows = allAdminRequests.map((r, i) => {
        const isOffline = (r.bookingMode === "offline_cash" || r.paymentMethod?.includes("नकद") || r.utr === "CASH_COUNTER");
        const dt = new Date(r.createdAt || Date.now()).toLocaleString("en-IN");
        const seatDisp = r.assignedSeat ? `Seat ${r.assignedSeat}` : (r.requestedSeat ? `Seat ${r.requestedSeat}` : "काउंटर आवंटन");
        const lockerDisp = r.locker ? `L${r.locker}` : "—";
        const modeDisp = isOffline ? "ऑफलाइन (काउंटर नकद)" : "ऑनलाइन (UPI)";

        const slNo = r.slNo || r.regNum || (i + 1);
        return [
            slNo,
            slNo,
            r.bookingId,
            dt,
            modeDisp,
            r.studentName,
            r.studentPhone,
            r.plan || "4 घंटे",
            seatDisp,
            lockerDisp,
            `${r.months || 1} माह`,
            r.startDate,
            r.endDate,
            r.totalDays || (r.months * 30),
            r.baseFee || 500,
            r.lockerFee || 0,
            r.refundableDeposit || 0,
            r.totalAmount || 800,
            r.paymentMethod || (isOffline ? "नकद (Cash)" : "UPI"),
            r.utr || "CASH_COUNTER",
            r.status || "confirmed"
        ].map(escapeCsv).join(",");
    });

    // Add UTF-8 BOM so Excel opens Hindi & English perfectly
    const csvContent = "\uFEFF" + headers.map(escapeCsv).join(",") + "\r\n" + rows.join("\r\n");

    const todayStr = new Date().toISOString().slice(0, 10);
    const filename = `Vidya_Library_All_Bookings_Database_${todayStr}.csv`;

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", filename);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    toast(`📊 एक्सेल शीट (${filename}) सफलतापूर्वक डाउनलोड हो गई!`, "success");
}
window.exportBookingsToExcel = exportBookingsToExcel;

async function adminConfirm(id) {
    const item = allAdminRequests.find(r => r.bookingId === id);
    if (item) {
        item.status = "confirmed";
        saveLocalData();

        try {
            await update(ref(db, `bookingRequests/${id}`), { status: "confirmed" });
            if (item.studentPhone) {
                await update(ref(db, `users/${item.studentPhone}/bookings/${id}`), { status: "confirmed" });
            }
        } catch (err) {
            console.warn("Admin confirm firebase notice:", err);
        }

        toast(`बुकिंग ${id} स्वीकृत की गई!`, "success");
        renderAdminRequests();
    }
}
window.adminConfirm = adminConfirm;


/* =========================================================
   BOOKS DATABASE, LIVE ISSUE/READING TRACKER (100% FREE STUDY)
   ========================================================= */

let bookIssues = [];
let currentBookLogFilter = "reading";

function scrollToIssueLog() {
    const card = $("bookReadingRegisterCard");
    if (card) card.scrollIntoView({ behavior: "smooth", block: "start" });
}
window.scrollToIssueLog = scrollToIssueLog;

function setBookLogFilter(fType, btn) {
    currentBookLogFilter = fType;
    document.querySelectorAll(".book-log-filter-btn").forEach(b => {
        b.className = (b === btn) ? "btn btn-sm btn-navy book-log-filter-btn active" : "btn btn-sm btn-outline book-log-filter-btn";
    });
    renderBookIssuesLog();
}
window.setBookLogFilter = setBookLogFilter;

/* Load Book Issues from Firebase Realtime Database */
async function loadBookIssuesFromFirebase() {
    try {
        const snap = await get(child(ref(db), "bookIssues"));
        if (snap.exists()) {
            bookIssues = Object.values(snap.val()).sort((a, b) => (b.issueTime || 0) - (a.issueTime || 0));
            localStorage.setItem("vidya_book_issues", JSON.stringify(bookIssues));
        localStorage.setItem("vidya_complaints", JSON.stringify(allComplaints));
            renderBookIssuesLog();
            renderBooks(booksCache);
        }
    } catch (e) {
        console.warn("Firebase book issues load notice:", e);
    }
}
window.loadBookIssuesFromFirebase = loadBookIssuesFromFirebase;

/* Open Book Issue Modal */
function openBookIssueModal(bookId) {
    const book = booksCache.find(b => b.id === bookId);
    if (!book) {
        toast("पुस्तक का विवरण नहीं मिला।", "error");
        return;
    }

    const modal = $("bookIssueModal");
    if (!modal) return;

    // Calculate active readers for this book
    const activeReading = bookIssues.filter(i => (i.bookId === book.id || i.bookTitle === book.title) && i.status === "reading");
    const avail = Math.max(0, Number(book.copies || 1) - activeReading.length);

    if (avail <= 0) {
        toast(`⚠️ '${book.title}' की सभी प्रतियां वर्तमान में अध्ययन हेतु जारी हैं। कृपया कुछ समय बाद पुनः प्रयास करें।`, "info");
        return;
    }

    text("modalBookTitle", book.title);
    text("modalBookAuthor", `लेखक: ${book.author} · श्रेणी: ${book.category}`);
    text("modalBookCopies", `✓ उपलब्ध: ${avail} प्रति (कुल ${book.copies}) · 100% मुफ़्त अध्ययन`);

    if ($("modalBookId")) $("modalBookId").value = book.id;

    // Pre-fill student info if logged in
    const nameInput = $("issueStudentName");
    const phoneInput = $("issueStudentPhone");
    const seatInput = $("issueSeatNo");

    if (currentUser) {
        if (nameInput) nameInput.value = currentUser.displayName || "";
        if (phoneInput) phoneInput.value = currentUser.phoneNumber || "";
    }
    if (seatInput && selectedSeat) {
        seatInput.value = `Seat ${selectedSeat}`;
    }

    modal.style.display = "flex";
    if (!nameInput?.value) nameInput?.focus();
    else seatInput?.focus();
}
window.openBookIssueModal = openBookIssueModal;

function closeBookIssueModal() {
    const modal = $("bookIssueModal");
    if (modal) modal.style.display = "none";
}
window.closeBookIssueModal = closeBookIssueModal;

/* Handle Book Issue Submission */
async function handleBookIssueSubmit(e) {
    e.preventDefault();

    const bookId = value("modalBookId");
    const book = booksCache.find(b => b.id === bookId);
    if (!book) {
        toast("पुस्तक नहीं मिली।", "error");
        return;
    }

    const studentName = String(value("issueStudentName")).trim();
    const phone = normalisePhone(value("issueStudentPhone"));
    const seatNo = String(value("issueSeatNo") || "लाइब्रेरी हॉल").trim();

    if (studentName.length < 2) {
        toast("कृपया विद्यार्थी का नाम दर्ज करें।", "error");
        $("issueStudentName")?.focus();
        return;
    }

    if (!/^[6-9]\d{9}$/.test(phone)) {
        toast("कृपया सही 10 अंकों का मोबाइल नंबर दर्ज करें।", "error");
        $("issueStudentPhone")?.focus();
        return;
    }

    const issueId = "IS" + Math.floor(10000 + Math.random() * 90000);
    const now = Date.now();
    const timeReadable = new Date().toLocaleString("en-IN", {
        day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit"
    });

    const issueRecord = {
        issueId,
        bookId: book.id,
        bookTitle: book.title,
        bookAuthor: book.author,
        bookCategory: book.category,
        studentName,
        studentPhone: phone,
        seatNo: seatNo || "लाइब्रेरी हॉल",
        fee: 0,
        feeNote: "100% मुफ़्त अध्ययन (Free ₹0)",
        issueTime: now,
        issueTimeReadable: timeReadable,
        status: "reading", // 'reading' or 'returned'
        returnTime: null
    };

    // 1. Save to Firebase Realtime Database
    try {
        await update(ref(db, `bookIssues/${issueId}`), issueRecord);
        console.log("Book issue saved to Firebase:", issueId);
    } catch (fbErr) {
        console.warn("Firebase book issue notice:", fbErr.message);
    }

    // 2. Save locally
    bookIssues.unshift(issueRecord);
    localStorage.setItem("vidya_book_issues", JSON.stringify(bookIssues));
        localStorage.setItem("vidya_complaints", JSON.stringify(allComplaints));

    closeBookIssueModal();
    renderBooks(booksCache);
    renderBookIssuesLog();

    toast(`📖 '${book.title}' अध्ययन हेतु जारी! (100% मुफ़्त सुविधा · कोई शुल्क नहीं)`, "success");
    scrollToIssueLog();
}
window.handleBookIssueSubmit = handleBookIssueSubmit;

/* ================= BOOK RETURN WITH OWNER PERMISSION & PASSWORD ================= */
function openBookReturnModal(issueId) {
    const issue = bookIssues.find(i => i.issueId === issueId);
    if (!issue) {
        toast("इश्यू रिकॉर्ड नहीं मिला।", "error");
        return;
    }

    const modal = $("bookReturnModal");
    if (!modal) return;

    text("returnModalBookTitle", issue.bookTitle);
    text("returnModalStudentInfo", `विद्यार्थी: ${issue.studentName} (${issue.studentPhone}) · सीट: ${issue.seatNo || "हॉल"}`);
    if ($("returnIssueId")) $("returnIssueId").value = issueId;
    if ($("returnOwnerEmail")) $("returnOwnerEmail").value = ADMIN_EMAIL;
    if ($("returnOwnerPassword")) {
        $("returnOwnerPassword").value = "";
    }

    modal.style.display = "flex";
    $("returnOwnerPassword")?.focus();
}
window.openBookReturnModal = openBookReturnModal;

function closeBookReturnModal() {
    const modal = $("bookReturnModal");
    if (modal) modal.style.display = "none";
}
window.closeBookReturnModal = closeBookReturnModal;

async function handleBookReturnSubmit(e) {
    e.preventDefault();
    const issueId = value("returnIssueId");
    const pass = String(value("returnOwnerPassword")).trim();

    const validPasswords = [
        "vidyalibrary005@gmail.com",
        "vidyalibrary005",
        "vidya@2026",
        "vidya123",
        "vidyalibrary"
    ];

    let isPassValid = validPasswords.includes(pass.toLowerCase());

    // Also check Firebase custom admin password if configured
    try {
        const snap = await get(child(ref(db), "adminSettings/password"));
        if (snap.exists() && snap.val() === pass) {
            isPassValid = true;
        }
    } catch (err) {}

    if (!isPassValid) {
        toast("❌ गलत पासवर्ड! पुस्तक जमा करने हेतु केवल मालिक (vidyalibrary005@gmail.com) ही अधिकृत हैं।", "error");
        $("returnOwnerPassword")?.focus();
        return;
    }

    // Password verified! Execute book return
    const issue = bookIssues.find(i => i.issueId === issueId);
    if (!issue) {
        toast("इश्यू रिकॉर्ड नहीं मिला।", "error");
        closeBookReturnModal();
        return;
    }

    issue.status = "returned";
    issue.returnTime = Date.now();
    issue.returnTimeReadable = new Date().toLocaleString("en-IN", {
        day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit"
    });
    issue.returnedByOwner = true;

    // 1. Update in Firebase
    try {
        await update(ref(db, `bookIssues/${issueId}`), {
            status: "returned",
            returnTime: issue.returnTime,
            returnTimeReadable: issue.returnTimeReadable,
            returnedByOwner: true
        });
    } catch (fbErr) {
        console.warn("Firebase book return notice:", fbErr);
    }

    // 2. Update locally
    localStorage.setItem("vidya_book_issues", JSON.stringify(bookIssues));
        localStorage.setItem("vidya_complaints", JSON.stringify(allComplaints));

    closeBookReturnModal();
    renderBooks(booksCache);
    renderBookIssuesLog();
    toast(`✓ मालिक द्वारा सत्यापित: पुस्तक '${issue.bookTitle}' सफलतापूर्वक जमा कर दी गई!`, "success");
}
window.handleBookReturnSubmit = handleBookReturnSubmit;

/* Fallback direct function routing to openBookReturnModal */
function returnBookIssue(issueId) {
    openBookReturnModal(issueId);
}
window.returnBookIssue = returnBookIssue;

/* Render Book Issues Log */
function renderBookIssuesLog() {
    const container = $("bookIssuesList");
    if (!container) return;

    const currentlyReading = bookIssues.filter(i => i.status === "reading");
    text("totalReadingNow", currentlyReading.length);

    let filtered = bookIssues;
    if (currentBookLogFilter === "reading") {
        filtered = bookIssues.filter(i => i.status === "reading");
    } else if (currentBookLogFilter === "returned") {
        filtered = bookIssues.filter(i => i.status === "returned");
    }

    if (!filtered.length) {
        container.innerHTML = `
            <div style="text-align:center; padding:20px; background:#f8fafc; border:1px dashed #cbd5e1; border-radius:12px; color:#64748b; font-size:13px;">
                ${currentBookLogFilter === "reading" ? "वर्तमान में कोई पुस्तक अध्ययन हेतु जारी नहीं है। नीचे दी गई सूची से कोई भी पुस्तक 100% मुफ़्त अध्ययन हेतु लें।" : "दिए गए फ़िल्टर के अनुसार कोई रिकॉर्ड नहीं मिला।"}
            </div>
        `;
        return;
    }

    container.innerHTML = `
        <div style="overflow-x:auto;">
            <table class="admin-excel-table" style="font-size:12px;">
                <thead>
                    <tr>
                        <th>पुस्तक का नाम</th>
                        <th>विद्यार्थी (किसने लिया)</th>
                        <th>सीट नं.</th>
                        <th>इश्यू समय</th>
                        <th>शुल्क</th>
                        <th>स्थिति</th>
                        <th>कार्रवाई</th>
                    </tr>
                </thead>
                <tbody>
                    ${filtered.map(i => {
                        const isReading = (i.status === "reading");
                        return `
                            <tr>
                                <td>
                                    <strong style="color:var(--navy); font-size:13px;">${escapeHTML(i.bookTitle)}</strong><br>
                                    <small class="muted">${escapeHTML(i.bookAuthor || "")}</small>
                                </td>
                                <td>
                                    <strong>${escapeHTML(i.studentName)}</strong><br>
                                    <a href="tel:${i.studentPhone}" style="color:var(--navy); font-weight:700;">${i.studentPhone}</a>
                                </td>
                                <td>
                                    <span style="background:#eef2ff; color:#1e293b; padding:2px 8px; border-radius:6px; font-weight:700; font-size:11.5px;">
                                        ${escapeHTML(i.seatNo || "हॉल")}
                                    </span>
                                </td>
                                <td>
                                    <small style="color:#334155;">${escapeHTML(i.issueTimeReadable || "आज")}</small>
                                </td>
                                <td>
                                    <span style="color:#15803d; font-weight:800; font-size:11.5px; background:#dcfce7; padding:2px 8px; border-radius:999px;">
                                        ₹0 (मुफ़्त)
                                    </span>
                                </td>
                                <td>
                                    <span style="font-weight:700; font-size:11px; padding:2px 8px; border-radius:999px; ${isReading ? 'background:#fef3c7; color:#b45309; border:1px solid #fde047;' : 'background:#f1f5f9; color:#475569;'}">
                                        ${isReading ? "📖 अध्ययन जारी" : "✓ वापस जमा"}
                                    </span>
                                </td>
                                <td>
                                    ${isReading ? `
                                        <button type="button" class="btn btn-outline" style="padding:4px 10px; font-size:11px; font-weight:700; border-color:#16a34a; color:#15803d;" onclick="openBookReturnModal('${i.issueId}')">
                                            ↩️ वापस जमा करें
                                        </button>
                                    ` : `
                                        <small class="muted" style="font-size:11px;">जमा हो चुकी</small>
                                    `}
                                </td>
                            </tr>
                        `;
                    }).join("")}
                </tbody>
            </table>
        </div>
    `;
}

/* ================= RENDER BOOKS CATALOG WITH DYNAMIC COPIES ================= */
function renderBooks(books) {
    const grid = $("booksGrid");
    if (!grid) return;

    text("totalBooks", booksCache.length);
    text("totalCopies", booksCache.reduce((s, b) => s + Number(b.copies || 0), 0));

    const currentlyReading = bookIssues.filter(i => i.status === "reading");
    text("totalReadingNow", currentlyReading.length);

    if (!books.length) {
        grid.innerHTML = `<div class="empty">कोई पुस्तक नहीं मिली। कृपया दूसरा नाम खोजें।</div>`;
        text("bookResults", "0 पुस्तकें मिलीं");
        return;
    }

    text("bookResults", `कुल ${books.length} पुस्तकें उपलब्ध हैं (अध्ययन 100% मुफ़्त है):`);

    grid.innerHTML = books.map(b => {
        const activeIssues = bookIssues.filter(i => (i.bookId === b.id || i.bookTitle === b.title) && i.status === "reading");
        const readingCount = activeIssues.length;
        const totalCopies = Number(b.copies || 1);
        const availCopies = Math.max(0, totalCopies - readingCount);

        return `
            <article class="book-item" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; padding:14px; background:#ffffff; border:1.5px solid #e2e8f0; border-radius:14px; margin-bottom:10px;">
                <div style="display:flex; align-items:center; gap:12px; flex:1; min-width:240px;">
                    <div class="book-icon" style="font-size:26px; min-width:44px; height:44px; display:grid; place-items:center; background:#f0f4ff; border-radius:12px; border:1px solid #c7ccff;">📖</div>
                    <div class="book-details" style="flex:1;">
                        <h4 style="margin:0 0 4px; color:var(--navy); font-size:15px; font-weight:800;">${escapeHTML(b.title)}</h4>
                        <p style="margin:0 0 4px; font-size:12.5px; color:#475569;">लेखक/प्रकाशन: <b>${escapeHTML(b.author)}</b> · <span style="color:#0369a1; font-weight:600;">${escapeHTML(b.category)}</span></p>
                        <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                            <span class="book-available" style="font-size:12px; font-weight:700; color:${availCopies > 0 ? '#15803d' : '#b45309'};">
                                ${availCopies > 0 ? `✓ उपलब्ध: ${availCopies} प्रतियां (कुल ${totalCopies})` : `⏳ सभी ${totalCopies} प्रतियां अध्ययन में हैं`}
                            </span>
                            ${readingCount > 0 ? `<span style="font-size:11px; background:#eff6ff; color:#1e40af; padding:2px 8px; border-radius:6px; font-weight:700;">📖 ${readingCount} छात्र अभी पढ़ रहे हैं</span>` : ""}
                            <span style="font-size:11px; background:#dcfce7; color:#15803d; padding:2px 8px; border-radius:6px; font-weight:800;">✨ पढ़ाई 100% मुफ़्त (₹0)</span>
                        </div>
                    </div>
                </div>

                <div class="book-action-wrap" style="flex-shrink:0;">
                    ${availCopies > 0 ? `
                        <button type="button" class="btn btn-success" style="padding:8px 16px; font-size:12.5px; font-weight:800; box-shadow:0 3px 10px rgba(22,163,74,0.25);" onclick="openBookIssueModal('${escapeHTML(b.id)}')">
                            📖 पढ़ने हेतु लें (Free ₹0)
                        </button>
                    ` : `
                        <button type="button" class="btn btn-outline" style="padding:7px 12px; font-size:12px; font-weight:600; opacity:0.8;" onclick="toast('यह पुस्तक अभी अध्ययन हेतु ली जा चुकी है। छात्र द्वारा वापस जमा करने पर उपलब्ध होगी।', 'info')">
                            ⏳ अध्ययन जारी है
                        </button>
                    `}
                </div>
            </article>
        `;
    }).join("");
}

function searchBooks() {
    const q = String(value("bookSearch")).trim().toLowerCase();
    const filtered = booksCache.filter(b => 
        (b.title + " " + b.author + " " + b.category).toLowerCase().includes(q)
    );
    renderBooks(filtered);
}
window.searchBooks = searchBooks;

/* ================= LOCAL STORAGE BACKUP ================= */
function loadLocalData() {
    try {
        const u = localStorage.getItem("vidya_user");
        if (u) currentUser = JSON.parse(u);

        const ru = localStorage.getItem("vidya_registered_users");
        if (ru) registeredUsers = JSON.parse(ru);

        const b = localStorage.getItem("vidya_bookings");
        if (b) {
            const raw = JSON.parse(b);
            if (currentUser && currentUser.phoneNumber) {
                const uPhone = normalisePhone(currentUser.phoneNumber);
                myBookings = raw.filter(item => normalisePhone(item.studentPhone) === uPhone);
            } else {
                myBookings = [];
            }
        }

        const a = localStorage.getItem("vidya_admin_req");
        if (a) allAdminRequests = JSON.parse(a);

        const uu = localStorage.getItem("vidya_used_utrs");
        if (uu) usedUtrs = JSON.parse(uu);

        const bi = localStorage.getItem("vidya_book_issues");
        if (bi) bookIssues = JSON.parse(bi);

        const cmp = localStorage.getItem("vidya_complaints");
        if (cmp) allComplaints = JSON.parse(cmp);

        const av = localStorage.getItem("vidya_avail");
        if (av) availability = JSON.parse(av);
        else availability = { seats: {}, lockers: {} };
    } catch (e) {
        availability = { seats: {}, lockers: {} };
        console.warn("Local storage read error", e);
    }
}

function saveLocalData() {
    try {
        localStorage.setItem("vidya_registered_users", JSON.stringify(registeredUsers));
        localStorage.setItem("vidya_bookings", JSON.stringify(myBookings));
        localStorage.setItem("vidya_admin_req", JSON.stringify(allAdminRequests));
        localStorage.setItem("vidya_avail", JSON.stringify(availability));
        localStorage.setItem("vidya_used_utrs", JSON.stringify(usedUtrs));
        localStorage.setItem("vidya_book_issues", JSON.stringify(bookIssues));
        localStorage.setItem("vidya_complaints", JSON.stringify(allComplaints));
    } catch (e) {
        console.warn("Local storage write error", e);
    }
}

let resetConfirmPending = false;
let resetConfirmTimer = null;

function clearDemoData() {
    // 1. Strict Owner Authentication Guard
    if (!isAdminLoggedIn()) {
        toast("🔒 सुरक्षा प्रतिबंध: केवल मुख्य लाइब्रेरी संचालक (vidyalibrary005@gmail.com) ही डेटाबेस रीसेट कर सकते हैं।", "error");
        openAdminLoginModal();
        return;
    }

    // 2. In-page 2-step verification (Canvas safe without confirm() dialog)
    if (!resetConfirmPending) {
        resetConfirmPending = true;
        toast("⚠️ पुष्टि हेतु 5 सेकंड के भीतर दोबारा क्लिक करें: क्या आप निश्चित रूप से पूरा डेटाबेस रीसेट करना चाहते हैं?", "error");
        clearTimeout(resetConfirmTimer);
        resetConfirmTimer = setTimeout(() => {
            resetConfirmPending = false;
        }, 5000);
        return;
    }

    resetConfirmPending = false;
    clearTimeout(resetConfirmTimer);

    myBookings = [];
    allAdminRequests = [];
    registeredUsers = {};
    currentUser = null;
    availability = { seats: {}, lockers: {} };
    localStorage.removeItem("vidya_user");
    localStorage.removeItem("vidya_registered_users");
    localStorage.removeItem("vidya_bookings");
    localStorage.removeItem("vidya_admin_req");
    localStorage.removeItem("vidya_avail");
    localStorage.removeItem("vidya_used_utrs");
    updateAuthUI(null);
    selectSlot("4");
    selectMonths("1");
    renderLockerGrid();
    renderHistory();
    renderAdminRequests();
    updateSummary();
    toast("मालिक द्वारा डेटाबेस सुरक्षित रूप से रीसेट कर दिया गया। सभी 80 सीटें उपलब्ध हैं।", "info");
}


/* =========================================================
   STUDENT HELPDESK & COMPLAINT SYSTEM (विद्यार्थी सहायता व शिकायत निवारण)
   ========================================================= */

function saveComplaintsLocal() {
    try {
        localStorage.setItem("vidya_complaints", JSON.stringify(allComplaints));
    } catch (e) {
        console.warn("Save complaints error:", e);
    }
}

async function loadComplaintsFromFirebase() {
    try {
        const snap = await get(child(ref(db), "complaints"));
        if (snap.exists()) {
            const data = snap.val();
            const list = Object.values(data).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
            allComplaints = list;
            saveComplaintsLocal();
        }
    } catch (err) {
        console.warn("Firebase complaints fetch notice:", err);
    }
    renderStudentComplaints();
    renderAdminComplaints();
    updateAdminComplaintBadge();
}
window.loadComplaintsFromFirebase = loadComplaintsFromFirebase;

function updateAdminComplaintBadge() {
    const badge = $("adminComplaintBadge");
    if (badge) {
        const pendingCount = allComplaints.filter(c => c.status !== "resolved").length;
        badge.textContent = String(pendingCount);
        badge.style.display = pendingCount > 0 ? "inline-block" : "none";
    }
}
window.updateAdminComplaintBadge = updateAdminComplaintBadge;

async function handleComplaintSubmit(e) {
    e.preventDefault();

    const category = value("complaintCategory");
    const seatNo = value("complaintSeatNo").trim();
    const name = value("complaintStudentName").trim();
    const phone = normalisePhone(value("complaintStudentPhone"));
    const message = value("complaintText").trim();

    if (!category) {
        toast("कृपया परेशानी का प्रकार चुनें।", "error");
        $("complaintCategory")?.focus();
        return;
    }

    if (name.length < 2) {
        toast("कृपया अपना पूरा नाम दर्ज करें।", "error");
        $("complaintStudentName")?.focus();
        return;
    }

    if (!/^[6-9]\d{9}$/.test(phone)) {
        toast("कृपया सही 10 अंकों का WhatsApp मोबाइल नंबर दर्ज करें।", "error");
        $("complaintStudentPhone")?.focus();
        return;
    }

    if (message.length < 4) {
        toast("कृपया अपनी परेशानी का विवरण थोड़ा विस्तार से लिखें।", "error");
        $("complaintText")?.focus();
        return;
    }

    const complaintId = "CMP" + Math.floor(1000 + Math.random() * 9000);
    const dateFormatted = new Date().toLocaleDateString("en-IN", {
        day: '2-digit', month: 'short', year: 'numeric',
        hour: '2-digit', minute: '2-digit'
    });

    const record = {
        id: complaintId,
        studentName: name,
        studentPhone: phone,
        seatNo: seatNo || "—",
        category,
        message,
        status: "pending",
        createdAt: Date.now(),
        dateFormatted
    };

    // 1. Save to Firebase Realtime Database
    try {
        const updates = {};
        updates[`complaints/${complaintId}`] = record;
        updates[`users/${phone}/complaints/${complaintId}`] = record;
        await update(ref(db), updates);
        console.log("Complaint saved to Firebase:", complaintId);
    } catch (fbErr) {
        console.warn("Firebase complaint notice:", fbErr.message);
    }

    // 2. Save locally
    allComplaints.unshift(record);
    saveComplaintsLocal();

    toast(`✅ आपकी समस्या संचालक (मालिक) को भेज दी गई है (ID: #${complaintId})। शीघ्र समाधान किया जाएगा!`, "success");

    // Reset message
    if ($("complaintText")) $("complaintText").value = "";
    renderStudentComplaints();
    renderAdminComplaints();
    updateAdminComplaintBadge();
}
window.handleComplaintSubmit = handleComplaintSubmit;

function sendComplaintViaWhatsApp() {
    const category = value("complaintCategory") || "लाइब्रेरी सहायता";
    const seatNo = value("complaintSeatNo").trim();
    const name = value("complaintStudentName").trim() || currentUser?.displayName || "विद्यार्थी";
    const phone = normalisePhone(value("complaintStudentPhone")) || currentUser?.phoneNumber || "";
    const message = value("complaintText").trim();

    if (!message) {
        toast("कृपया पहले परेशानी का विवरण भरें।", "error");
        $("complaintText")?.focus();
        return;
    }

    const seatPart = seatNo ? ` (सीट नं: ${seatNo})` : "";
    const waText = `नमस्ते विद्या लाइब्रेरी संचालक (मालिक)!%0A%0Aमैं *${encodeURIComponent(name)}* बोल रहा हूँ${seatPart}।%0A📱 मोबाइल: ${phone}%0A⚠️ *विषय:* ${encodeURIComponent(category)}%0A📝 *समस्या का विवरण:* ${encodeURIComponent(message)}%0A%0Aकृपया इस परेशानी का जल्द समाधान करने की कृपा करें। धन्यवाद!`;

    window.open(`https://wa.me/919111701828?text=${waText}`, "_blank");
}
window.sendComplaintViaWhatsApp = sendComplaintViaWhatsApp;

function renderStudentComplaints() {
    const container = $("studentComplaintsList");
    if (!container) return;

    const curPhone = normalisePhone(currentUser?.phoneNumber || value("complaintStudentPhone"));
    const list = curPhone
        ? allComplaints.filter(c => normalisePhone(c.studentPhone) === curPhone)
        : allComplaints.slice(0, 3);

    if (!list.length) {
        container.innerHTML = `<div class="empty" style="padding:14px; font-size:12px; background:#f8fafc; border-radius:8px; text-align:center; color:#64748b;">
            आपने अभी तक कोई शिकायत या समस्या दर्ज नहीं की है। सब कुछ ठीक है! ✓
        </div>`;
        return;
    }

    container.innerHTML = list.map(c => `
        <div style="background:#f8fafc; border:1px solid #cbd5e1; border-radius:10px; padding:12px; margin-bottom:8px;">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:6px; margin-bottom:6px;">
                <div>
                    <span style="font-weight:800; color:var(--navy); font-size:13px;">#${c.id}</span>
                    <span style="font-size:11px; color:#64748b; margin-left:6px;">${c.dateFormatted || ''}</span>
                    ${c.seatNo && c.seatNo !== '—' ? `<span style="font-size:11px; background:#e0f2fe; color:#0369a1; padding:1px 6px; border-radius:4px; font-weight:700; margin-left:6px;">सीट: ${escapeHTML(c.seatNo)}</span>` : ''}
                </div>
                <div>
                    ${c.status === 'resolved' 
                        ? `<span style="background:#dcfce7; color:#15803d; padding:2px 8px; border-radius:6px; font-weight:800; font-size:11px; border:1px solid #86efac;">✅ समाधान पूर्ण (Resolved)</span>`
                        : `<span style="background:#fef3c7; color:#b45309; padding:2px 8px; border-radius:6px; font-weight:800; font-size:11px; border:1px solid #fde68a;">⏳ संचालक के पास लंबित (Pending)</span>`
                    }
                </div>
            </div>
            <div style="font-size:12px; font-weight:700; color:#1e293b; margin-bottom:3px;">
                ${escapeHTML(c.category)}
            </div>
            <div style="font-size:12px; color:#475569; line-height:1.4; background:#ffffff; padding:6px 10px; border-radius:6px; border:1px solid #e2e8f0;">
                ${escapeHTML(c.message)}
            </div>
        </div>
    `).join("");
}
window.renderStudentComplaints = renderStudentComplaints;

function renderAdminComplaints() {
    const container = $("adminComplaintsListTable");
    if (!container) return;

    if (!allComplaints.length) {
        container.innerHTML = `<div class="empty" style="padding:16px; text-align:center; color:#64748b;">
            अभी कोई विद्यार्थी शिकायत या समस्या दर्ज नहीं है। सब कुछ सामान्य है! ✓
        </div>`;
        return;
    }

    container.innerHTML = `
        <div style="display:flex; flex-direction:column; gap:10px;">
            ${allComplaints.map(c => `
                <div style="background:#ffffff; border:1.5px solid ${c.status === 'resolved' ? '#bbf7d0' : '#fcd34d'}; border-radius:12px; padding:14px; box-shadow:0 2px 8px rgba(0,0,0,0.04);">
                    <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:8px; margin-bottom:8px;">
                        <div>
                            <span style="font-weight:900; color:var(--navy); font-size:14px;">#${c.id}</span>
                            <span style="font-size:12px; font-weight:700; color:#0f172a; margin-left:8px;">${escapeHTML(c.studentName)}</span>
                            <span style="font-size:11.5px; color:#475569; margin-left:6px;">(${escapeHTML(c.studentPhone)})</span>
                            ${c.seatNo && c.seatNo !== '—' ? `<span style="font-size:11px; background:#eff6ff; color:#1e40af; padding:2px 7px; border-radius:5px; font-weight:800; margin-left:6px;">सीट: ${escapeHTML(c.seatNo)}</span>` : ''}
                            <div style="font-size:11px; color:#64748b; margin-top:2px;">दर्ज समय: ${c.dateFormatted || ''}</div>
                        </div>
                        <div style="display:flex; align-items:center; gap:8px;">
                            ${c.status === 'resolved' 
                                ? `<span style="background:#dcfce7; color:#15803d; padding:3px 10px; border-radius:6px; font-weight:800; font-size:12px; border:1px solid #86efac;">✅ सुलझा लिया गया</span>`
                                : `<button type="button" class="btn btn-sm btn-success" style="font-size:11.5px; padding:5px 10px; font-weight:800;" onclick="adminResolveComplaint('${c.id}', '${c.studentPhone}')">
                                    ✅ समाधान हुआ (Mark Resolved)
                                   </button>`
                            }
                            <a href="tel:${c.studentPhone}" class="btn btn-sm btn-outline" style="font-size:11px; padding:4px 8px;">📞 कॉल</a>
                            <a href="https://wa.me/91${c.studentPhone}?text=${encodeURIComponent('नमस्ते ' + c.studentName + ', विद्या लाइब्रेरी संचालक। आपकी शिकायत #' + c.id + ' के संबंध में:')}" target="_blank" class="btn btn-sm btn-success" style="font-size:11px; padding:4px 8px;">💬 WA</a>
                        </div>
                    </div>

                    <div style="font-size:12.5px; font-weight:800; color:#1e3a8a; margin-bottom:4px;">
                        ⚠️ विषय: ${escapeHTML(c.category)}
                    </div>
                    <div style="font-size:12.5px; color:#334155; line-height:1.45; background:#f8fafc; padding:8px 12px; border-radius:6px; border:1px solid #e2e8f0;">
                        ${escapeHTML(c.message)}
                    </div>
                </div>
            `).join("")}
        </div>
    `;
}
window.renderAdminComplaints = renderAdminComplaints;

async function adminResolveComplaint(id, phone) {
    if (!isAdminLoggedIn()) {
        toast("🔒 केवल मुख्य लाइब्रेरी संचालक ही इसे अपडेट कर सकते हैं।", "error");
        return;
    }

    try {
        const updates = {};
        updates[`complaints/${id}/status`] = "resolved";
        updates[`complaints/${id}/resolvedAt`] = Date.now();
        if (phone) {
            updates[`users/${phone}/complaints/${id}/status`] = "resolved";
            updates[`users/${phone}/complaints/${id}/resolvedAt`] = Date.now();
        }
        await update(ref(db), updates);
        console.log("Complaint marked resolved in Firebase:", id);
    } catch (e) {
        console.warn("Firebase update complaint notice:", e);
    }

    const item = allComplaints.find(c => c.id === id);
    if (item) {
        item.status = "resolved";
        item.resolvedAt = Date.now();
    }
    saveComplaintsLocal();

    toast(`✅ शिकायत #${id} का समाधान दर्ज कर दिया गया!`, "success");
    renderAdminComplaints();
    renderStudentComplaints();
    updateAdminComplaintBadge();
}
window.adminResolveComplaint = adminResolveComplaint;

function toggleAdminComplaintsView() {
    const box = $("adminComplaintsBox");
    if (!box) return;
    const isHidden = box.style.display === "none";
    box.style.display = isHidden ? "block" : "none";
    if (isHidden) {
        renderAdminComplaints();
        box.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
}
window.toggleAdminComplaintsView = toggleAdminComplaintsView;


/* ================= INITIAL SETUP ================= */
function setupUI() {
        // Production launch: ensure all 80 seats and 24 lockers are clean & vacant unless booked
    if (!localStorage.getItem("vidya_prod_v1")) {
        localStorage.clear();
        localStorage.setItem("vidya_prod_v1", "true");
        availability = { seats: {}, lockers: {} };
        myBookings = [];
        allAdminRequests = [];
        registeredUsers = {};
        currentUser = null;
    }

    loadLocalData();

    if ($("startDate")) $("startDate").min = todayDate();
    if ($("startDate") && !$("startDate").value) $("startDate").value = todayDate();
    if ($("lockerStartDate")) $("lockerStartDate").min = todayDate();
    if ($("lockerStartDate") && !$("lockerStartDate").value) $("lockerStartDate").value = todayDate();

    $("bookSearch")?.addEventListener("input", searchBooks);
    $("lockerStartDate")?.addEventListener("change", updateSummary);
    $("lockerMonths")?.addEventListener("change", updateSummary);

    setAuthMode("login");
    updateAuthUI(currentUser);
    selectSlot("4");
    selectMonths("1");
    renderLockerGrid();
    renderBooks(booksCache);
    loadBookIssuesFromFirebase();
    renderBookIssuesLog();
    updateSummary();
    if (currentUser && currentUser.phoneNumber) {
        loadUserBookingsFromFirebase(currentUser.phoneNumber);
    } else {
        renderHistory();
    }
    updateAdminUI();
    loadComplaintsFromFirebase();

    document.querySelectorAll(".nav-item[data-page]").forEach(b => {
        b.addEventListener("click", e => {
            e.preventDefault();
            go(b.dataset.page);
        });
    });

    startLiveAvailability();
}

// Global functions for inline HTML events

/* ================= DIRECT PHONE CALL & DIRECT WHATSAPP LAUNCH ================= */
function callPhone(number = "9111701828") {
    const cleanNum = String(number).replace(/\D/g, "");
    window.location.href = `tel:${cleanNum}`;
}
window.callPhone = callPhone;

function openWhatsApp(customText = "") {
    const defaultMsg = "नमस्ते विद्या लाइब्रेरी राजनांदगांव! मुझे सीट बुकिंग के बारे में जानकारी चाहिए।";
    const msg = encodeURIComponent(customText || defaultMsg);
    
    // Direct native WhatsApp app intent
    const appIntentUrl = `whatsapp://send?phone=919111701828&text=${msg}`;
    const webFallbackUrl = `https://api.whatsapp.com/send?phone=919111701828&text=${msg}`;

    const start = Date.now();
    window.location.href = appIntentUrl;

    setTimeout(() => {
        // If app intent wasn't handled within 700ms (e.g. desktop browser), fallback to web/wa.me
        if (Date.now() - start < 1200) {
            window.open(webFallbackUrl, "_blank");
        }
    }, 600);
}
window.openWhatsApp = openWhatsApp;


/* ================= SHOW / HIDE PASSWORD TOGGLE ================= */
function togglePasswordVisibility(inputId, btn) {
    const input = $(inputId);
    if (!input) return;
    if (input.type === "password") {
        input.type = "text";
        if (btn) btn.textContent = "🙈";
    } else {
        input.type = "password";
        if (btn) btn.textContent = "👁️";
    }
}
window.togglePasswordVisibility = togglePasswordVisibility;

/* ================= SEND RECEIPT TO WHATSAPP ================= */
function sendReceiptToWhatsApp(id) {
    const booking = myBookings.find(b => b.bookingId === id) || allAdminRequests.find(b => b.bookingId === id);
    if (!booking) {
        toast("रसीद का विवरण नहीं मिला!", "error");
        return;
    }
    const msg = `नमस्ते विद्या लाइब्रेरी राजनांदगांव!\nमैंने सीट/लॉकर बुक किया है। कृपया मेरी रसीद की पुष्टि करें:\n\n` +
        `📄 Reg. No. A: ${booking.regNum || booking.bookingId}\n` +
        `👤 विद्यार्थी: ${booking.studentName}\n` +
        `📱 मोबाइल: ${booking.studentPhone}\n` +
        `💺 प्लान: ${booking.plan || "Study Seat"} (${booking.months} माह)\n` +
        `📅 प्रारंभ तिथि: ${booking.startDate} से ${booking.endDate}\n` +
        `💰 कुल राशि: ₹${booking.totalAmount} (${booking.paymentMethod || "UPI"})\n` +
        `🔒 UTR / Ref: ${booking.utr || "Counter Cash"}\n` +
        `🏢 Vidya Library, Shiv Towar, Rajnandgaon`;
    openWhatsApp(msg);
}
window.sendReceiptToWhatsApp = sendReceiptToWhatsApp;

window.go = go;

window._pageRenderHooks = {
    booking: function() {
        if (currentUser) {
            if ($("studentName") && !$("studentName").value) $("studentName").value = currentUser.displayName || "";
            if ($("studentPhone") && !$("studentPhone").value && currentUser.phoneNumber) $("studentPhone").value = currentUser.phoneNumber;
        }
        renderSeatGrid();
        updateSummary();
        const curPhone = normalisePhone(value("studentPhone") || currentUser?.phoneNumber || "");
        if (curPhone.length === 10) {
            renderDepositBadge(curPhone, getStudentDepositStatus(curPhone));
        }
    },
    lockers: function() { renderLockerGrid(); },
    profile: function() {
        try { renderHistory(); } catch(e) {}
        try { renderAdminRequests(); } catch(e) {}
        try { renderStudentComplaints(); } catch(e) {}
    },
    books: function() { renderBooks(booksCache); },
    fees: function() { updateSummary(); }
};

window.setAuthMode = setAuthMode;
window.handleAuthSubmit = handleAuthSubmit;
window.sendForgotOTP = sendForgotOTP;
window.handleForgotSubmit = handleForgotSubmit;
window.logout = logout;
window.onPlanChange = onPlanChange;
window.onPayMethodChange = onPayMethodChange;
window.updateSummary = updateSummary;
window.prepareBooking = prepareBooking;
window.saveLocker = saveLocker;
window.submitLockerWithUTR = submitLockerWithUTR;
window.copyUPI = copyUPI;
window.printReceipt = printReceipt;
window.closeReceiptModal = closeReceiptModal;
window.downloadCurrentReceiptPDF = downloadCurrentReceiptPDF;
window.printReceiptDirect = printReceiptDirect;
window.searchBooks = searchBooks;
window.clearDemoData = clearDemoData;
window.toggleAdminPanel = toggleAdminPanel;
window.adminConfirm = adminConfirm;

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", setupUI, { once: true });
} else {
    setupUI();
}


async function adminRefundDeposit(phone, bookingId) {
    if (!phone) return;
    if (registeredUsers[phone]) {
        registeredUsers[phone].depositStatus = "refunded";
        registeredUsers[phone].depositRefundedAt = Date.now();
    }
    const b = myBookings.find(item => item.bookingId === bookingId) || allAdminRequests.find(item => item.bookingId === bookingId);
    if (b) b.depositRefunded = true;

    saveLocalData();

    try {
        await update(ref(db, `users/${phone}`), { depositStatus: "refunded", depositRefundedAt: Date.now() });
        if (bookingId) {
            await update(ref(db, `bookingRequests/${bookingId}`), { depositRefunded: true });
        }
    } catch (e) {}

    toast(`विद्यार्थी ${phone} का ₹300 डिपॉजिट रिफंड मार्क कर दिया गया!`, "info");
    renderAdminRequests();
    updateSummary();
    if (currentUser) updateAuthUI(currentUser);
}
window.adminRefundDeposit = adminRefundDeposit;


async function adminReject(bookingId) {
    const item = allAdminRequests.find(r => r.bookingId === bookingId);
    if (!item) return;

    item.status = "rejected";
    // Release seat back if it was reserved
    if (item.requestedSeat && availability.seats[String(item.requestedSeat)] === "reserved") {
        delete availability.seats[String(item.requestedSeat)];
    }
    if (item.locker && availability.lockers[String(item.locker)] === "reserved") {
        delete availability.lockers[String(item.locker)];
    }

    saveLocalData();

    try {
        await update(ref(db, `bookingRequests/${bookingId}`), { status: "rejected" });
        if (item.studentPhone) {
            await update(ref(db, `users/${item.studentPhone}/bookings/${bookingId}`), { status: "rejected" });
        }
        if (item.requestedSeat) {
            await update(ref(db, `public/availability/seats/${item.requestedSeat}`), "available");
        }
    } catch (e) {}

    toast(`बुकिंग ${bookingId} रिजेक्ट कर दी गई और सीट खाली कर दी गई।`, "error");
    renderAdminRequests();
    renderSeatGrid();
}
window.adminReject = adminReject;


function selectPlanFromTable(planName, monthsCount = null) {
    const slotEl = $("slot");
    if (slotEl) slotEl.value = planName;
    if (monthsCount && $("months")) $("months").value = String(monthsCount);

    if ($("feesSlotSelect")) $("feesSlotSelect").value = planName;
    if (monthsCount && $("feesMonthsSelect")) $("feesMonthsSelect").value = String(monthsCount);

    onPlanChange();
    updateSummary();

    const amt = calculateBookingAmount();
    toast(`${getPlanDisplayName(planName)} (${amt.months} माह) चयनित! कुल: ${money(amt.total)}`, "success");
}
window.selectPlanFromTable = selectPlanFromTable;

function togglePayQrCode(amount) {
    const qrArea = $("dynamicPayQrArea");
    if (!qrArea) return;
    qrArea.style.display = (qrArea.style.display === "none") ? "block" : "none";
}
window.togglePayQrCode = togglePayQrCode;

/* Synchronize dropdowns from Fees page to Booking page */
function syncFromFeesPage() {
    const fSlot = value("feesSlotSelect");
    const fMonths = value("feesMonthsSelect");
    if (fSlot && $("slot")) $("slot").value = fSlot;
    if (fMonths && $("months")) $("months").value = fMonths;
    onPlanChange();
    updateSummary();
}
window.syncFromFeesPage = syncFromFeesPage;

function syncToFeesPage() {
    const slot = value("slot");
    const months = value("months");
    if (slot && $("feesSlotSelect")) $("feesSlotSelect").value = slot;
    if (months && $("feesMonthsSelect")) $("feesMonthsSelect").value = months;
}


// Auto-remove any injected Netlify badges that cover bottom navigation
function removeInjectedNetlifyBadge() {
    try {
        const netlifyNodes = document.querySelectorAll('[data-netlify-deploy-id], [class*="netlify-feedback"], [id*="netlify-feedback"], .netlify-badge, #netlify-badge, iframe[src*="netlify"]');
        netlifyNodes.forEach(n => {
            n.style.display = "none";
            n.style.pointerEvents = "none";
            n.remove();
        });
    } catch (e) {}
}
if (typeof window !== "undefined") {
    window.addEventListener("DOMContentLoaded", removeInjectedNetlifyBadge);
    window.addEventListener("load", removeInjectedNetlifyBadge);
    setInterval(removeInjectedNetlifyBadge, 800);
}
