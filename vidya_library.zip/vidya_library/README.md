# Vidya Library Rajnandgaon - The Study Zone
Official Website & Student Portal for Vidya Library Rajnandgaon (C.G.)

## 🚀 How to Publish on GitHub Pages (1-Click Guide)
1. Push all files in this repository (or extract and commit them to your repository's `main` branch).
2. Go to your repository **Settings** -> **Pages**.
3. Under **Branch**, select `main` (root `/`) and click **Save**.
4. The `.nojekyll` file included in this repository automatically disables Jekyll so all HTML, CSS, JavaScript, and image assets load 100% cleanly without broken links.
5. Your website is live at `https://<your-username>.github.io/<your-repo>/`!

## 🚀 How to Publish on Netlify
1. Log into your Netlify account.
2. Go to **Deploys** or **Add new site** -> **Deploy manually**.
3. Drag and drop this extracted folder (or the `vidya_library.zip` file).
4. The website will be instantly live with all real photos and navigation active!
